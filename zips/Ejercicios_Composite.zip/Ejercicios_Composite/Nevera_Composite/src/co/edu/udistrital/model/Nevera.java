/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Jhon
 */

public class Nevera implements ComponenteNevera {
    private String nombre;
    private List<ComponenteNevera> componentes;
    private final double consumoBase = 100.0; // Consumo base de la nevera

    public Nevera(String nombre) {
        this.nombre = nombre;
        this.componentes = new ArrayList<>();
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public double getConsumoEnergia() {
        double total = consumoBase;
        for (ComponenteNevera c : componentes) {
            total += c.getConsumoEnergia();
        }
        return total;
    }

    @Override
    public String mostrarContenido(String indentacion) {
        StringBuilder sb = new StringBuilder();
        sb.append(indentacion).append("Nevera: ").append(nombre)
          .append(" | Consumo total: ").append(getConsumoEnergia()).append("W\n");
        
        for (ComponenteNevera c : componentes) {
            sb.append(c.mostrarContenido(indentacion + "  "));
        }
        return sb.toString();
    }

    @Override
    public void agregar(ComponenteNevera componente) {
        componentes.add(componente);
    }
}