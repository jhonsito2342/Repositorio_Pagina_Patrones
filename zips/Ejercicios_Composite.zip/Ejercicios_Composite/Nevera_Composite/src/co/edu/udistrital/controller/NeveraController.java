/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.controller;

import co.edu.udistrital.model.Producto;
import co.edu.udistrital.model.Compartimiento;
import co.edu.udistrital.view.VistaNevera;
import co.edu.udistrital.model.ComponenteNevera;
import co.edu.udistrital.model.Congelador;
import co.edu.udistrital.model.Nevera;

/**
 *
 * @author Jhon
 */

public class NeveraController {

    private VistaNevera vista;
    private Nevera nevera;
    private ComponenteNevera componenteActual;

    public NeveraController() {
        this.vista = new VistaNevera();
        this.nevera = new Nevera("Nevera Principal");
        this.componenteActual = nevera;

        // Mensaje inicial
        vista.mostrarMensaje("SISTEMA DE NEVERA INTELIGENTE (PATRÓN COMPOSITE)");
    }

    public void iniciar() {
        int opcion;
        do {
            vista.mostrarMenu();
            opcion = vista.leerOpcion();

            switch (opcion) {
                case 1:
                    agregarProducto();
                    break;
                case 2:
                    agregarCompartimiento();
                    break;
                case 3:
                    agregarCongelador();
                    break;
                case 4:
                    mostrarContenido();
                    break;
                case 5:
                    verConsumoTotal();
                    break;
                case 6:
                    vista.mostrarMensaje("Saliendo del sistema...");
                    break;
                default:
                    vista.mostrarMensaje("Opción no válida");
            }
        } while (opcion != 6);
    }

    private void agregarProducto() {
        String nombre = vista.leerNombre();
        double consumo = vista.leerConsumo();

        Producto producto = new Producto(nombre, consumo);
        componenteActual.agregar(producto);
        vista.mostrarMensaje("Producto '" + nombre + "' agregado con éxito");
    }

    private void agregarCompartimiento() {
        String nombre = vista.leerNombre();
        Compartimiento compartimiento = new Compartimiento(nombre);
        componenteActual.agregar(compartimiento);
        vista.mostrarMensaje("Compartimiento '" + nombre + "' agregado con éxito");
    }

    private void agregarCongelador() {
        String nombre = vista.leerNombre();
        Congelador congelador = new Congelador(nombre);
        componenteActual.agregar(congelador);
        vista.mostrarMensaje("Congelador '" + nombre + "' agregado con éxito");
    }

    private void mostrarContenido() {
        String contenido = nevera.mostrarContenido("");
        vista.mostrarContenido(contenido);
    }

    private void verConsumoTotal() {
        vista.mostrarMensaje("Consumo total de la nevera: " + nevera.getConsumoEnergia() + "W");
    }
}
