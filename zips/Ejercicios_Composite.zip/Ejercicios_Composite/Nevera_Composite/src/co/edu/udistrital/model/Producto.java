/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */
public class Producto implements ComponenteNevera {

    private String nombre;
    private double consumoEnergia;

    public Producto(String nombre, double consumoEnergia) {
        this.nombre = nombre;
        this.consumoEnergia = consumoEnergia;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public double getConsumoEnergia() {
        return consumoEnergia;
    }

    @Override
    public String mostrarContenido(String indentacion) {
        return indentacion + "- " + nombre + " | Consumo: " + consumoEnergia + "W\n";
    }

    @Override
    public void agregar(ComponenteNevera componente) {
        throw new UnsupportedOperationException("No se pueden agregar elementos a un producto");
    }
}
