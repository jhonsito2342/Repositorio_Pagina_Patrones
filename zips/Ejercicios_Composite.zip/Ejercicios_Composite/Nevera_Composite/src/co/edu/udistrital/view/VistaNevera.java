/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.view;


import java.util.Scanner;

/**
 *
 * @author Jhon
 */



public class VistaNevera {
    private Scanner scanner;
    
    public VistaNevera() {
        this.scanner = new Scanner(System.in);
    }
    
    public void mostrarMenu() {
        System.out.println("\n--- NEVERA INTELIGENTE ---");
        System.out.println("1. Agregar producto");
        System.out.println("2. Agregar compartimiento");
        System.out.println("3. Agregar congelador");
        System.out.println("4. Mostrar contenido");
        System.out.println("5. Ver consumo total");
        System.out.println("6. Salir");
        System.out.print("Seleccione opción: ");
    }
    
    public int leerOpcion() {
        return scanner.nextInt();
    }
    
    public String leerNombre() {
        System.out.print("Ingrese nombre: ");
        scanner.nextLine(); // Limpiar buffer
        return scanner.nextLine();
    }
    
    public double leerConsumo() {
        System.out.print("Ingrese consumo energético (W): ");
        double consumo = scanner.nextDouble();
        scanner.nextLine(); // Limpiar buffer
        return consumo;
    }
    
    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
    
    public void mostrarContenido(String contenido) {
        System.out.println("\n--- CONTENIDO DE LA NEVERA ---");
        System.out.println(contenido);
    }
}