/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.view;

import java.util.Scanner;

/**
 *
 * @author Jhon
 */

public class VistaBiblioteca {
    private Scanner scanner;
    
    public VistaBiblioteca() {
        this.scanner = new Scanner(System.in);
    }
    
    public void mostrarMenu() {
        System.out.println("\n--- MENÚ BIBLIOTECA ---");
        System.out.println("1. Agregar material");
        System.out.println("2. Agregar sección");
        System.out.println("3. Agregar estante");
        System.out.println("4. Mostrar contenido");
        System.out.println("5. Ver páginas totales");
        System.out.println("6. Salir");
        System.out.print("Seleccione opción: ");
    }
    
    public int leerOpcion() {
        return scanner.nextInt();
    }
    
    public String leerTipoMaterial() {
        System.out.print("Ingrese tipo de material (Libro/Revista/Diario): ");
        scanner.nextLine();
        return scanner.nextLine();
    }
    
    public String leerTitulo() {
        System.out.print("Ingrese título: ");
        return scanner.nextLine();
    }
    
    public int leerPaginas() {
        System.out.print("Ingrese número de páginas: ");
        int paginas = scanner.nextInt();
        scanner.nextLine();
        return paginas;
    }
    
    public String leerNombreSeccion() {
        System.out.print("Ingrese nombre de la sección: ");
        scanner.nextLine();
        return scanner.nextLine();
    }
    
    public String leerNumeroEstante() {
        System.out.print("Ingrese número de estante: ");
        scanner.nextLine();
        return scanner.nextLine();
    }
    
    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
    
    public void mostrarContenido(String contenido) {
        System.out.println("\n--- CONTENIDO DE LA BIBLIOTECA ---");
        System.out.println(contenido);
    }
}