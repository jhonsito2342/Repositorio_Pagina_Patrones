/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Jhon
 */

public class Seccion implements ComponenteBiblioteca {
    private String nombre;
    private List<ComponenteBiblioteca> componentes;

    public Seccion(String nombre) {
        this.nombre = nombre;
        this.componentes = new ArrayList<>();
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public int getTotalPaginas() {
        int total = 0;
        for (ComponenteBiblioteca c : componentes) {
            total += c.getTotalPaginas();
        }
        return total;
    }

    @Override
    public String mostrarContenido(String indentacion) {
        StringBuilder sb = new StringBuilder();
        sb.append(indentacion).append("Sección: ").append(nombre)
          .append(" | Páginas: ").append(getTotalPaginas()).append("\n");
        
        for (ComponenteBiblioteca c : componentes) {
            sb.append(c.mostrarContenido(indentacion + "  "));
        }
        return sb.toString();
    }

    @Override
    public void agregar(ComponenteBiblioteca componente) {
        componentes.add(componente);
    }
}