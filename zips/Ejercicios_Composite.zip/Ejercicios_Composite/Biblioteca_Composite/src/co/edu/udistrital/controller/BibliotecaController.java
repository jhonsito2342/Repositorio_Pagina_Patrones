/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.controller;

import co.edu.udistrital.model.Biblioteca;
import co.edu.udistrital.model.Estante;
import co.edu.udistrital.model.Seccion;
import co.edu.udistrital.model.Material;
import co.edu.udistrital.view.VistaBiblioteca;
import co.edu.udistrital.model.ComponenteBiblioteca;

/**
 *
 * @author Jhon
 */


public class BibliotecaController {
    private VistaBiblioteca vista;
    private Biblioteca biblioteca;
    private ComponenteBiblioteca componenteActual;

    public BibliotecaController() {
        this.vista = new VistaBiblioteca();
        this.biblioteca = new Biblioteca("Biblioteca Central");
        this.componenteActual = biblioteca;
        vista.mostrarMensaje("SISTEMA DE BIBLIOTECA (PATRÓN COMPOSITE)");
    }

    public void iniciar() {
        int opcion;
        do {
            vista.mostrarMenu();
            opcion = vista.leerOpcion();

            switch (opcion) {
                case 1: agregarMaterial(); break;
                case 2: agregarSeccion(); break;
                case 3: agregarEstante(); break;
                case 4: mostrarContenido(); break;
                case 5: verPaginasTotales(); break;
                case 6: vista.mostrarMensaje("Saliendo del sistema..."); break;
                default: vista.mostrarMensaje("Opción no válida");
            }
        } while (opcion != 6);
    }

    private void agregarMaterial() {
        String tipo = vista.leerTipoMaterial();
        String titulo = vista.leerTitulo();
        int paginas = vista.leerPaginas();
        componenteActual.agregar(new Material(tipo, titulo, paginas));
        vista.mostrarMensaje("Material '" + titulo + "' agregado con éxito");
    }

    private void agregarSeccion() {
        String nombre = vista.leerNombreSeccion();
        componenteActual.agregar(new Seccion(nombre));
        vista.mostrarMensaje("Sección '" + nombre + "' agregada con éxito");
    }

    private void agregarEstante() {
        String numero = vista.leerNumeroEstante();
        componenteActual.agregar(new Estante(numero));
        vista.mostrarMensaje("Estante '" + numero + "' agregado con éxito");
    }

    private void mostrarContenido() {
        vista.mostrarContenido(biblioteca.mostrarContenido(""));
    }

    private void verPaginasTotales() {
        vista.mostrarMensaje("Total de páginas en la biblioteca: " + biblioteca.getTotalPaginas());
    }
}