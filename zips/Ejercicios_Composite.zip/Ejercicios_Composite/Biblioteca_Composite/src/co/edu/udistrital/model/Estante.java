/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Jhon
 */



public class Estante implements ComponenteBiblioteca {
    private String numero;
    private List<ComponenteBiblioteca> materiales;

    public Estante(String numero) {
        this.numero = numero;
        this.materiales = new ArrayList<>();
    }

    @Override
    public String getNombre() {
        return "Estante " + numero;
    }

    @Override
    public int getTotalPaginas() {
        int total = 0;
        for (ComponenteBiblioteca m : materiales) {
            total += m.getTotalPaginas();
        }
        return total;
    }

    @Override
    public String mostrarContenido(String indentacion) {
        StringBuilder sb = new StringBuilder();
        sb.append(indentacion).append("Estante ").append(numero)
          .append(" | Páginas: ").append(getTotalPaginas()).append("\n");
        
        for (ComponenteBiblioteca m : materiales) {
            sb.append(m.mostrarContenido(indentacion + "  "));
        }
        return sb.toString();
    }

    @Override
    public void agregar(ComponenteBiblioteca componente) {
        materiales.add(componente);
    }
}