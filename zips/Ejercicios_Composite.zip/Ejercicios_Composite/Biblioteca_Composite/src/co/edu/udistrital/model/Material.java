/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */


public class Material implements ComponenteBiblioteca {
    private String tipo;
    private String titulo;
    private int paginas;

    public Material(String tipo, String titulo, int paginas) {
        this.tipo = tipo;
        this.titulo = titulo;
        this.paginas = paginas;
    }

    @Override
    public String getNombre() {
        return tipo + ": " + titulo;
    }

    @Override
    public int getTotalPaginas() {
        return paginas;
    }

    @Override
    public String mostrarContenido(String indentacion) {
        return indentacion + "- " + tipo + ": " + titulo + " (" + paginas + " páginas)\n";
    }

    @Override
    public void agregar(ComponenteBiblioteca componente) {
        throw new UnsupportedOperationException("No se pueden agregar elementos a un material");
    }
}