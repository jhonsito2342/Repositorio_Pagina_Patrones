/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Jhon
 */


public class Biblioteca implements ComponenteBiblioteca {

    private String nombre;
    private List<ComponenteBiblioteca> componentes;
    private final int paginasBase = 0;

    public Biblioteca(String nombre) {
        this.nombre = nombre;
        this.componentes = new ArrayList<>();
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public int getTotalPaginas() {
        int total = paginasBase;
        for (ComponenteBiblioteca c : componentes) {
            total += c.getTotalPaginas();
        }
        return total;
    }

    @Override
    public String mostrarContenido(String indentacion) {
        StringBuilder sb = new StringBuilder();
        sb.append(indentacion).append("Biblioteca: ").append(nombre)
                .append(" | Total páginas: ").append(getTotalPaginas()).append("\n");

        for (ComponenteBiblioteca c : componentes) {
            sb.append(c.mostrarContenido(indentacion + "  "));
        }
        return sb.toString();
    }

    @Override
    public void agregar(ComponenteBiblioteca componente) {
        componentes.add(componente);
    }
}
