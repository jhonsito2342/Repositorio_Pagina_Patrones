/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.controller;

import co.edu.udistrital.model.Area;
import co.edu.udistrital.model.ComponenteGaraje;
import co.edu.udistrital.model.Estacionamiento;
import co.edu.udistrital.model.Garaje;
import co.edu.udistrital.model.Vehiculo;
import co.edu.udistrital.view.VistaGaraje;

/**
 *
 * @author Jhon
 */

public class GarajeController {
    private VistaGaraje vista;
    private Garaje garaje;
    private ComponenteGaraje componenteActual;

    public GarajeController() {
        this.vista = new VistaGaraje();
        this.garaje = new Garaje("Garaje Principal");
        this.componenteActual = garaje;
        vista.mostrarMensaje("SISTEMA DE GARAJE (PATRÓN COMPOSITE)");
    }

    public void iniciar() {
        int opcion;
        do {
            vista.mostrarMenu();
            opcion = vista.leerOpcion();

            switch (opcion) {
                case 1: agregarVehiculo(); break;
                case 2: agregarArea(); break;
                case 3: agregarEstacionamiento(); break;
                case 4: mostrarContenido(); break;
                case 5: verEspacioTotal(); break;
                case 6: vista.mostrarMensaje("Saliendo..."); break;
                default: vista.mostrarMensaje("Opción inválida");
            }
        } while (opcion != 6);
    }

    private void agregarVehiculo() {
        String tipo = vista.leerTipoVehiculo();
        String placa = vista.leerPlaca();
        double espacio = vista.leerEspacio();
        componenteActual.agregar(new Vehiculo(tipo, placa, espacio));
        vista.mostrarMensaje("Vehículo agregado");
    }

    private void agregarArea() {
        String nombre = vista.leerNombreArea();
        componenteActual.agregar(new Area(nombre));
        vista.mostrarMensaje("Área '" + nombre + "' agregada");
    }

    private void agregarEstacionamiento() {
        String nombre = vista.leerNombreArea();
        componenteActual.agregar(new Estacionamiento(nombre));
        vista.mostrarMensaje("Estacionamiento '" + nombre + "' agregado");
    }

    private void mostrarContenido() {
        vista.mostrarContenido(garaje.mostrarContenido(""));
    }

    private void verEspacioTotal() {
        vista.mostrarMensaje("Espacio total ocupado: " + garaje.getEspacioOcupado() + " m²");
    }
}