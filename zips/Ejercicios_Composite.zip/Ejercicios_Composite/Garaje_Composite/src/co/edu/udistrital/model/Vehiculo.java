/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */

public class Vehiculo implements ComponenteGaraje {
    private String tipo;
    private String placa;
    private double espacio;

    public Vehiculo(String tipo, String placa, double espacio) {
        this.tipo = tipo;
        this.placa = placa;
        this.espacio = espacio;
    }

    @Override
    public String getNombre() {
        return tipo + " " + placa;
    }

    @Override
    public double getEspacioOcupado() {
        return espacio;
    }

    @Override
    public String mostrarContenido(String indentacion) {
        return indentacion + "- " + tipo + " " + placa + " | Espacio: " + espacio + " m²\n";
    }

    @Override
    public void agregar(ComponenteGaraje componente) {
        throw new UnsupportedOperationException("No se pueden agregar elementos a un vehículo");
    }
}