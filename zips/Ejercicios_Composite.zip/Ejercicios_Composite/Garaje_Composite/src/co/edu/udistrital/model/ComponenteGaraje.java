/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */
public interface ComponenteGaraje {

    String getNombre();

    double getEspacioOcupado();

    String mostrarContenido(String indentacion);

    void agregar(ComponenteGaraje componente);
}
