/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Jhon
 */


public class Estacionamiento implements ComponenteGaraje {
    private String nombre;
    private List<ComponenteGaraje> componentes;
    private final double espacioBase = 5.0;

    public Estacionamiento(String nombre) {
        this.nombre = nombre;
        this.componentes = new ArrayList<>();
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public double getEspacioOcupado() {
        double total = espacioBase;
        for (ComponenteGaraje c : componentes) {
            total += c.getEspacioOcupado();
        }
        return total;
    }

    @Override
    public String mostrarContenido(String indentacion) {
        StringBuilder sb = new StringBuilder();
        sb.append(indentacion).append("Estacionamiento: ").append(nombre)
          .append(" | Espacio: ").append(getEspacioOcupado()).append(" m²\n");
        
        for (ComponenteGaraje c : componentes) {
            sb.append(c.mostrarContenido(indentacion + "  "));
        }
        return sb.toString();
    }

    @Override
    public void agregar(ComponenteGaraje componente) {
        componentes.add(componente);
    }
}