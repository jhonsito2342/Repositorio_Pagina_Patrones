/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.view;

import java.util.Scanner;

/**
 *
 * @author Jhon
 */
public class VistaGaraje {

    private Scanner scanner;

    public VistaGaraje() {
        this.scanner = new Scanner(System.in);
    }

    public void mostrarMenu() {
        System.out.println("\n--- MENÚ GARAJE ---");
        System.out.println("1. Agregar vehículo");
        System.out.println("2. Agregar área");
        System.out.println("3. Agregar estacionamiento");
        System.out.println("4. Mostrar contenido");
        System.out.println("5. Ver espacio total");
        System.out.println("6. Salir");
        System.out.print("Seleccione opción: ");
    }

    public int leerOpcion() {
        return scanner.nextInt();
    }

    public String leerTipoVehiculo() {
        System.out.print("Ingrese tipo de vehículo (Auto/Moto/Camioneta): ");
        scanner.nextLine();
        return scanner.nextLine();
    }

    public String leerPlaca() {
        System.out.print("Ingrese placa del vehículo: ");
        return scanner.nextLine();
    }

    public double leerEspacio() {
        System.out.print("Ingrese espacio ocupado (m²): ");
        double espacio = scanner.nextDouble();
        scanner.nextLine();
        return espacio;
    }

    public String leerNombreArea() {
        System.out.print("Ingrese nombre del área/estacionamiento: ");
        scanner.nextLine();
        return scanner.nextLine();
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }

    public void mostrarContenido(String contenido) {
        System.out.println("\n--- CONTENIDO DEL GARAJE ---");
        System.out.println(contenido);
    }
}
