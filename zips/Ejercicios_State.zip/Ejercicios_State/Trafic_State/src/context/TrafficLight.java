/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package context;

import states.*;

public class TrafficLight {

    private TrafficLightState currentState;

    public TrafficLight() {
        this.currentState = new RedState();
    }

    public void changeState(TrafficLightState state) {
        this.currentState = state;
    }

    public void performAction() {
        currentState.handle();
    }

    public void simulate() throws InterruptedException {
        while (true) {
            System.out.println("Luz actual: " + currentState.getColor());
            performAction();

            Thread.sleep(currentState.getDuration() * 1000);

            // Transición de estados
            if (currentState.getColor().equals("ROJO")) {
                changeState(new GreenState());
            } else if (currentState.getColor().equals("VERDE")) {
                changeState(new YellowState());
            } else {
                changeState(new RedState());
            }
        }
    }
}
