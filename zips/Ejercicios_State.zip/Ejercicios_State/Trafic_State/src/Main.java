/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

import context.TrafficLight;

public class Main {

    public static void main(String[] args) throws InterruptedException {
        TrafficLight trafficLight = new TrafficLight();

        System.out.println("=== Simulación de semáforo ===");
        trafficLight.simulate(); // Corre indefinidamente con cambios de estado
    }
}
