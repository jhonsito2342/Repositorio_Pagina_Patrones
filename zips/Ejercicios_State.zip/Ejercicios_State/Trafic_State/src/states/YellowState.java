/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package states;

public class YellowState implements TrafficLightState {
    @Override
    public void handle() {
        System.out.println("AMARILLO: Precaución");
    }
    
    @Override
    public String getColor() {
        return "AMARILLO";
    }
    
    @Override
    public int getDuration() {
        return 5; // segundos
    }
}