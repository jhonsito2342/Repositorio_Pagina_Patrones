/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package states;

public class GreenState implements TrafficLightState {
    @Override
    public void handle() {
        System.out.println("VERDE: Avanzar");
    }
    
    @Override
    public String getColor() {
        return "VERDE";
    }
    
    @Override
    public int getDuration() {
        return 45; // segundos
    }
}