/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package context;

import states.*;

public class AudioPlayer {

    private PlayerState currentState;

    public AudioPlayer() {
        this.currentState = new ReadyState();
    }

    public void changeState(PlayerState state) {
        this.currentState = state;
    }

    public void clickPlay() {
        currentState.clickPlay();
        if (currentState instanceof ReadyState) {
            changeState(new PlayingState());
        } else if (currentState instanceof PausedState) {
            changeState(new PlayingState());
        }
    }

    public void clickPause() {
        currentState.clickPause();
        if (currentState instanceof PlayingState) {
            changeState(new PausedState());
        }
    }

    public void clickLock() {
        currentState.clickLock();
        if (!(currentState instanceof LockedState)) {
            changeState(new LockedState());
        } else {
            changeState(new ReadyState());
        }
    }

    public void clickNext() {
        currentState.clickNext();
    }

    public void clickPrevious() {
        currentState.clickPrevious();
    }
}
