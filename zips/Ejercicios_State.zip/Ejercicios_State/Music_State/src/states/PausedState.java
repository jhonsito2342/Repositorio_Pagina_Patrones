/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package states;

import context.AudioPlayer;

public class PausedState implements PlayerState {
    @Override
    public void clickPlay() {
        System.out.println("Reanudando reproducción");
    }
    
    @Override
    public void clickPause() {
        System.out.println("Ya está en pausa");
    }
    
    @Override
    public void clickLock() {
        System.out.println("Bloqueando reproductor");
    }
    
    @Override
    public void clickNext() {
        System.out.println("Siguiente canción (manteniendo pausa)");
    }
    
    @Override
    public void clickPrevious() {
        System.out.println("Canción anterior (manteniendo pausa)");
    }
}