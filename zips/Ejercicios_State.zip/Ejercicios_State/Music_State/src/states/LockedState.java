/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package states;

import context.AudioPlayer;

public class LockedState implements PlayerState {
    @Override
    public void clickPlay() {
        System.out.println("Reproductor bloqueado - Desbloquear primero");
    }
    
    @Override
    public void clickPause() {
        System.out.println("Reproductor bloqueado - Desbloquear primero");
    }
    
    @Override
    public void clickLock() {
        System.out.println("Reproductor ya está bloqueado");
    }
    
    @Override
    public void clickNext() {
        System.out.println("Reproductor bloqueado - Desbloquear primero");
    }
    
    @Override
    public void clickPrevious() {
        System.out.println("Reproductor bloqueado - Desbloquear primero");
    }
}