/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package states;

import context.AudioPlayer;

public class PlayingState implements PlayerState {
    @Override
    public void clickPlay() {
        System.out.println("Ya está reproduciéndose");
    }
    
    @Override
    public void clickPause() {
        System.out.println("Pausando reproducción");
    }
    
    @Override
    public void clickLock() {
        System.out.println("Bloqueando reproductor");
    }
    
    @Override
    public void clickNext() {
        System.out.println("Reproduciendo siguiente canción");
    }
    
    @Override
    public void clickPrevious() {
        System.out.println("Reproduciendo canción anterior");
    }
}