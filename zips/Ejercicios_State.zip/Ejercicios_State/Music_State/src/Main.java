/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

import context.AudioPlayer;

public class Main {

    public static void main(String[] args) {
        AudioPlayer player = new AudioPlayer();

        System.out.println("=== Prueba de estados del reproductor ===");
        player.clickPlay();  // Ready -> Playing
        player.clickPause(); // Playing -> Paused
        player.clickPlay();  // Paused -> Playing
        player.clickLock();  // Playing -> Locked
        player.clickPlay();  // No cambia (locked)
        player.clickLock();  // Locked -> Ready
        player.clickPlay();  // Ready -> Playing
        player.clickNext();  // Siguiente canción
    }
}
