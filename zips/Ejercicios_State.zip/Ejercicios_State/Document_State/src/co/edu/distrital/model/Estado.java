package co.edu.distrital.model;

/**
 * Interfaz del patrón State.
 * Define los métodos que todos los estados concretos deben implementar.
 * Permite que cada estado defina su propio comportamiento.
 */
public interface Estado {
    void escribir(Documento doc, String texto);
    void publicar(Documento doc);
}