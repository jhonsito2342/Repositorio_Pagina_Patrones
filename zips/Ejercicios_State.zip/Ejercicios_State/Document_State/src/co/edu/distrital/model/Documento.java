package co.edu.distrital.model;

import co.edu.udistrital.model.concrete.*;
/**
 * Clase principal del modelo (Modelo del MVC).
 * Representa el Documento y mantiene su estado actual.
 *
 * Colabora con el patrón State: contiene una instancia de Estado que varía en tiempo de ejecución.
 */
public class Documento {
    private Estado estado;
    private String contenido = "";

    public Documento() {
        // Estado inicial al crear un documento
        this.estado = new EstadoBorrador();
    }

    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    public Estado getEstado() {
        return estado;
    }

    public String getContenido() {
        return contenido;
    }

    public void agregarContenido(String texto) {
        this.contenido += texto + "\n";
    }

    // Estas llamadas se delegan al objeto Estado actual (patrón State)
    public void escribir(String texto) {
        estado.escribir(this, texto);
    }

    public void cambiarEstado() {
        estado.publicar(this);
    }
}