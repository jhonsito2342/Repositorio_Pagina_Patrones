package co.edu.udistrital.controller;

public class AplMain {	
	/**
	 * Punto de entrada del programa.
	 * Inicializa el controlador y ejecuta la aplicación.
	 */
	public static void main(String[] args) {

		Controller control;
		control = new Controller();
		control.run();

	}


}