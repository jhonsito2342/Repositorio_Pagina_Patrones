package co.edu.udistrital.view;

import java.util.InputMismatchException; // Importa InputMismatchException
import java.util.Scanner;

public class VistaConsola {

	private Scanner sc;

	public VistaConsola() {
		sc = new Scanner(System.in);
	}

	public void mostrarInformacion(String mensaje) {
		System.out.println(mensaje);
	}

	public int leerDatoEntero(String mensaje) {
		int dato = 0;
		while (true) { // Bucle para asegurar una entrada válida
			System.out.print(mensaje);
			try {
				dato = sc.nextInt();
				sc.nextLine(); // <<-- IMPORTANTE: Consumir el salto de línea pendiente
				return dato;
			} catch (InputMismatchException e) {
				// Captura si el usuario no ingresa un entero
				System.out.println("Error: Debe ingresar un número entero válido.");
				sc.nextLine(); // <<-- IMPORTANTE: Consumir la entrada inválida para limpiar el búfer
			}
		}
	}

	public String leerString(String mensaje) {
		System.out.print(mensaje);
		// No necesitamos un nextLine() extra aquí porque el nextLine() de
		// leerDatoEntero o leerDouble ya consume el salto de línea anterior.
		return sc.nextLine();
	}

	public boolean leerBoolean(String mensaje) {
		while (true) {
			System.out.print(mensaje);
			String dato = sc.nextLine().trim().toUpperCase();

			if (dato.equals("SI")) {
				return true;
			} else if (dato.equals("NO")) {
				return false;
			} else {
				System.out.println("Error: Debe ingresar SI o NO");
			}
		}
	}

	public double leerDouble(String mensaje) {
		while (true) {
			System.out.print(mensaje);
			try {
				// Parseamos directamente la línea completa para evitar problemas con nextDouble()
				return Double.parseDouble(sc.nextLine().trim());
			} catch (NumberFormatException e) {
				// Captura si el usuario no ingresa un número válido
				System.out.println("Error: Debe ingresar un número válido. Ejemplo: 12.5");
			}
		}
	}
}