package co.edu.udistrital.model.concrete;

import co.edu.distrital.model.Documento;
import co.edu.distrital.model.Estado;
import co.edu.udistrital.view.*;

/**
 * Estado concreto que representa el estado "Borrador" del documento.
 * Permite modificar el contenido y enviar el documento a moderación.
 */
public class EstadoBorrador implements Estado {
	VistaConsola vista;

    @Override
    public void escribir(Documento doc, String texto) {
        doc.agregarContenido(texto);
        vista.mostrarInformacion("Escribiendo en Borrador: " + texto);
    }

    @Override
    public void publicar(Documento doc) {
        doc.setEstado(new EstadoModeracion()); // transita al siguiente estado
        vista.mostrarInformacion("Documento enviado a Moderación.");
    }
}