package co.edu.udistrital.controller;

import co.edu.distrital.model.Documento;
import co.edu.udistrital.view.VistaConsola;

/**
 * Controlador (parte del patrón MVC).
 */

public class Controller {

    private Documento doc;           // Modelo: documento sobre el que se actúa
    private VistaConsola vista;      // Vista: encargada de mostrar información y recibir entrada

    /**
     * Constructor del controlador. Inicializa el modelo y la vista.
     */
    public Controller() {
        doc = new Documento(); // Inicializa el documento en estado Borrador
        vista = new VistaConsola(); // Vista basada en consola
    }

    /**
     * Método principal que ejecuta la lógica de la aplicación.
     * Presenta un menú al usuario y responde según su elección.
     */
    public void run() {
        boolean salir = false; // Controla el ciclo del menú

        vista.mostrarInformacion("Bienvenido al sistema de edición de documentos\n");

        // Bucle principal del menú
        while (!salir) {
            try {
                // Mostrar opciones del menú
                vista.mostrarInformacion("\n===== MENÚ DE OPCIONES =====");
                vista.mostrarInformacion("1. Escribir en el documento");
                vista.mostrarInformacion("2. Cambiar de estado: Borrador -> Moderación -> Publicado");
                vista.mostrarInformacion("3. Mostrar estado actual");
                vista.mostrarInformacion("4. Mostrar contenido");
                vista.mostrarInformacion("5. Salir");

                // Leer opción del usuario
                int opcion = vista.leerDatoEntero("Seleccione una opción: ");

                // Ejecutar acción según la opción seleccionada
                switch (opcion) {
                    case 1:
                        // Permite ingresar texto para agregar al documento
                        String texto = vista.leerString("Ingrese el texto a agregar: ");
                        doc.escribir(texto);
                        break;
                    case 2:
                        // Cambia de estado: Borrador -> Moderación -> Publicado
                        doc.cambiarEstado();
                        break;
                    case 3:
                        // Muestra el nombre de la clase del estado actual
                        vista.mostrarInformacion("Estado actual: " + doc.getEstado().getClass().getSimpleName());
                        break;
                    case 4:
                        // Muestra el contenido completo del documento
                        vista.mostrarInformacion("Contenido actual:\n" + doc.getContenido());
                        break;
                    case 5:
                        // Termina la aplicación
                        salir = true;
                        vista.mostrarInformacion("Saliendo del programa. ¡Hasta pronto!");
                        break;
                    default:
                        // Manejo de opción no válida
                        vista.mostrarInformacion("Opción inválida. Intente nuevamente.");
                        break;
                }
            } catch (Exception e) {
                // Captura errores generales (por ejemplo, entrada no numérica)
                vista.mostrarInformacion("Error: Entrada inválida. Intente nuevamente.\n");
            }
        }
    }
} 
