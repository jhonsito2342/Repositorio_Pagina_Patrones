package co.edu.udistrital.model.concrete;

import co.edu.distrital.model.Documento;
import co.edu.distrital.model.Estado;
import co.edu.udistrital.view.VistaConsola;

/**
 * Estado concreto que representa el estado "Publicado".
 * No permite hacer ninguna modificación adicional.
 */
public class EstadoPublicado implements Estado {
	VistaConsola vista;
	
    @Override
    public void escribir(Documento doc, String texto) {
    	vista.mostrarInformacion("El documento ya fue publicado. No se puede modificar.");
    }

    @Override
    public void publicar(Documento doc) {
    	vista.mostrarInformacion("El documento ya está publicado.");
    }

}