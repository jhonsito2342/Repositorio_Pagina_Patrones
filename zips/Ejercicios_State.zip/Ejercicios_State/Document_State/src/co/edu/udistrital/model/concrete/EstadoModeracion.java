package co.edu.udistrital.model.concrete;

import co.edu.distrital.model.Documento;
import co.edu.distrital.model.Estado;
import co.edu.udistrital.view.VistaConsola;

/**
 * Estado concreto que representa el estado "Moderación".
 * No permite modificar el contenido. Solo permite publicarlo.
 */
public class EstadoModeracion implements Estado {
	VistaConsola vista;

    @Override
    public void escribir(Documento doc, String texto) {
    	vista.mostrarInformacion("No se puede escribir mientras está en Moderación.");
    }

    @Override
    public void publicar(Documento doc) {
        doc.setEstado(new EstadoPublicado()); // transita a publicado
        vista.mostrarInformacion("Documento Publicado.");
    }
}