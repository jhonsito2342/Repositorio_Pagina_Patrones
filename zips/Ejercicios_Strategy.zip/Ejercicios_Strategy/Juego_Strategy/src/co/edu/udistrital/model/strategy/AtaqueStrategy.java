package co.edu.udistrital.model.strategy;

public interface AtaqueStrategy {

	// Metodo que implementaran todas las estrategias de ataque
    // Recibe el nombre del atacante y del objetivo, y devuelve un mensaje del ataque.
	String atacar(String atacante, String objetivo);
}
