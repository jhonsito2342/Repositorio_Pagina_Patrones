package co.edu.udistrital.model;

import co.edu.udistrital.model.strategy.AtaqueStrategy;

public class AtaqueAgua implements AtaqueStrategy{

	// Implementa el método atacar del Strategy, específico para ataque de tipo agua.
	@Override
	public String atacar(String atacante, String objetivo) {
		String mensaje = atacante + " lanza un chorro de agua a " + objetivo + "!\n";
		return mensaje;
	}

}
