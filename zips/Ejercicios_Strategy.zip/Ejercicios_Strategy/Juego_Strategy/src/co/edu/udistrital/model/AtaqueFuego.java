package co.edu.udistrital.model;

import co.edu.udistrital.model.strategy.AtaqueStrategy;

public class AtaqueFuego implements AtaqueStrategy{

	// Implementa el método atacar del Strategy, específico para ataque de tipo fuego.
	@Override
	public String atacar(String atacante, String objetivo) {
		String mensaje = atacante + " lanza una llamarada ardiente a " + objetivo + "!\n";
		return mensaje;
	}

	

}
