package co.edu.udistrital.model;

import co.edu.udistrital.model.strategy.AtaqueStrategy;

public class Pokemon {

	// Nombre del Pokemon
	private String nombre;
	// Estrategia de ataque que utiliza
	private AtaqueStrategy estrategia;
	
	public Pokemon(String nombre, AtaqueStrategy estrategia) {
        this.nombre = nombre;
        this.estrategia = estrategia;
    }

	// Metodo para atacar a otro Pokemon usando la estrategia actual
    public String atacar(Pokemon enemigo) {
        String mensajeAtaque = estrategia.atacar(this.nombre, enemigo.getNombre());
        return mensajeAtaque;
    }

    // Permite cambiar la estrategia de ataque en cualquier momento
    public void setEstrategia(AtaqueStrategy estrategia) {
        this.estrategia = estrategia;
    }

    // Devuelve el nombre del Pokemon
    public String getNombre() {
        return nombre;
    }
}
