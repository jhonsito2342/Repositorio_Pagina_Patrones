package co.edu.udistrital.model;

import co.edu.udistrital.model.strategy.AtaqueStrategy;

public class AtaqueNormal implements AtaqueStrategy{

	// Implementa el método atacar del Strategy, específico para ataque de tipo normal.
	@Override
	public String atacar(String atacante, String objetivo) {
		String mensaje = atacante + " golpea con un ataque normal a " + objetivo + ".\n";
		return mensaje;
	}

}
