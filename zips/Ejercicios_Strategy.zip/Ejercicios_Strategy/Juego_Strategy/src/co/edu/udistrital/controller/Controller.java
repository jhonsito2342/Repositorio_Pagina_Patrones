package co.edu.udistrital.controller;

import co.edu.udistrital.model.AtaqueAgua;
import co.edu.udistrital.model.AtaqueFuego;
import co.edu.udistrital.model.AtaqueNormal;
import co.edu.udistrital.model.AtaquePlanta;
import co.edu.udistrital.model.Pokemon;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

	private VistaConsola vista;
	
	public Controller() {
		// Inicializa la vista por consola
		vista = new VistaConsola();
	}
	
	public void run() {
		// Se crean los Pokemon con sus ataques iniciales
		Pokemon charmander = new Pokemon("Charmander", new AtaqueFuego());
        Pokemon squirtle = new Pokemon("Squirtle", new AtaqueAgua());
        
        Pokemon pidgey = new Pokemon("Pidgey", new AtaqueNormal());
        Pokemon treecko = new Pokemon("Treecko", new AtaquePlanta());

     // Se inician los combates
        iniciarCombate(charmander, squirtle);
        iniciarCombate(treecko,pidgey);
	}
	
	
	public void iniciarCombate(Pokemon p1, Pokemon p2) {
		String combate;
		// Mensaje de inicio
		vista.mostrarInformacion("Comienza el combate entre " + p1.getNombre() + " y " + p2.getNombre() + "\n");
        
		// Turno 1: cada Pokémon ataca
		vista.mostrarInformacion("Turno 1:\n");
        combate = p1.atacar(p2);
        combate += p2.atacar(p1);
        vista.mostrarInformacion(combate);
        
        // Turno 2: se cambian las estrategias (ataques)
        vista.mostrarInformacion("Turno 2: Cambian estrategias\n");
        p1.setEstrategia(new AtaquePlanta());
        p2.setEstrategia(new AtaqueFuego());
        
        combate = p1.atacar(p2);
        combate += p2.atacar(p1);
        vista.mostrarInformacion(combate);

        vista.mostrarInformacion("Fin del combate\n");
	}
}
