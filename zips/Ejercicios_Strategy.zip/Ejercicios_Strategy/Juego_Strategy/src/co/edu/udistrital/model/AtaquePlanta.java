package co.edu.udistrital.model;

import co.edu.udistrital.model.strategy.AtaqueStrategy;

public class AtaquePlanta implements AtaqueStrategy{

	// Implementa el método atacar del Strategy, específico para ataque de tipo planta.
	@Override
	public String atacar(String atacante, String objetivo) {
		String mensaje = atacante + " usa látigo cepa contra "  + objetivo + "!\n";
		return mensaje;
	}

}
