/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package context;

import strategy.PaymentStrategy;

public class PaymentProcessor {
    private PaymentStrategy strategy;
    
    public void setPaymentStrategy(PaymentStrategy strategy) {
        this.strategy = strategy;
    }
    
    public void executePayment(double amount) {
        if(strategy != null) {
            strategy.processPayment(amount);
            System.out.println("Detalles: " + strategy.getPaymentDetails());
        } else {
            System.out.println("Estrategia de pago no configurada");
        }
    }
}