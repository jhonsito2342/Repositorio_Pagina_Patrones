/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

import context.PaymentProcessor;
import strategy.*;

public class Main {

    public static void main(String[] args) {
        PaymentProcessor processor = new PaymentProcessor();

        // Pago con tarjeta de crédito
        processor.setPaymentStrategy(
                new CreditCardStrategy("Juan Pérez", "1234567812345678", "123", "12/25")
        );
        processor.executePayment(100.50);

        System.out.println();

        // Pago con PayPal
        processor.setPaymentStrategy(
                new PayPalStrategy("juan@example.com", "pass123")
        );
        processor.executePayment(75.99);

        System.out.println();

        // Pago con criptomoneda
        processor.setPaymentStrategy(
                new CryptoStrategy("1A2b3C4d5E6f7G8h9I0j", "Bitcoin")
        );
        processor.executePayment(0.005);
    }
}
