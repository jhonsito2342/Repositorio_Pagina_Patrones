/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package strategy;

public class CryptoStrategy implements PaymentStrategy {

    private String walletAddress;
    private String cryptoType;

    public CryptoStrategy(String walletAddress, String cryptoType) {
        this.walletAddress = walletAddress;
        this.cryptoType = cryptoType;
    }

    @Override
    public void processPayment(double amount) {
        System.out.printf("Procesando pago con %s de %.4f\n", cryptoType, amount);
        // Lógica real de procesamiento...
    }

    @Override
    public String getPaymentDetails() {
        return cryptoType + " wallet: " + walletAddress.substring(0, 8) + "...";
    }
}
