/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package strategy;

import java.io.File;

public interface CompressionStrategy {
    void compressFile(File file);
    String getAlgorithmName();
}