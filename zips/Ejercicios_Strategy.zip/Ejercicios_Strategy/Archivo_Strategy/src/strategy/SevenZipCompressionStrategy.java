/*
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package strategy;

import java.io.File;

public class SevenZipCompressionStrategy implements CompressionStrategy {

    @Override
    public void compressFile(File file) {
        System.out.println("Comprimiendo " + file.getName() + " usando 7Z");
        // Lógica real de compresión...
    }

    @Override
    public String getAlgorithmName() {
        return "7-Zip";
    }
}
