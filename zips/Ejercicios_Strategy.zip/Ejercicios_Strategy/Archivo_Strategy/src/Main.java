/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

import context.FileCompressor;
import strategy.*;
import java.io.File;

public class Main {

    public static void main(String[] args) {
        FileCompressor compressor = new FileCompressor();
        File file = new File("documento.txt");

        // Compresión ZIP
        compressor.setCompressionStrategy(new ZipCompressionStrategy());
        compressor.compress(file);

        System.out.println();

        // Compresión RAR
        compressor.setCompressionStrategy(new RarCompressionStrategy());
        compressor.compress(file);

        System.out.println();

        // Compresión 7Z
        compressor.setCompressionStrategy(new SevenZipCompressionStrategy());
        compressor.compress(file);
    }
}
