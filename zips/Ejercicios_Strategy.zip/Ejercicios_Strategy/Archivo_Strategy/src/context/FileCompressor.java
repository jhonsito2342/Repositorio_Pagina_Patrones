/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package context;

import strategy.CompressionStrategy;
import java.io.File;

public class FileCompressor {

    private CompressionStrategy strategy;

    public void setCompressionStrategy(CompressionStrategy strategy) {
        this.strategy = strategy;
    }

    public void compress(File file) {
        if (strategy != null) {
            System.out.println("Iniciando compresión con " + strategy.getAlgorithmName());
            strategy.compressFile(file);
            System.out.println("Compresión completada");
        } else {
            System.out.println("Estrategia de compresión no configurada");
        }
    }
}
