/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.*;
import vista.DocumentView;

public class DocumentController {
    private DocumentView view;

    public DocumentController() {
        this.view = new DocumentView();
        processDocuments();
    }

    private void processDocuments() {
        Document pdfDoc = new Document("informe.pdf", "confidencial");
        Document wordDoc = new Document("contrato.docx", "normal");

        DocumentProcessor pdfProcessor = new PDFProcessor();
        DocumentProcessor wordProcessor = new WordProcessor();

        view.showMessage("\nProcesando PDF:");
        pdfProcessor.processDocument(pdfDoc);

        view.showMessage("\nProcesando Word:");
        wordProcessor.processDocument(wordDoc);
    }
}