/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public abstract class DocumentProcessor {

    // Método template (final para evitar sobrescritura)
    public final void processDocument(Document doc) {
        openDocument(doc);
        readContent();
        parseContent();
        if (needsEncryption()) {
            encrypt();
        }
        save();
        closeDocument();
    }

    // Métodos abstractos que las subclases deben implementar
    protected abstract void openDocument(Document doc);

    protected abstract void readContent();

    protected abstract void parseContent();

    protected abstract void save();

    // Métodos concretos con implementación por defecto
    protected void closeDocument() {
        System.out.println("Cerrando documento...");
    }

    // Hook method - puede ser sobrescrito
    protected boolean needsEncryption() {
        return false;
    }

    protected void encrypt() {
        System.out.println("Encriptando contenido...");
    }
}
