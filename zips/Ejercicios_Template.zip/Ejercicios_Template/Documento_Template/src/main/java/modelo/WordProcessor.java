/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class WordProcessor extends DocumentProcessor {
    private Document currentDoc;

    @Override
    protected void openDocument(Document doc) {
        this.currentDoc = doc;
        System.out.println("Abriendo documento Word: " + doc.getFileName());
    }

    @Override
    protected void readContent() {
        System.out.println("Leyendo contenido Word...");
    }

    @Override
    protected void parseContent() {
        System.out.println("Parseando formato Word...");
    }

    @Override
    protected void save() {
        System.out.println("Guardando documento Word: " + currentDoc.getFileName());
    }
}