/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class PDFProcessor extends DocumentProcessor {

    private Document currentDoc;

    @Override
    protected void openDocument(Document doc) {
        this.currentDoc = doc;
        System.out.println("Abriendo PDF: " + doc.getFileName());
    }

    @Override
    protected void readContent() {
        System.out.println("Leyendo contenido PDF...");
    }

    @Override
    protected void parseContent() {
        System.out.println("Parseando estructura PDF...");
    }

    @Override
    protected void save() {
        System.out.println("Guardando PDF: " + currentDoc.getFileName());
    }

    @Override
    protected boolean needsEncryption() {
        return currentDoc.getFileType().equals("confidencial");
    }
}
