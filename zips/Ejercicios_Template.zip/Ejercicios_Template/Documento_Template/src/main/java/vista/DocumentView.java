/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

public class DocumentView {
    public void showMessage(String message) {
        System.out.println(message);
    }

    public void showProcessingResult(String docType, String result) {
        System.out.println("Procesamiento de " + docType + ": " + result);
    }
}