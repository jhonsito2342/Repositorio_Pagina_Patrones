/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.*;
import vista.BeverageView;

public class BeverageController {

    private BeverageView view;

    public BeverageController() {
        this.view = new BeverageView();
        prepareBeverages();
    }

    private void prepareBeverages() {
        view.showPreparation("café");
        BeverageMaker coffeeMaker = new CoffeeMaker();
        Beverage coffee = coffeeMaker.makeBeverage();
        view.showBeverageReady(coffee);

        view.showPreparation("té");
        BeverageMaker teaMaker = new TeaMaker();
        Beverage tea = teaMaker.makeBeverage();
        view.showBeverageReady(tea);
    }
}
