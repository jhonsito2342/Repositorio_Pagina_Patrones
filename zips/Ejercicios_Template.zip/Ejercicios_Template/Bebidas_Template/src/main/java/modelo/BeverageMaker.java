/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public abstract class BeverageMaker {

    // Método template
    public final Beverage makeBeverage() {
        boilWater();
        brew();
        pourInCup();
        if (customerWantsCondiments()) {
            addCondiments();
        }
        return createBeverage();
    }

    protected abstract void brew();

    protected abstract void addCondiments();

    protected abstract Beverage createBeverage();

    protected void boilWater() {
        System.out.println("Hirviendo agua...");
    }

    protected void pourInCup() {
        System.out.println("Sirviendo en la taza...");
    }

    // Hook method
    protected boolean customerWantsCondiments() {
        return true;
    }
}
