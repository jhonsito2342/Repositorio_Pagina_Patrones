/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class CoffeeMaker extends BeverageMaker {

    private Beverage coffee;

    @Override
    protected void brew() {
        System.out.println("Preparando café...");
    }

    @Override
    protected void addCondiments() {
        System.out.println("Añadiendo azúcar y leche...");
    }

    @Override
    protected Beverage createBeverage() {
        this.coffee = new Beverage("Café", 95);
        return coffee;
    }

    @Override
    protected boolean customerWantsCondiments() {
        // Simulando preferencia del cliente
        return Math.random() > 0.3; // 70% de probabilidad de querer condimentos
    }
}
