/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class TeaMaker extends BeverageMaker {

    private Beverage tea;

    @Override
    protected void brew() {
        System.out.println("Preparando té...");
    }

    @Override
    protected void addCondiments() {
        System.out.println("Añadiendo limón...");
    }

    @Override
    protected Beverage createBeverage() {
        this.tea = new Beverage("Té", 85);
        return tea;
    }
}
