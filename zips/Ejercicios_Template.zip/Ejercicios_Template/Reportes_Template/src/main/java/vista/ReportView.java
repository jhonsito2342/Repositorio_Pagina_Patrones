/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

public class ReportView {

    public void showReportGeneration(String reportType) {
        System.out.println("\nGenerando reporte de " + reportType + "...");
    }

    public void showCompletionMessage(String reportType) {
        System.out.println("Reporte de " + reportType + " completado exitosamente");
    }
}
