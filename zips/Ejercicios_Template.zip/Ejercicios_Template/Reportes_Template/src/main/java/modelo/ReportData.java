/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class ReportData {

    private int recordCount;
    private String reportType;

    public ReportData(int recordCount, String reportType) {
        this.recordCount = recordCount;
        this.reportType = reportType;
    }

    public int getRecordCount() {
        return recordCount;
    }

    public String getReportType() {
        return reportType;
    }
}
