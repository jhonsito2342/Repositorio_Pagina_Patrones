/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class InventoryReportGenerator extends ReportGenerator {
    private ReportData currentData;

    @Override
    protected void prepareData(ReportData data) {
        this.currentData = data;
        System.out.println("Preparando datos de inventario...");
    }

    @Override
    protected void createHeader() {
        System.out.println("Creando encabezado para reporte de inventario...");
    }

    @Override
    protected void createBody() {
        System.out.println("Generando cuerpo del reporte de inventario con " + 
                         currentData.getRecordCount() + " items...");
    }

    @Override
    protected void saveReport() {
        System.out.println("Guardando reporte de inventario como CSV...");
    }
}