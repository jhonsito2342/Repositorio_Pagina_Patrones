/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class SalesReportGenerator extends ReportGenerator {
    private ReportData currentData;

    @Override
    protected void prepareData(ReportData data) {
        this.currentData = data;
        System.out.println("Preparando datos de ventas...");
    }

    @Override
    protected void createHeader() {
        System.out.println("Creando encabezado para reporte de ventas...");
    }

    @Override
    protected void createBody() {
        System.out.println("Generando cuerpo del reporte de ventas con " + 
                         currentData.getRecordCount() + " registros...");
    }

    @Override
    protected void saveReport() {
        System.out.println("Guardando reporte de ventas como PDF...");
    }

    @Override
    protected boolean needsFooter() {
        return currentData.getRecordCount() > 10;
    }
}