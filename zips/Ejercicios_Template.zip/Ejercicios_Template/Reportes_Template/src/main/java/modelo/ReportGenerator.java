/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public abstract class ReportGenerator {
    // Método template
    public final void generateReport(ReportData data) {
        prepareData(data);
        createHeader();
        createBody();
        if (needsFooter()) {
            createFooter();
        }
        formatReport();
        saveReport();
    }

    protected abstract void prepareData(ReportData data);
    protected abstract void createHeader();
    protected abstract void createBody();
    protected abstract void saveReport();

    protected void createFooter() {
        System.out.println("Generando pie de página estándar...");
    }

    protected void formatReport() {
        System.out.println("Formateando reporte...");
    }

    // Hook method
    protected boolean needsFooter() {
        return true;
    }
}