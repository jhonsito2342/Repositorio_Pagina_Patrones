/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.*;
import vista.ReportView;

public class ReportController {
    private ReportView view;

    public ReportController() {
        this.view = new ReportView();
        generateReports();
    }

    private void generateReports() {
        ReportData salesData = new ReportData(15, "ventas");
        ReportData inventoryData = new ReportData(8, "inventario");

        view.showReportGeneration("ventas");
        ReportGenerator salesReport = new SalesReportGenerator();
        salesReport.generateReport(salesData);
        view.showCompletionMessage("ventas");

        view.showReportGeneration("inventario");
        ReportGenerator inventoryReport = new InventoryReportGenerator();
        inventoryReport.generateReport(inventoryData);
        view.showCompletionMessage("inventario");
    }
}