package model;

import java.util.HashMap; // //Estructura de datos que permite almacenar pares clave-valor
import java.util.Map; // Se utiliza para declarar variables o métodos de forma más genérica
import view.VistaConsola;

public class CarFactory {

    private static Map<String, CarType> carTypes = new HashMap<>(); // Lista donde se van a agregar los carros
    private static VistaConsola vista=new VistaConsola();

    // Método para obtener el CarType, reutilizando los existentes o creando nuevos
    public static CarType getCarType(String model, String engineType, String color) {

        String key = model + ":" + engineType + ":" + color;

        // Si ya existe un CarType con los mismos atributos, lo reutiliza
        if (!carTypes.containsKey(key)) {
            carTypes.put(key, new CarType(model, engineType, color));
            vista.mostrarInformacion("\nCreando nuevo tipo de carro: " + model);
        }

        return carTypes.get(key);

    }

}
