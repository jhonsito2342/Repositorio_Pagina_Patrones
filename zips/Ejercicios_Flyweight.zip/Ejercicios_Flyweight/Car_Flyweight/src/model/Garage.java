package model;

import java.util.ArrayList;
import java.util.List;

public class Garage {

    private List<Car> cars = new ArrayList<>();

    // Método para agregar un carro al garaje
    public void addCar(String licensePlate, int x, int y, String model, String engineType, String color) {
        // Verifica si ya se ha creado un objeto de CarType con el método de CarFactory 
        CarType carType = CarFactory.getCarType(model, engineType, color);
        // Crea un nuevo carro con atributos específicos
        Car car = new Car(licensePlate, x, y, carType);
        cars.add(car);
    }

    // Método para dibujar todos los carros en el garaje
    public void drawCars() {
        for (Car car : cars) {
            car.draw();
        }
    }

}
