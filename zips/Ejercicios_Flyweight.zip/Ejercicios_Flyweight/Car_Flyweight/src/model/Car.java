package model;

public class Car { // Contiene los atributos que son únicos para cada carro

	private String licensePlate; 
	private int x, y; 
	private CarType carType; 

	public Car(String licensePlate, int x, int y, CarType carType) {
		this.licensePlate = licensePlate;
		this.x = x;
		this.y = y;
		this.carType = carType;
	}

	// Método para dibujar el carro en la ubicación dada
	public void draw() {
		carType.draw(licensePlate, x, y);
	}

}
