package model;

import view.VistaConsola;

public class CarType { // Contiene los atributos que cualquier carro puede compartir

	private String model;
	private String engineType;
	private String color;
    private VistaConsola vista;

	public CarType(String model, String engineType, String color) {
		this.model = model;
		this.engineType = engineType;
		this.color = color;
        vista=new VistaConsola();
	}

	public String getModel() {
		return model;
	}

	public String getEngineType() {
		return engineType;
	}

	public String getColor() {
		return color;
	}

	// Método que simula dibujar el carro en una ubicación
	public void draw(String licensePlate, int x, int y) {
		vista.mostrarInformacion("Dibujando " + model + " con matrícula " + licensePlate + " en la posición: (" + x + ", " + y
				+ ") - Motor: " + engineType + " - Color: " + color);
	}

}
