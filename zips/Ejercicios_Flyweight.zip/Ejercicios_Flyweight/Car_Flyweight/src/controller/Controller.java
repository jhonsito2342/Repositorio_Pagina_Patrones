package controller;

import model.Garage;
import view.VistaConsola;

public class Controller {

    private Garage garage;
    private VistaConsola vista;

    public void run () {

        garage = new Garage();
        vista=new VistaConsola();
        byte option;
        String licensePlate, model, engineType, color;
        int x,y;

        do { 

            option=Byte.parseByte(vista.leerTexto("\nDijita la opción que desees realizar:\n1. Agregar un nuevo carro a tu garaje\n2. Ver todos los carros de tu garage\n3. Salir\n\n"));

            switch (option) {
                case 1-> {
                    licensePlate=vista.leerTexto("\n¿Cuál es la placa de tu carro? ");
                    x=Integer.parseInt(vista.leerTexto("¿En qué posición de X esta tu carro? "));
                    y=Integer.parseInt(vista.leerTexto("¿En qué posición de Y esta tu carro? "));
                    model=vista.leerTexto("¿Cuál es el módelo de tu carro? ");
                    engineType=vista.leerTexto("¿Cuál es el tipo de motor de tu carro? ");
                    color=vista.leerTexto("¿Cuál es el color de tu carro? ");
                    garage.addCar(licensePlate, x, y, model, engineType, color);
                    break;
                }
                case 2-> {
                    garage.drawCars();
                    break;
                }
                case 3-> {
                    vista.mostrarInformacion("Gracias por tu visita");
                    break;
                }
            }
        } while (option!=3);
        System.exit(0);

    }

}
