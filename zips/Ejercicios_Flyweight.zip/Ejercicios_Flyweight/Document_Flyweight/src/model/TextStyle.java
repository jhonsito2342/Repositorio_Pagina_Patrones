/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

// Flyweight
public class TextStyle {

    private final String font;
    private final int size;
    private final boolean bold;
    private final boolean italic;
    private final String color;

    public TextStyle(String font, int size, boolean bold, boolean italic, String color) {
        this.font = font;
        this.size = size;
        this.bold = bold;
        this.italic = italic;
        this.color = color;
    }

    public void applyStyle(char character) {
        System.out.printf("%c [Font: %s, Size: %d, Bold: %b, Italic: %b, Color: %s]\n",
                character, font, size, bold, italic, color);
    }
}
