/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.HashMap;
import java.util.Map;

public class StyleFactory {
    private static Map<String, TextStyle> styles = new HashMap<>();
    
    public static TextStyle getStyle(String font, int size, 
                                   boolean bold, boolean italic, String color) {
        String key = font + size + bold + italic + color;
        if(!styles.containsKey(key)) {
            styles.put(key, new TextStyle(font, size, bold, italic, color));
        }
        return styles.get(key);
    }
    
    public static int getTotalStyles() {
        return styles.size();
    }
}