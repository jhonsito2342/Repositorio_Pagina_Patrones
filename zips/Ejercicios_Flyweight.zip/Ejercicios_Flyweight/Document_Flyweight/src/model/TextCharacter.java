/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

public class TextCharacter {

    private char character;
    private TextStyle style;

    public TextCharacter(char character, TextStyle style) {
        this.character = character;
        this.style = style;
    }

    public void display() {
        style.applyStyle(character);
    }
}
