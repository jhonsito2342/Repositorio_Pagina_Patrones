/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package controller;

/**
 *
 * @author Jhon
 */
public class Main {

    public static void main(String[] args) {
        DocumentController controller = new DocumentController();

        // Texto con estilos específicos
        controller.addText("Flyweight", "Arial", 14, true, false, "Blue");
        controller.addText(" pattern ", "Times New Roman", 12, false, true, "Black");
        controller.addText("example", "Courier New", 16, true, true, "Red");

        // Generar documento aleatorio
        controller.generateRandomDocument(500);

        // Renderizar documento
        controller.renderDocument();
    }
}
