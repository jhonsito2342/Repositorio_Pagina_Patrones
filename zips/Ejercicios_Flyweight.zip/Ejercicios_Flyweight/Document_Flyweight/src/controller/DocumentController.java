/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import model.*;
import view.DocumentView;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class DocumentController {

    private List<TextCharacter> characters = new ArrayList<>();
    private DocumentView view = new DocumentView();
    private Random random = new Random();

    public void addText(String text, String font, int size,
            boolean bold, boolean italic, String color) {
        TextStyle style = StyleFactory.getStyle(font, size, bold, italic, color);
        for (char c : text.toCharArray()) {
            characters.add(new TextCharacter(c, style));
        }
    }

    public void generateRandomDocument(int length) {
        String[] fonts = {"Arial", "Times New Roman", "Courier New"};
        String[] colors = {"Black", "Red", "Blue", "Green"};

        for (int i = 0; i < length; i++) {
            String font = fonts[random.nextInt(fonts.length)];
            String color = colors[random.nextInt(colors.length)];
            TextStyle style = StyleFactory.getStyle(font, 12,
                    random.nextBoolean(), random.nextBoolean(), color);

            characters.add(new TextCharacter((char) (random.nextInt(26) + 'a'), style));
        }
    }

    public void renderDocument() {
        view.displayDocument(characters, StyleFactory.getTotalStyles());
    }
}
