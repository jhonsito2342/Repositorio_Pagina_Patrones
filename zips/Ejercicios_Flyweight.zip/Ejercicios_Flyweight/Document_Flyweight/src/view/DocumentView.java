/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import model.TextCharacter;
import java.util.List;

public class DocumentView {

    public void displayDocument(List<TextCharacter> chars, int totalStyles) {
        System.out.println("\n=== DOCUMENTO FORMATEADO ===");
        chars.forEach(TextCharacter::display);
        System.out.println("\nTotal de caracteres: " + chars.size());
        System.out.println("Estilos únicos utilizados: " + totalStyles);
        System.out.println("Memoria optimizada con Flyweight!");
    }
}
