/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import model.*;
import view.ForestView;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ForestController {

    private List<Tree> trees = new ArrayList<>();
    private ForestView view = new ForestView();
    private Random random = new Random();

    public void plantTree(String name, String color, String texture, int x, int y) {
        TreeType type = TreeTypeFactory.getTreeType(name, color, texture);
        trees.add(new Tree(x, y, type));
    }

    public void generateRandomForest(int count) {
        String[] types = {"Roble", "Pino", "Abeto", "Sauce"};
        String[] colors = {"Verde", "Verde Oscuro", "Verde Claro"};

        for (int i = 0; i < count; i++) {
            String type = types[random.nextInt(types.length)];
            String color = colors[random.nextInt(colors.length)];
            plantTree(type, color, "Textura_" + type,
                    random.nextInt(100), random.nextInt(100));
        }
    }

    public void renderForest() {
        view.displayForest(trees, TreeTypeFactory.getTotalTypes());
    }
}
