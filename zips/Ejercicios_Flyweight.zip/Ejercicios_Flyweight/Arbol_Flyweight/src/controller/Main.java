/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package controller;

/**
 *
 * @author Jhon
 */
public class Main {

    public static void main(String[] args) {
        ForestController controller = new ForestController();

        // Plantar algunos árboles manualmente
        controller.plantTree("Roble", "Verde", "Textura_Roble", 10, 20);
        controller.plantTree("Pino", "Verde Oscuro", "Textura_Pino", 30, 40);
        controller.plantTree("Roble", "Verde", "Textura_Roble", 50, 60); // Mismo tipo

        // Generar bosque aleatorio
        controller.generateRandomForest(1000);

        // Renderizar
        controller.renderForest();
    }
}
