/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import model.Tree;
import java.util.List;

public class ForestView {

    public void displayForest(List<Tree> trees, int totalTypes) {
        System.out.println("\n=== BOSQUE RENDERIZADO ===");
        trees.forEach(Tree::draw);
        System.out.println("\nTotal de árboles: " + trees.size());
        System.out.println("Tipos únicos de árboles: " + totalTypes);
        System.out.println("Memoria optimizada con Flyweight!");
    }
}
