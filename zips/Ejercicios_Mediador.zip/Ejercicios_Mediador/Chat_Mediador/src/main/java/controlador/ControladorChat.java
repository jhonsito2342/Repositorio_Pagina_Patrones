/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.MediadorChat;
import modelo.Usuario;
import vista.VistaChat;

public class ControladorChat {
    private MediadorChat mediador;
    private VistaChat vista;

    public ControladorChat() {
        this.vista = new VistaChat();
        this.mediador = new MediadorChat(this);
        
        Usuario usuario1 = new Usuario("Ana", mediador);
        Usuario usuario2 = new Usuario("Carlos", mediador);
        
        usuario1.enviarMensaje("Hola a todos!");
        usuario2.enviarMensaje("Hola Ana, ¿cómo estás?");
        usuario1.enviarMensaje("Bien, gracias!");
    }

    public void mostrarMensaje(String mensaje) {
        vista.mostrarMensaje(mensaje);
    }
}