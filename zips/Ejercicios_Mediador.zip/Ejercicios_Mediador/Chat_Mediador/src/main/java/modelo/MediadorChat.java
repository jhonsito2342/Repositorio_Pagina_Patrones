/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import controlador.ControladorChat;
import java.util.ArrayList;
import java.util.List;

public class MediadorChat {

    private List<Usuario> usuarios;
    private ControladorChat controlador;

    public MediadorChat(ControladorChat controlador) {
        this.usuarios = new ArrayList<>();
        this.controlador = controlador;
    }

    public void registrarUsuario(Usuario usuario) {
        usuarios.add(usuario);
        controlador.mostrarMensaje("Usuario registrado: " + usuario.getNombre());
    }

    public void enviarMensaje(Mensaje mensaje) {
        for (Usuario usuario : usuarios) {
            if (!usuario.equals(mensaje.getRemitente())) {
                usuario.recibirMensaje(mensaje);
            }
        }
        controlador.mostrarMensaje(mensaje.getRemitente().getNombre() + ": " + mensaje.getTexto());
    }
}
