/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class Mensaje {

    private Usuario remitente;
    private String texto;

    public Mensaje(Usuario remitente, String texto) {
        this.remitente = remitente;
        this.texto = texto;
    }

    public Usuario getRemitente() {
        return remitente;
    }

    public String getTexto() {
        return texto;
    }
}
