/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class Usuario {

    private String nombre;
    private MediadorChat mediador;

    public Usuario(String nombre, MediadorChat mediador) {
        this.nombre = nombre;
        this.mediador = mediador;
        mediador.registrarUsuario(this);
    }

    public void enviarMensaje(String texto) {
        Mensaje mensaje = new Mensaje(this, texto);
        mediador.enviarMensaje(mensaje);
    }

    public void recibirMensaje(Mensaje mensaje) {
        System.out.println(nombre + " recibió mensaje de "
                + mensaje.getRemitente().getNombre() + ": "
                + mensaje.getTexto());
    }

    public String getNombre() {
        return nombre;
    }
}
