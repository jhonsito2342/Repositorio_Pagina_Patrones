/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import controlador.ControladorReservas;
import java.util.ArrayList;
import java.util.List;

public class MediadorReservas {

    private List<Vuelo> vuelos = new ArrayList<>();
    private ControladorReservas controlador;

    public MediadorReservas(ControladorReservas controlador) {
        this.controlador = controlador;
        // Vuelos de ejemplo
        vuelos.add(new Vuelo("V001", "Nueva York", "Londres", 200));
        vuelos.add(new Vuelo("V002", "Madrid", "París", 150));
    }

    public void hacerReserva(Pasajero pasajero, String vueloId) {
        Vuelo vuelo = buscarVuelo(vueloId);
        if (vuelo != null && vuelo.reservarAsiento()) {
            Reserva reserva = new Reserva(pasajero, vuelo);
            controlador.mostrarMensaje("Reserva exitosa para " + pasajero.getNombre()
                    + " en vuelo " + vueloId);
        } else {
            controlador.mostrarMensaje("No hay asientos disponibles en " + vueloId);
        }
    }

    private Vuelo buscarVuelo(String id) {
        for (Vuelo v : vuelos) {
            if (v.getId().equals(id)) {
                return v;
            }
        }
        return null;
    }
}
