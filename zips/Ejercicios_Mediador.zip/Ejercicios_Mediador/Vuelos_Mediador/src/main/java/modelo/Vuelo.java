/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class Vuelo {
    private String id;
    private String origen;
    private String destino;
    private int asientos;

    public Vuelo(String id, String origen, String destino, int asientos) {
        this.id = id;
        this.origen = origen;
        this.destino = destino;
        this.asientos = asientos;
    }

    public synchronized boolean reservarAsiento() {
        if (asientos > 0) {
            asientos--;
            return true;
        }
        return false;
    }

    public String getId() { return id; }
    public String getOrigen() { return origen; }
    public String getDestino() { return destino; }
}