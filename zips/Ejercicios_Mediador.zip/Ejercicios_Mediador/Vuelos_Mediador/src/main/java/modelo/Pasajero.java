/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class Pasajero {
    private String nombre;
    private MediadorReservas mediador;

    public Pasajero(String nombre, MediadorReservas mediador) {
        this.nombre = nombre;
        this.mediador = mediador;
    }

    public void reservarVuelo(String vueloId) {
        mediador.hacerReserva(this, vueloId);
    }

    public String getNombre() { return nombre; }
}