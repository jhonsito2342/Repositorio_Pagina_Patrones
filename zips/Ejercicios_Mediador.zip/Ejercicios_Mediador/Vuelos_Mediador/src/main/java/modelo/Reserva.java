/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
*/
package modelo;

public class Reserva {
    private Pasajero pasajero;
    private Vuelo vuelo;

    public Reserva(Pasajero pasajero, Vuelo vuelo) {
        this.pasajero = pasajero;
        this.vuelo = vuelo;
    }

    public Pasajero getPasajero() { return pasajero; }
    public Vuelo getVuelo() { return vuelo; }
}