/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.MediadorReservas;
import modelo.Pasajero;
import vista.VistaReservas;

public class ControladorReservas {

    private MediadorReservas mediador;
    private VistaReservas vista;

    public ControladorReservas() {
        this.vista = new VistaReservas();
        this.mediador = new MediadorReservas(this);

        // Ejemplo de uso
        Pasajero juan = new Pasajero("Juan", mediador);
        Pasajero maria = new Pasajero("María", mediador);

        juan.reservarVuelo("V001");
        maria.reservarVuelo("V001");
        juan.reservarVuelo("V002");
    }

    public void mostrarMensaje(String mensaje) {
        vista.mostrarMensaje(mensaje);
    }
}
