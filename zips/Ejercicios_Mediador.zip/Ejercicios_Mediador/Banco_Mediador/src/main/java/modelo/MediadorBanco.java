/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import controlador.ControladorBanco;
import java.util.HashMap;
import java.util.Map;

public class MediadorBanco {

    private Map<String, Cuenta> cuentas = new HashMap<>();
    private ControladorBanco controlador;

    public MediadorBanco(ControladorBanco controlador) {
        this.controlador = controlador;
    }

    public void registrarCuenta(Cuenta cuenta) {
        cuentas.put(cuenta.getNumero(), cuenta);
    }

    public void transferir(String origen, String destino, double monto) {
        Cuenta cuentaOrigen = cuentas.get(origen);
        Cuenta cuentaDestino = cuentas.get(destino);

        if (cuentaOrigen == null || cuentaDestino == null) {
            controlador.mostrarMensaje("Cuenta no encontrada");
            return;
        }

        // Ordenar cuentas para prevenir deadlock
        Cuenta primera = origen.compareTo(destino) < 0 ? cuentaOrigen : cuentaDestino;
        Cuenta segunda = primera == cuentaOrigen ? cuentaDestino : cuentaOrigen;

        synchronized (primera) {
            synchronized (segunda) {
                if (cuentaOrigen.retirar(monto)) {
                    cuentaDestino.depositar(monto);
                    Transaccion t = new Transaccion(origen, destino, monto);
                    controlador.mostrarMensaje("Transferencia exitosa: " + monto);
                } else {
                    controlador.mostrarMensaje("Fondos insuficientes");
                }
            }
        }
    }
}
