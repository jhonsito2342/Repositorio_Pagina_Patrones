/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */package controlador;

import modelo.*;
import vista.VistaBanco;

public class ControladorBanco {

    private MediadorBanco mediador;
    private VistaBanco vista;

    public ControladorBanco() {
        this.vista = new VistaBanco();
        this.mediador = new MediadorBanco(this);

        // Configuración inicial
        Cliente cliente1 = new Cliente("12345678", "Ana García");
        Cliente cliente2 = new Cliente("87654321", "Carlos López");

        Cuenta cuenta1 = new Cuenta("CT001", cliente1, 1000);
        Cuenta cuenta2 = new Cuenta("CT002", cliente2, 500);

        mediador.registrarCuenta(cuenta1);
        mediador.registrarCuenta(cuenta2);

        // Ejemplo de transferencias
        mediador.transferir("CT001", "CT002", 200);
        mediador.transferir("CT002", "CT001", 100);
        mediador.transferir("CT001", "CT002", 1500); // Debe fallar
    }

    public void mostrarMensaje(String mensaje) {
        vista.mostrarMensaje(mensaje);
    }
}
