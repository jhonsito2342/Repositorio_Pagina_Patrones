/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package handlers;

import model.ReimbursementRequest;
import utils.RequestType;

public class DirectorHandler implements ApprovalHandler {

    private ApprovalHandler nextHandler;
    private final double APPROVAL_LIMIT = 5000;

    @Override
    public void setNextHandler(ApprovalHandler nextHandler) {
        this.nextHandler = nextHandler;
    }

    @Override
    public void processRequest(ReimbursementRequest request) {
        if (request.getAmount() <= APPROVAL_LIMIT) {
            System.out.printf("Director approved %s request for $%.2f from employee %s\n",
                    request.getType(), request.getAmount(), request.getEmployeeId());
        } else if (nextHandler != null) {
            nextHandler.processRequest(request);
        }
    }
}
