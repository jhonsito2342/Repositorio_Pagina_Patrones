/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package handlers;

/**
 *
 * @author Jhon
 */
import handlers.*;
import model.ReimbursementRequest;
import utils.RequestType;

public class Main {

    public static void main(String[] args) {
        // Configurar la cadena de responsabilidad
        ApprovalHandler manager = new ManagerHandler();
        ApprovalHandler director = new DirectorHandler();
        ApprovalHandler vp = new VPHandler();

        manager.setNextHandler(director);
        director.setNextHandler(vp);

        // Crear solicitudes
        ReimbursementRequest request1 = new ReimbursementRequest("EMP001", 800, RequestType.TRAVEL, "Conferencia anual");
        ReimbursementRequest request2 = new ReimbursementRequest("EMP002", 3500, RequestType.EQUIPMENT, "Nueva laptop");
        ReimbursementRequest request3 = new ReimbursementRequest("EMP003", 12000, RequestType.TRAINING, "Curso certificación");

        // Procesar solicitudes
        manager.processRequest(request1);
        System.out.println();
        manager.processRequest(request2);
        System.out.println();
        manager.processRequest(request3);
    }
}
