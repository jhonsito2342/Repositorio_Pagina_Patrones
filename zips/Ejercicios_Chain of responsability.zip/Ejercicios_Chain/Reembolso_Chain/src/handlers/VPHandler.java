/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package handlers;

import model.ReimbursementRequest;

public class VPHandler implements ApprovalHandler {

    private ApprovalHandler nextHandler;

    @Override
    public void setNextHandler(ApprovalHandler nextHandler) {
        this.nextHandler = nextHandler;
    }

    @Override
    public void processRequest(ReimbursementRequest request) {
        System.out.printf("VP approved %s request for $%.2f from employee %s\n",
                request.getType(), request.getAmount(), request.getEmployeeId());
    }
}
