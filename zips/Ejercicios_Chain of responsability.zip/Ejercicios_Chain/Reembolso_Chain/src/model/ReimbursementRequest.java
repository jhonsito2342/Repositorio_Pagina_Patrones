/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import utils.RequestType;

public class ReimbursementRequest {

    private String employeeId;
    private double amount;
    private RequestType type;
    private String description;

    public ReimbursementRequest(String employeeId, double amount, RequestType type, String description) {
        this.employeeId = employeeId;
        this.amount = amount;
        this.type = type;
        this.description = description;
    }

    // Getters
    public double getAmount() {
        return amount;
    }

    public RequestType getType() {
        return type;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public String getDescription() {
        return description;
    }
}
