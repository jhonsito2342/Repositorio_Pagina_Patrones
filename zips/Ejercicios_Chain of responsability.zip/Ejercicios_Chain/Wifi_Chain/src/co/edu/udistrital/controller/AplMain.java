package co.edu.udistrital.controller;

public class AplMain {
	
	public static void main(String []args) {
		
		Controller control;
		control = new Controller();
		control.run();
		
	}

}
