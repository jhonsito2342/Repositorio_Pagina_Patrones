package co.edu.udistrital.controller;

import co.edu.udistrital.model.IProblemaHandler;
import co.edu.udistrital.model.Problema;
import co.edu.udistrital.model.concreto.ValidacionHandler;
import co.edu.udistrital.model.concreto.SoporteHandler;
import co.edu.udistrital.model.concreto.TecnicoHandler;
import co.edu.udistrital.view.VistaConsola;

public class Controller {
	private VistaConsola vista;
	
	public Controller() {
		vista = new VistaConsola();
	}
	
	public void run() {
		
		String descripcion = vista.leerCadenaTexto("Describe tu problema:");
		Problema problema = new Problema(descripcion);
		
		IProblemaHandler validacion = new ValidacionHandler(vista);
		IProblemaHandler soporte = new SoporteHandler(vista);
		IProblemaHandler tecnico = new TecnicoHandler(vista);
		
		//Se relaciona la cadena
		validacion.setSiguiente(soporte).setSiguiente(tecnico);
		
		//Se inicia el proceso de manejo del problema
		validacion.ManejarProblema(problema);
		
	}

}
