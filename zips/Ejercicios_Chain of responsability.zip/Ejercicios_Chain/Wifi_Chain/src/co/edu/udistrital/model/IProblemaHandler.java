package co.edu.udistrital.model;

public interface IProblemaHandler {
	
	//Método que conecta al manejador con el siguiente
	IProblemaHandler setSiguiente(IProblemaHandler h);
	
	//Método que maneja la solicitud(problema)
	void ManejarProblema(Problema problema);
	

}
