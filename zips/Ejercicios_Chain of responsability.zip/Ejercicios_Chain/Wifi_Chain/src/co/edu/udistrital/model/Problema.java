package co.edu.udistrital.model;

public class Problema {
	private String descripcion;
	private boolean resuelto;
	
	public Problema(String descripcion) {
		
		this.descripcion = descripcion;
		this.resuelto=false;
	}


	public String getDescripcion() {
		return descripcion;
	}
	
	
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}


	public boolean isResuelto() {
		return resuelto;
	}

	public void setResuelto(boolean resuelto) {
		this.resuelto = resuelto;
	}
	
	

}
