package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.AProblema;
import co.edu.udistrital.model.Problema;
import co.edu.udistrital.view.VistaConsola;

public class TecnicoHandler extends AProblema{
	private VistaConsola vista;
	
	public TecnicoHandler(VistaConsola vista) {
		this.vista = vista;
		
	}

	@Override
	public void ManejarProblema(Problema problema) {
		vista.mostrarInformacion("Área Técnica: Espera mi llamada para agendar la visita");
		problema.setResuelto(true);
	}
	
	


}
