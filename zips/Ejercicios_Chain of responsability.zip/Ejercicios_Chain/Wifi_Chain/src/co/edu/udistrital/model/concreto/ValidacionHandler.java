package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.AProblema;
import co.edu.udistrital.model.Problema;
import co.edu.udistrital.view.VistaConsola;

public class ValidacionHandler extends AProblema{
	private VistaConsola vista;
	
	public ValidacionHandler(VistaConsola vista) {
		this.vista = vista;
	}

	@Override
	public void ManejarProblema(Problema problema) {
		 String descripcion = problema.getDescripcion().toLowerCase();

		 
	        if (descripcion.contains("no tengo internet") || descripcion.contains("sin internet")) {
	            vista.mostrarInformacion("Área de validación: Hola, Por favor intenta apagar y encender tu módem. ¿Se solucionó el problema?");
	            String respuesta = vista.leerCadenaTexto("Escribe 'sí' o 'no'");

	            if (respuesta.equalsIgnoreCase("sí") || respuesta.equalsIgnoreCase("si")) {
	                problema.setResuelto(true);
	                vista.mostrarInformacion("Área de validación: Tu problema ha sido solucionado con exito, adios");
	                return; 
	            }
	        }
	        vista.mostrarInformacion("CASO ESCALADO");
		super.ManejarProblema(problema);//Pasa al siguiente manejador
		//super clase pader(Aproblema)
	}
	
	





}
