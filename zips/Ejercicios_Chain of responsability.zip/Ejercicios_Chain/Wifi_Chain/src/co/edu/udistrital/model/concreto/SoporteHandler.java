package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.AProblema;
import co.edu.udistrital.model.Problema;
import co.edu.udistrital.view.VistaConsola;

public class SoporteHandler extends AProblema{
	private VistaConsola vista;
	
	public SoporteHandler(VistaConsola vista) {
		this.vista = vista;
		
	}

	@Override
	public void ManejarProblema(Problema problema) {
		 vista.mostrarInformacion("Área de soporte: Hola, por favor mantén precionado el boton de reset durante 1 minuto.¿Se solucionó el problema?");
         String respuesta = vista.leerCadenaTexto("Escribe 'sí' o 'no'");
         
	        if (respuesta.equalsIgnoreCase("sí") || respuesta.equalsIgnoreCase("si")) {
	            problema.setResuelto(true);
	            vista.mostrarInformacion("Área de soporte: Soporte: Tu problema ha sido solucionado con exito, adios");
	        } else {
	            vista.mostrarInformacion("CASO ESCALADO");
	            super.ManejarProblema(problema); //Pasa al siguiente manejador
	            //super clase pader(Aproblema)
	        }
	    }

	
	

}
	

