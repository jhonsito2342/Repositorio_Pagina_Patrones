package co.edu.udistrital.model;


//Plantilla Base
public abstract class AProblema implements IProblemaHandler {
	
	protected IProblemaHandler siguiente;

	@Override
	public IProblemaHandler setSiguiente(IProblemaHandler h) {
		//Guarda el siguiente manejador ylo retorna para encadenar
		this.siguiente = h;
		return h;
	}

	@Override
	public void ManejarProblema(Problema problema) {
		
		//Delega la solución al otro manejador
		if(siguiente != null) {
			siguiente.ManejarProblema(problema);
		}else {
			System.out.println("No se pudo resolver el problema");
		}
		
	}
	
}
