/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

public class UserPost {

    private String userId;
    private String content;
    private boolean isApproved;

    public UserPost(String userId, String content) {
        this.userId = userId;
        this.content = content;
        this.isApproved = false;
    }

    // Getters y setters
    public String getContent() {
        return content;
    }

    public String getUserId() {
        return userId;
    }

    public boolean isApproved() {
        return isApproved;
    }

    public void approve() {
        isApproved = true;
    }

    public void reject() {
        isApproved = false;
    }

    @Override
    public String toString() {
        return "Post de " + userId + ": " + content + " - " + (isApproved ? "APROBADO" : "RECHAZADO");
    }
}
