/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package filters;

import model.UserPost;

public class SpamFilter implements ContentFilter {

    private ContentFilter nextFilter;
    private final int MAX_LINKS = 2;

    @Override
    public void setNextFilter(ContentFilter nextFilter) {
        this.nextFilter = nextFilter;
    }

    @Override
    public void process(UserPost post) {
        String content = post.getContent();
        int linkCount = content.split("http://", -1).length - 1;

        if (linkCount > MAX_LINKS) {
            System.out.println("Filtro de spam: Post rechazado por demasiados enlaces (" + linkCount + ")");
            post.reject();
        } else if (nextFilter != null) {
            nextFilter.process(post);
        } else {
            post.approve();
        }
    }
}
