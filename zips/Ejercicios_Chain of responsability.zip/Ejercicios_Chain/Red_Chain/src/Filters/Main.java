/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Filters;

import filters.ContentFilter;
import filters.LegalComplianceFilter;
import filters.ProfanityFilter;
import filters.SpamFilter;
import model.UserPost;

public class Main {

    public static void main(String[] args) {
        // Configurar cadena de filtros
        ContentFilter profanityFilter = new ProfanityFilter();
        ContentFilter spamFilter = new SpamFilter();
        ContentFilter legalFilter = new LegalComplianceFilter();

        profanityFilter.setNextFilter(spamFilter);
        spamFilter.setNextFilter(legalFilter);

        // Crear posts
        UserPost post1 = new UserPost("user1", "Este es un post normal sobre mi día");
        UserPost post2 = new UserPost("user2", "Compre este producto http://link1.com y http://link2.com y http://link3.com");
        UserPost post3 = new UserPost("user3", "Información confidencial de la empresa");
        UserPost post4 = new UserPost("user4", "Post con malapalabra");

        // Procesar posts
        System.out.println("=== Procesamiento de posts ===");
        profanityFilter.process(post1);
        profanityFilter.process(post2);
        profanityFilter.process(post3);
        profanityFilter.process(post4);

        // Mostrar resultados
        System.out.println("\n=== Resultados ===");
        System.out.println(post1);
        System.out.println(post2);
        System.out.println(post3);
        System.out.println(post4);
    }
}
