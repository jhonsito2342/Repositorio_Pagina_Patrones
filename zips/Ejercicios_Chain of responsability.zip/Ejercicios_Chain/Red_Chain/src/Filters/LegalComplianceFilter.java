/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package filters;

import model.UserPost;

public class LegalComplianceFilter implements ContentFilter {

    private ContentFilter nextFilter;
    private String[] restrictedTerms = {"confidencial", "patente", "interno"};

    @Override
    public void setNextFilter(ContentFilter nextFilter) {
        this.nextFilter = nextFilter;
    }

    @Override
    public void process(UserPost post) {
        boolean hasRestrictedTerm = false;
        String content = post.getContent().toLowerCase();

        for (String term : restrictedTerms) {
            if (content.contains(term)) {
                hasRestrictedTerm = true;
                break;
            }
        }

        if (hasRestrictedTerm) {
            System.out.println("Filtro legal: Post rechazado por contenido confidencial");
            post.reject();
        } else if (nextFilter != null) {
            nextFilter.process(post);
        } else {
            post.approve();
        }
    }
}
