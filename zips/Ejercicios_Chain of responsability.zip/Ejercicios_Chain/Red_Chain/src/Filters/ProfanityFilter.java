/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package filters;

import model.UserPost;

public class ProfanityFilter implements ContentFilter {

    private ContentFilter nextFilter;
    private String[] badWords = {"malapalabra", "insulto", "odio"};

    @Override
    public void setNextFilter(ContentFilter nextFilter) {
        this.nextFilter = nextFilter;
    }

    @Override
    public void process(UserPost post) {
        boolean containsBadWord = false;
        String content = post.getContent().toLowerCase();

        for (String word : badWords) {
            if (content.contains(word)) {
                containsBadWord = true;
                break;
            }
        }

        if (containsBadWord) {
            System.out.println("Filtro de groserías: Post rechazado por lenguaje inapropiado");
            post.reject();
        } else if (nextFilter != null) {
            nextFilter.process(post);
        } else {
            post.approve();
        }
    }
}
