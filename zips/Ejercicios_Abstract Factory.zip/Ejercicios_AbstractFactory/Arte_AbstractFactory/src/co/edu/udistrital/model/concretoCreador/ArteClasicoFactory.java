/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model.concretoCreador;

import co.edu.udistrital.model.EsculturaClasica;
import co.edu.udistrital.model.PinturaClasica;
import co.edu.udistrital.model.abstracto.ArteFactory;
import co.edu.udistrital.model.abstracto.Escultura;
import co.edu.udistrital.model.abstracto.Pintura;

/**
 *
 * @author Jhon
 */
public class ArteClasicoFactory implements ArteFactory {

    public Pintura crearPintura() {
        return new PinturaClasica();
    }

    public Escultura crearEscultura() {
        return new EsculturaClasica();
    }
}
