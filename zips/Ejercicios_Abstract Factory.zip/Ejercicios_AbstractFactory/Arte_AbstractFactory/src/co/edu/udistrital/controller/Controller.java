package co.edu.udistrital.controller;

import co.edu.udistrital.view.VistaConsola;
import co.edu.udistrital.model.abstracto.ArteFactory;
import co.edu.udistrital.model.abstracto.Pintura;
import co.edu.udistrital.model.abstracto.Escultura;
import co.edu.udistrital.model.concretoCreador.ArteClasicoFactory;
import co.edu.udistrital.model.concretoCreador.ArteModernoFactory;

public class Controller {

    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        int opcion;

        do {
            vista.mostrarInformacion("\n--- GALERIA DE ARTE ---");
            vista.mostrarInformacion("1. Crear arte clasico");
            vista.mostrarInformacion("2. Crear arte moderno");
            vista.mostrarInformacion("0. Salir");
            opcion = vista.leerDatoEntero("Seleccione una opcion: ");

            ArteFactory fabrica = null;

            switch (opcion) {
                case 1:
                    fabrica = new ArteClasicoFactory();
                    break;
                case 2:
                    fabrica = new ArteModernoFactory();
                    break;
                case 0:
                    vista.mostrarInformacion("Saliendo...");
                    continue;
                default:
                    vista.mostrarInformacion("Opcion no valida.");
                    continue;
            }

            Pintura pintura = fabrica.crearPintura();
            Escultura escultura = fabrica.crearEscultura();

            vista.mostrarInformacion("\n--- Obra de Pintura ---");
            vista.mostrarInformacion(pintura.mostrar());

            vista.mostrarInformacion("\n--- Obra de Escultura ---");
            vista.mostrarInformacion(escultura.mostrar());

        } while (opcion != 0);
    }
}
