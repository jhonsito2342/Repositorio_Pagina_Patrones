package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Escultura;

public class EsculturaClasica implements Escultura {
    public String mostrar() {
        return "Escultura clasica en marmol estilo griego.";
    }
}
