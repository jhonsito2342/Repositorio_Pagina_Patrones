package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Pintura;

public class PinturaModerna implements Pintura {
    public String mostrar() {
        return "Pintura moderna con tecnicas digitales.";
    }

    
}