package co.edu.udistrital.model.abstracto;

public interface ArteFactory {
    Pintura crearPintura();
    Escultura crearEscultura();
}