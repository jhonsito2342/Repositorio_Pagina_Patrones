package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Pintura;

public class PinturaClasica implements Pintura {

    public String mostrar() {
        return "Pintura clasica al oleo del Renacimiento.";
    }
}
