/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model.concretoCreador;

import co.edu.udistrital.model.EsculturaModerna;
import co.edu.udistrital.model.PinturaModerna;
import co.edu.udistrital.model.abstracto.ArteFactory;
import co.edu.udistrital.model.abstracto.Escultura;
import co.edu.udistrital.model.abstracto.Pintura;

/**
 *
 * @author Jhon
 */
public class ArteModernoFactory implements ArteFactory {
    public Pintura crearPintura() {
        return new PinturaModerna();
    }

    public Escultura crearEscultura() {
        return new EsculturaModerna();
    }
}
