/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model.concretoCreador;

import co.edu.udistrital.model.ConsolaRetro;
import co.edu.udistrital.model.JuegoRetro;
import co.edu.udistrital.model.abstracto.Consola;
import co.edu.udistrital.model.abstracto.Juego;
import co.edu.udistrital.model.abstracto.VideojuegoFactory;

/**
 *
 * @author Jhon
 */
public class VideojuegoRetroFactory implements VideojuegoFactory {

    public Juego crearJuego() {
        return new JuegoRetro();
    }

    public Consola crearConsola() {
        return new ConsolaRetro();
    }
}
