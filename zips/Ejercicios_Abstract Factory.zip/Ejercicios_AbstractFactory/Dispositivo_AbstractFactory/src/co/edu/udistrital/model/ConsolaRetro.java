package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Consola;

public class ConsolaRetro implements Consola {

    public String mostrar() {
        return "️ Consola retro: NES de 1985.";
    }
}
