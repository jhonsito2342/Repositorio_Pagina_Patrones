package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Consola;

public class ConsolaModerna implements Consola {

    public String mostrar() {
        return "️ Consola moderna: PlayBox Series X con VR.";
    }
}
