package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Juego;

public class JuegoModerno implements Juego {
    public String mostrar() {
        return " Juego moderno: Legends of Infinity en 4K.";
    }
}
