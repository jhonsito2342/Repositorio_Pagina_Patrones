/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model.concretoCreador;

import co.edu.udistrital.model.ConsolaModerna;
import co.edu.udistrital.model.JuegoModerno;
import co.edu.udistrital.model.abstracto.Consola;
import co.edu.udistrital.model.abstracto.Juego;
import co.edu.udistrital.model.abstracto.VideojuegoFactory;

/**
 *
 * @author Jhon
 */
public class VideojuegoModernoFactory implements VideojuegoFactory {

    public Juego crearJuego() {
        return new JuegoModerno();
    }

    public Consola crearConsola() {
        return new ConsolaModerna();
    }
}
