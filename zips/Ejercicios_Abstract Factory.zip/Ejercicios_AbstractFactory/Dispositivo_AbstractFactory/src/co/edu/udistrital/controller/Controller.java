package co.edu.udistrital.controller;

import co.edu.udistrital.model.abstracto.Consola;
import co.edu.udistrital.model.abstracto.Juego;
import co.edu.udistrital.model.abstracto.VideojuegoFactory;
import co.edu.udistrital.model.concretoCreador.VideojuegoModernoFactory;
import co.edu.udistrital.model.concretoCreador.VideojuegoRetroFactory;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        int opcion;

        do {
            vista.mostrarInformacion("\n--- MUNDO DE VIDEOJUEGOS ---");
            vista.mostrarInformacion("1. Crear videojuego retro");
            vista.mostrarInformacion("2. Crear videojuego moderno");
            vista.mostrarInformacion("0. Salir");
            opcion = vista.leerDatoEntero("Seleccione una opcion: ");

            VideojuegoFactory fabrica = null;

            switch (opcion) {
                case 1:
                    fabrica = new VideojuegoRetroFactory();
                    break;
                case 2:
                    fabrica = new VideojuegoModernoFactory();
                    break;
                case 0:
                    vista.mostrarInformacion("Saliendo...");
                    continue;
                default:
                    vista.mostrarInformacion("Opcion no valida.");
                    continue;
            }

            Juego juego = fabrica.crearJuego();
            Consola consola = fabrica.crearConsola();

            vista.mostrarInformacion("\n--- Juego ---");
            vista.mostrarInformacion(juego.mostrar());

            vista.mostrarInformacion("\n--- Consola ---");
            vista.mostrarInformacion(consola.mostrar());

        } while (opcion != 0);
    }
}
