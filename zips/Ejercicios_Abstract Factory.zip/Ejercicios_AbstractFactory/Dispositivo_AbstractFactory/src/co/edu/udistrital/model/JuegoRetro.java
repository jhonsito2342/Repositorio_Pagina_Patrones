/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Juego;

/**
 *
 * @author Jhon
 */
public class JuegoRetro implements Juego {
    public String mostrar() {
        return " Juego retro: Super Pixel Bros en 8 bits.";
    }
}