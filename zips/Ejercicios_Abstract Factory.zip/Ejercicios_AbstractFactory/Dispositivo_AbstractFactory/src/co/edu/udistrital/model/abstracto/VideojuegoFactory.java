package co.edu.udistrital.model.abstracto;

public interface VideojuegoFactory {
    Juego crearJuego();
    Consola crearConsola();
}