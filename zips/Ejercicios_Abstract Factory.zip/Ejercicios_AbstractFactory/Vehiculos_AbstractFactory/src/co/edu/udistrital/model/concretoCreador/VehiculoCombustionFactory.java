/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model.concretoCreador;


/**
 *
 * @author Jhon
 */


import co.edu.udistrital.model.CarroGasolina;
import co.edu.udistrital.model.MotoGasolina;
import co.edu.udistrital.model.abstracto.Carro;
import co.edu.udistrital.model.abstracto.Moto;
import co.edu.udistrital.model.abstracto.VehiculoFactory;

public class VehiculoCombustionFactory implements VehiculoFactory {
    public Carro crearCarro() {
        return new CarroGasolina();
    }

    public Moto crearMoto() {
        return new MotoGasolina();
    }
}