/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Moto;

/**
 *
 * @author Jhon
 */
public class MotoElectrica implements Moto {
    public String especificaciones() {
        return "Moto Electrica: motor 5kW, autonomia 100km.";
    }
}