package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Carro;

public class CarroGasolina implements Carro {
    public String especificaciones() {
        return "Carro a Gasolina: motor 2.0L, rendimiento 40km/gal.";
    }
}
