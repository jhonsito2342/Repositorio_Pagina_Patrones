/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model.concretoCreador;

import co.edu.udistrital.model.CarroElectrico;
import co.edu.udistrital.model.MotoElectrica;
import co.edu.udistrital.model.abstracto.Carro;
import co.edu.udistrital.model.abstracto.Moto;
import co.edu.udistrital.model.abstracto.VehiculoFactory;

/**
 *
 * @author Jhon
 */

public class VehiculoElectricoFactory implements VehiculoFactory {
    public Carro crearCarro() {
        return new CarroElectrico();
    }

    public Moto crearMoto() {
        return new MotoElectrica();
    }
}