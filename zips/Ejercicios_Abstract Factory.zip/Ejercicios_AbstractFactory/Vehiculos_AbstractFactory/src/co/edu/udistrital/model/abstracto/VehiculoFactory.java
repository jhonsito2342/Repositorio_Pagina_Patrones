package co.edu.udistrital.model.abstracto;



public interface VehiculoFactory {
    Carro crearCarro();
    Moto crearMoto();
}