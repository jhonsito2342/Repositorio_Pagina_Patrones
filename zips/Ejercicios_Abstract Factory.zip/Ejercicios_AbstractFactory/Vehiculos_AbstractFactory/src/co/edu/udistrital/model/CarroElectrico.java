package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Carro;


public class CarroElectrico implements Carro {
    public String especificaciones() {
        return "Carro Electrico: bateria 75 kWh, autonomia 400km.";
    }
}
