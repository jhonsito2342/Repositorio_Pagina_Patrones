package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Moto;

public class MotoGasolina implements Moto {
    public String especificaciones() {
        return "Moto a Gasolina: motor 150cc, rendimiento 90km/gal.";
    }
}