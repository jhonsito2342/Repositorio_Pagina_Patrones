package co.edu.udistrital.controller;

import co.edu.udistrital.model.abstracto.Carro;
import co.edu.udistrital.model.abstracto.Moto;
import co.edu.udistrital.model.abstracto.VehiculoFactory;
import co.edu.udistrital.model.concretoCreador.VehiculoCombustionFactory;
import co.edu.udistrital.model.concretoCreador.VehiculoElectricoFactory;
import co.edu.udistrital.view.VistaConsola;


public class Controller {
    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        int opcion;
        do {
            vista.mostrarInformacion("\n--- FABRICA DE VEHICULOS ---");
            vista.mostrarInformacion("1. Crear Vehiculos Electricos");
            vista.mostrarInformacion("2. Crear Vehiculos a Gasolina");
            vista.mostrarInformacion("0. Salir");
            opcion = vista.leerDatoEntero("Seleccione una opcion: ");

            VehiculoFactory fabrica = null;

            switch (opcion) {
                case 1:
                    fabrica = new VehiculoElectricoFactory();
                    break;
                case 2:
                    fabrica = new VehiculoCombustionFactory();
                    break;
                case 0:
                    vista.mostrarInformacion("Adios!");
                    continue;
                default:
                    vista.mostrarInformacion("Opcion invalida.");
                    continue;
            }

            Carro carro = fabrica.crearCarro();
            Moto moto = fabrica.crearMoto();

            vista.mostrarInformacion("\nCARRO: " + carro.especificaciones());
            vista.mostrarInformacion("MOTO: " + moto.especificaciones());

        } while (opcion != 0);
    }
}
