/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */

public class Casa {

    private final int habitaciones;
    private final int banos;
    private final String tipoTecho;
    private final boolean tieneGaraje;
    private final boolean tieneJardin;
    private final double areaConstruccion;

    // Constructor privado
    private Casa(Builder builder) {
        this.habitaciones = builder.habitaciones;
        this.banos = builder.banos;
        this.tipoTecho = builder.tipoTecho;
        this.tieneGaraje = builder.tieneGaraje;
        this.tieneJardin = builder.tieneJardin;
        this.areaConstruccion = builder.areaConstruccion;
    }

    // Getters
    public int getHabitaciones() {
        return habitaciones;
    }

    public int getBanos() {
        return banos;
    }

    public String getTipoTecho() {
        return tipoTecho;
    }

    public boolean tieneGaraje() {
        return tieneGaraje;
    }

    public boolean tieneJardin() {
        return tieneJardin;
    }

    public double getAreaConstruccion() {
        return areaConstruccion;
    }

    @Override
    public String toString() {
        return "Casa:\n"
                + "  Habitaciones: " + habitaciones + "\n"
                + "  Baños: " + banos + "\n"
                + "  Tipo de techo: " + tipoTecho + "\n"
                + "  Garaje: " + (tieneGaraje ? "Sí" : "No") + "\n"
                + "  Jardín: " + (tieneJardin ? "Sí" : "No") + "\n"
                + "  Área construcción: " + areaConstruccion + " m²\n";
    }

    // Builder estático interno
    public static class Builder {

        private int habitaciones;
        private int banos;
        private String tipoTecho = "Plano";
        private boolean tieneGaraje = false;
        private boolean tieneJardin = false;
        private double areaConstruccion = 100.0;

        public Builder setHabitaciones(int habitaciones) {
            this.habitaciones = habitaciones;
            return this;
        }

        public Builder setBanos(int banos) {
            this.banos = banos;
            return this;
        }

        public Builder setTipoTecho(String tipoTecho) {
            this.tipoTecho = tipoTecho;
            return this;
        }

        public Builder setTieneGaraje(boolean tieneGaraje) {
            this.tieneGaraje = tieneGaraje;
            return this;
        }

        public Builder setTieneJardin(boolean tieneJardin) {
            this.tieneJardin = tieneJardin;
            return this;
        }

        public Builder setAreaConstruccion(double areaConstruccion) {
            this.areaConstruccion = areaConstruccion;
            return this;
        }

        public Casa build() {
            // Validaciones básicas
            if (habitaciones <= 0 || banos <= 0 || areaConstruccion <= 0) {
                throw new IllegalStateException("Datos de construcción inválidos");
            }
            return new Casa(this);
        }
    }
}
