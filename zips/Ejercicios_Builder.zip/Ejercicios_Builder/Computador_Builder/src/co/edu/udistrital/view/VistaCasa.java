/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.view;


import java.util.Scanner;

/**
 *
 * @author Jhon
 */

public class VistaCasa {
    private Scanner sc;

    public VistaCasa() {
        this.sc = new Scanner(System.in);
    }

    public void mostrarMenu() {
        System.out.println("\n--- SIMULADOR DE ARQUITECTURA ---");
        System.out.println("1. Crear nueva casa");
        System.out.println("2. Mostrar casa creada");
        System.out.println("3. Salir");
        System.out.print("Seleccione opción: ");
    }

    public int leerOpcion() {
        return sc.nextInt();
    }

    public void limpiarBuffer() {
        sc.nextLine();
    }

    public int leerEntero(String mensaje) {
        System.out.print(mensaje);
        int valor = sc.nextInt();
        sc.nextLine(); // Limpiar buffer
        return valor;
    }

    public double leerDouble(String mensaje) {
        System.out.print(mensaje);
        double valor = sc.nextDouble();
        sc.nextLine(); // Limpiar buffer
        return valor;
    }

    public String leerTexto(String mensaje) {
        System.out.print(mensaje);
        return sc.nextLine();
    }

    public boolean leerSiNo(String mensaje) {
        System.out.print(mensaje + " (s/n): ");
        String respuesta = sc.nextLine();
        return respuesta.equalsIgnoreCase("s");
    }

    public void mostrarCasa(String infoCasa) {
        System.out.println("\nDETALLES DE LA CASA:");
        System.out.println(infoCasa);
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
}