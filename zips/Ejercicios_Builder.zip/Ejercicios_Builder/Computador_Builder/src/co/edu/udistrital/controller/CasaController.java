/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.controller;

import co.edu.udistrital.model.Casa;
import co.edu.udistrital.view.VistaCasa;

/**
 *
 * @author Jhon
 */


public class CasaController {
    private VistaCasa vista;
    private Casa casaActual;

    public CasaController() {
        this.vista = new VistaCasa();
    }

    public void iniciar() {
        int opcion;
        do {
            vista.mostrarMenu();
            opcion = vista.leerOpcion();
            vista.limpiarBuffer();

            switch (opcion) {
                case 1:
                    crearCasa();
                    break;
                case 2:
                    mostrarCasa();
                    break;
                case 3:
                    vista.mostrarMensaje("Saliendo del simulador...");
                    break;
                default:
                    vista.mostrarMensaje("Opción no válida");
            }
        } while (opcion != 3);
    }

    private void crearCasa() {
        try {
            Casa.Builder builder = new Casa.Builder()
                .setHabitaciones(vista.leerEntero("Número de habitaciones: "))
                .setBanos(vista.leerEntero("Número de baños: "))
                .setTipoTecho(vista.leerTexto("Tipo de techo (Plano/Inclinado/Arqueado): "))
                .setTieneGaraje(vista.leerSiNo("¿Incluir garaje?"))
                .setTieneJardin(vista.leerSiNo("¿Incluir jardín?"))
                .setAreaConstruccion(vista.leerDouble("Área de construcción (m²): "));

            casaActual = builder.build();
            vista.mostrarMensaje("¡Casa creada con éxito!");
        } catch (Exception e) {
            vista.mostrarMensaje("Error: " + e.getMessage());
        }
    }

    private void mostrarCasa() {
        if (casaActual != null) {
            vista.mostrarCasa(casaActual.toString());
        } else {
            vista.mostrarMensaje("No hay casa creada aún");
        }
    }
}