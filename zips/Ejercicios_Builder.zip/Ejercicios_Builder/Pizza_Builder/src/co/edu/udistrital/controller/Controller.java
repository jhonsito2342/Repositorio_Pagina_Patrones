package co.edu.udistrital.controller;

import co.edu.udistrital.model.Pizza;
import co.edu.udistrital.view.VistaConsola;
import java.util.ArrayList;
import java.util.List;

    public class Controller {

        private VistaConsola vista;
        private List<Pizza> pizzas;  // Lista para almacenar las pizzas ordenadas

        public Controller() {
            vista = new VistaConsola();
            pizzas = new ArrayList<>();  // Inicializar la lista de pizzas
        }

        public void run() {
            boolean seguir = true;

            while (seguir) {
                vista.mostrarInformacion("\n--- MENU PRINCIPAL ---");
                vista.mostrarInformacion("1. Ordenar una pizza");
                vista.mostrarInformacion("2. Ver pizzas ordenadas");
                vista.mostrarInformacion("0. Salir");

                int opcionPrincipal = vista.leerDatoEntero("Seleccione una opcion: ");
                Pizza.Builder builder = null;  // Declarado fuera del switch

                switch (opcionPrincipal) {
                    case 1:
                        vista.mostrarInformacion("BIENVENIDO AL CONSTRUCTOR DE PIZZAS ");
                        String nombre = vista.leerDatoTexto("Ingrese el nombre base de la pizza: ");
                        builder = Pizza.builder(nombre);

                        boolean continuar = true;

                        while (continuar) {
                            vista.mostrarInformacion("\nQue ingredientes desea agregar?");
                            vista.mostrarInformacion("1. Extra Queso");
                            vista.mostrarInformacion("2. Orilla Rellena");
                            vista.mostrarInformacion("3. Tamaño");
                            vista.mostrarInformacion("4. Tag");
                            vista.mostrarInformacion("5. Tomate");
                            vista.mostrarInformacion("6. Aceitunas");
                            vista.mostrarInformacion("7. Terminar");

                            int opcion = vista.leerDatoEntero("Seleccione una opción: ");

                            switch (opcion) {
                                case 1:
                                    String queso = vista.leerDatoTexto("Desea extra queso? (Si / No): ");
                                    builder.extraQueso(queso);
                                    break;
                                case 2:
                                    String orilla = vista.leerDatoTexto("Desea orilla rellena? (Si / No): ");
                                    builder.orillaRellena(orilla);
                                    break;
                                case 3:
                                    String tamaño = vista.leerDatoTexto("Ingrese el tamaño (Pequeña / Mediana / Grande): ");
                                    builder.tamaño(tamaño);
                                    break;
                                case 4:
                                    String tag = vista.leerDatoTexto("Ingrese un tag para esta pizza (ej. 'vegetariana', 'favorita', 'Recibe Andres(ej.)'): ");
                                    builder.tag(tag);
                                    break;
                                case 5:
                                    String tomate = vista.leerDatoTexto("Desea agregar tomate? (Si / No): ");
                                    builder.tomate(tomate);
                                    break;
                                case 6:
                                    String aceitunas = vista.leerDatoTexto("Desea agregar aceitunas? (Si / No): ");
                                    builder.aceitunas(aceitunas);
                                    break;
                                case 7:
                                    continuar = false;
                                    break;
                                default:
                                    vista.mostrarInformacion("Opcion invalida.");
                                    break;
                            }
                        }

                        Pizza pizza = builder.build();
                        pizzas.add(pizza); 

                        break;

                    case 2:
                        if (pizzas.isEmpty()) {
                            vista.mostrarInformacion("No hay pizzas ordenadas.");
                        } else {
                            vista.mostrarInformacion("\n LISTA DE PIZZAS ORDENADAS:");
                            for (Pizza p : pizzas) {
                                vista.mostrarInformacion("Nombre: " + p.getNombre());
                                vista.mostrarInformacion("Extra Queso: " + p.getExtraQueso());
                                vista.mostrarInformacion("Orilla Rellena: " + p.getOrillaRellena());
                                vista.mostrarInformacion("Tamaño: " + p.getTamaño());
                                vista.mostrarInformacion("Tags: " + p.getTags());
                                vista.mostrarInformacion("Tomate: " + p.getTomate());
                                vista.mostrarInformacion("Aceitunas: " + p.getAceitunas());
                            }
                        }
                        break;

                    case 0:
                        seguir = false;
                        vista.mostrarInformacion("Gracias por ecoger el mejor restaurante");
                        break;

                    default:
                        vista.mostrarInformacion("Opción invalida.");
                        break;
                }
            }
        }
    }
