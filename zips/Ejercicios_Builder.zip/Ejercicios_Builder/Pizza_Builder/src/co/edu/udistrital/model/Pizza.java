package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
public class Pizza {

    private String nombre;
    private String extraQueso;
    private String orillaRellena;
    private String aceitunas;
    private String tomate;
    private String tamaño;
    private List<String> tags;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getExtraQueso() {
        return extraQueso;
    }

    public void setExtraQueso(String extraQueso) {
        this.extraQueso = extraQueso;
    }

    public String getOrillaRellena() {
        return orillaRellena;
    }

    public void setOrillaRellena(String orillaRellena) {
        this.orillaRellena = orillaRellena;
    }

    public String getAceitunas() {
        return aceitunas;
    }

    public void setAceitunas(String aceitunas) {
        this.aceitunas = aceitunas;
    }

    public String getTomate() {
        return tomate;
    }

    public void setTomate(String tomate) {
        this.tomate = tomate;
    }

    public String getTamaño() {
        return tamaño;
    }

    public void setTamaño(String tamaño) {
        this.tamaño = tamaño;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }

    private Pizza(String nombre) {
        this.nombre = nombre;
        this.tags = new ArrayList<>();
    }

    public static Builder builder(String nombre) {
        return new Builder(nombre);
    }

    public static class Builder {

        private Pizza pizza;

        public Builder(String nombre) {
            this.pizza = new Pizza(nombre);
        }

        public Builder extraQueso(String extraQueso) {
            this.pizza.extraQueso = extraQueso;
            return this;
        }

        public Builder aceitunas(String aceitunas) {
            this.pizza.aceitunas = aceitunas;
            return this;
        }

        public Builder tomate(String tomate) {
            this.pizza.tomate = tomate;
            return this;
        }

        public Builder orillaRellena(String orillaRellena) {
            this.pizza.orillaRellena = orillaRellena;
            return this;
        }

        public Builder tamaño(String tamaño) {
            this.pizza.tamaño = tamaño;
            return this;
        }

        public Builder tag(String tag) {
            this.pizza.tags.add(tag);
            return this;
        }

        public Pizza build() {
            return this.pizza;
        }
    }
}
