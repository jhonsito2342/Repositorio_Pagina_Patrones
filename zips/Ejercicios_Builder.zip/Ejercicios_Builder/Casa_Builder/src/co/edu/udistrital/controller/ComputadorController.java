/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.controller;

import co.edu.udistrital.model.Computador;
import co.edu.udistrital.model.ComputadorBuilder;
import co.edu.udistrital.model.Director;
import co.edu.udistrital.view.VistaComputador;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Jhon
 */


public class ComputadorController {
    private List<Computador> computadores;
    private VistaComputador vista;
    private ComputadorBuilder builder;

    public ComputadorController() {
        this.computadores = new ArrayList<>();
        this.vista = new VistaComputador();
        this.builder = new ComputadorBuilder();
    }

    public void iniciar() {
        int opcion;
        do {
            vista.mostrarMenu();
            opcion = vista.leerOpcion();
            vista.limpiarBuffer();

            switch (opcion) {
                case 1:
                    crearBasicPC();
                    break;
                case 2:
                    crearGamerPC();
                    break;
                case 3:
                    crearCustomPC();
                    break;
                case 4:
                    mostrarComputadores();
                    break;
                case 5:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción no válida");
            }
        } while (opcion != 5);
    }

    private void crearBasicPC() {
        Computador pc = Director.makeBasicPC(builder);
        computadores.add(pc);
        vista.mostrarComputador(pc);
    }

    private void crearGamerPC() {
        Computador pc = Director.makeGamerPC(builder);
        computadores.add(pc);
        vista.mostrarComputador(pc);
    }

    private void crearCustomPC() {
        try {
            Computador pc = builder
                .setCPU(vista.leerCPU())
                .setRAM(vista.leerRAM())
                .setSSD(vista.leerSSD())
                .build();
            computadores.add(pc);
            vista.mostrarComputador(pc);
        } catch (IllegalStateException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void mostrarComputadores() {
        vista.mostrarListaComputadores(computadores);
    }
}