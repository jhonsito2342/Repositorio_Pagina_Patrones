/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */


public class ComputadorBuilder {

    private Computador computador;

    public ComputadorBuilder() {
        this.computador = new Computador();
    }

    public ComputadorBuilder setCPU(String cpu) {
        computador.cpu = cpu;
        return this;
    }

    public ComputadorBuilder setRAM(int ram) {
        computador.ram = ram;
        return this;
    }

    public ComputadorBuilder setSSD(int ssd) {
        computador.ssd = ssd;
        return this;
    }

    public Computador build() {
        // Validaciones básicas
        if (computador.cpu == null || computador.ram <= 0 || computador.ssd <= 0) {
            throw new IllegalStateException("Configuración inválida");
        }
        return computador;
    }
}
