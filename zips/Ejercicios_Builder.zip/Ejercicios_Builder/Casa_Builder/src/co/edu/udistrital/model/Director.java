/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */

public class Director {
    public static Computador makeBasicPC(ComputadorBuilder builder) {
        return builder
            .setCPU("Intel Core i3")
            .setRAM(8)
            .setSSD(256)
            .build();
    }

    public static Computador makeGamerPC(ComputadorBuilder builder) {
        return builder
            .setCPU("Intel Core i7")
            .setRAM(16)
            .setSSD(512)
            .build();
    }

    public static Computador makeWorkstationPC(ComputadorBuilder builder) {
        return builder
            .setCPU("AMD Ryzen 9")
            .setRAM(32)
            .setSSD(1000)
            .build();
    }
}