/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.view;

import co.edu.udistrital.model.Computador;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Jhon
 */

public class VistaComputador {
    private Scanner sc;

    public VistaComputador() {
        this.sc = new Scanner(System.in);
    }

    public void mostrarMenu() {
        System.out.println("\n--- CONSTRUCTOR DE COMPUTADORES ---");
        System.out.println("1. Crear PC Básico");
        System.out.println("2. Crear PC Gamer");
        System.out.println("3. Crear PC Personalizado");
        System.out.println("4. Mostrar todos los computadores");
        System.out.println("5. Salir");
        System.out.print("Seleccione opción: ");
    }

    public int leerOpcion() {
        return sc.nextInt();
    }

    public void limpiarBuffer() {
        sc.nextLine();
    }

    public String leerCPU() {
        System.out.print("Ingrese CPU: ");
        return sc.nextLine();
    }

    public int leerRAM() {
        System.out.print("Ingrese RAM (GB): ");
        int ram = sc.nextInt();
        sc.nextLine(); // Limpiar buffer
        return ram;
    }

    public int leerSSD() {
        System.out.print("Ingrese SSD (GB): ");
        int ssd = sc.nextInt();
        sc.nextLine(); // Limpiar buffer
        return ssd;
    }

    public void mostrarComputador(Computador pc) {
        System.out.println("\nComputador creado:");
        System.out.println(pc.toString());
    }

    public void mostrarListaComputadores(List<Computador> lista) {
        System.out.println("\n--- LISTA DE COMPUTADORES ---");
        for (int i = 0; i < lista.size(); i++) {
            System.out.println((i+1) + ". " + lista.get(i).toString());
        }
    }
}
