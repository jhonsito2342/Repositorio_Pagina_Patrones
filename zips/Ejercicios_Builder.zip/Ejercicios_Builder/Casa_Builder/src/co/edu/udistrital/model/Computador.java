/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */


public class Computador {
    String cpu;
    int ram;
    int ssd;

    public Computador() {}

    // Getters
    public String getCpu() { return cpu; }
    public int getRam() { return ram; }
    public int getSsd() { return ssd; }

    @Override
    public String toString() {
        return String.format("CPU: %s | RAM: %dGB | SSD: %dGB", cpu, ram, ssd);
    }
}