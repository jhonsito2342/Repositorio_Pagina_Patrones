
package co.edu.udistrital.model;




public class Leche extends DecoradorCafe {
    private Cafe cafe;

    public Leche(Cafe cafe) {
        this.cafe = cafe;
    }

    @Override
    public String getDescripcion() {
        return cafe.getDescripcion() + " + Leche";
    }
}
