package co.edu.udistrital.model;



public abstract class DecoradorCafe extends Cafe {
    @Override
    public abstract String getDescripcion();
}
