
package co.edu.udistrital.view;

import java.util.Scanner;


public class VistaCafe {
    private Scanner scanner;

    public VistaCafe() {
        this.scanner = new Scanner(System.in);
    }

    public void mostrarBienvenida() {
        System.out.println("\n=== CAFETERÍA DECORATOR ===");
    }

    public void mostrarMenu() {
        System.out.println("\n1. Añadir Leche");
        System.out.println("2. Añadir Chocolate");
        System.out.println("3. Añadir Canela");
        System.out.println("4. Añadir Crema");
        System.out.println("0. Terminar pedido");
        System.out.print("Seleccione: ");
    }

    public int leerOpcion() {
        return scanner.nextInt();
    }

    public void mostrarError() {
        System.out.println("Opción no válida");
    }

    public void mostrarPedido(String descripcion) {
        System.out.println("\n=== SU PEDIDO ===");
        System.out.println(descripcion);
        System.out.println("¡Disfrute su café!");
    }
}