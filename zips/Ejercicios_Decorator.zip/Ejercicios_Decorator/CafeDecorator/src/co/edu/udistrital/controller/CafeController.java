package co.edu.udistrital.controller;

import co.edu.udistrital.model.Cafe;
import co.edu.udistrital.model.Canela;
import co.edu.udistrital.model.Chocolate;
import co.edu.udistrital.model.Crema;
import co.edu.udistrital.model.Leche;
import co.edu.udistrital.view.VistaCafe;



public class CafeController {

    private VistaCafe vista;
    private Cafe cafe;

    public CafeController() {
        this.vista = new VistaCafe();
        this.cafe = new Cafe();
    }

    public void iniciar() {
        vista.mostrarBienvenida();
        int opcion;

        do {
            vista.mostrarMenu();
            opcion = vista.leerOpcion();

            switch (opcion) {
                case 1:
                    cafe = new Leche(cafe);
                    break;
                case 2:
                    cafe = new Chocolate(cafe);
                    break;
                case 3:
                    cafe = new Canela(cafe);
                    break;
                case 4:
                    cafe = new Crema(cafe);
                    break;
                case 0:
                    break;
                default:
                    vista.mostrarError();
            }
        } while (opcion != 0);

        vista.mostrarPedido(cafe.getDescripcion());
    }
}
