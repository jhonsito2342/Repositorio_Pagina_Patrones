
package co.edu.udistrital.model;






public class Pepperoni extends DecoradorPizza {
    private PizzaBase pizza;

    public Pepperoni(PizzaBase pizza) {
        this.pizza = pizza;
    }

    @Override
    public String getDescripcion() {
        return pizza.getDescripcion() + " + Pepperoni";
    }
}