
package co.edu.udistrital.view;




import java.util.Scanner;

public class VistaPizza {
    private Scanner scanner;

    public VistaPizza() {
        this.scanner = new Scanner(System.in);
    }

    public void mostrarBienvenida() {
        System.out.println("\n=== PIZZERÍA DECORATOR ===");
        System.out.println("Personalice su pizza:\n");
    }

    public void mostrarIngredientes() {
        System.out.println("1. Añadir Pepperoni");
        System.out.println("2. Añadir Queso Extra");
        System.out.println("3. Añadir Champiñones");
        System.out.println("4. Añadir Aceitunas");
        System.out.println("5. Añadir Pimientos");
        System.out.println("0. Finalizar pedido");
        System.out.print("Seleccione: ");
    }

    public int leerOpcion() {
        return scanner.nextInt();
    }

    public void mostrarError() {
        System.out.println("¡Opción no válida!");
    }

    public void mostrarPizza(String descripcion) {
        System.out.println("\n=== SU PIZZA PERSONALIZADA ===");
        System.out.println(descripcion);
        System.out.println("\n¡Que la disfrute!");
    }
}