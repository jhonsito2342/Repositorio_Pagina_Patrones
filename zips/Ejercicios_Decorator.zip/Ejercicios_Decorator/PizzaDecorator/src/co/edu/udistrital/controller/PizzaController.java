package co.edu.udistrital.controller;

import co.edu.udistrital.model.Aceitunas;
import co.edu.udistrital.model.Champinones;
import co.edu.udistrital.model.Pepperoni;
import co.edu.udistrital.model.Pimientos;
import co.edu.udistrital.model.PizzaBase;
import co.edu.udistrital.model.QuesoExtra;
import co.edu.udistrital.view.VistaPizza;



public class PizzaController {
    private VistaPizza vista;
    private PizzaBase pizza;

    public PizzaController() {
        this.vista = new VistaPizza();
        this.pizza = new PizzaBase();
    }

    public void iniciar() {
        vista.mostrarBienvenida();
        int opcion;
        
        do {
            vista.mostrarIngredientes();
            opcion = vista.leerOpcion();
            
            switch(opcion) {
                case 1: pizza = new Pepperoni(pizza); break;
                case 2: pizza = new QuesoExtra(pizza); break;
                case 3: pizza = new Champinones(pizza); break;
                case 4: pizza = new Aceitunas(pizza); break;
                case 5: pizza = new Pimientos(pizza); break;
                case 0: break;
                default: vista.mostrarError();
            }
        } while(opcion != 0);
        
        vista.mostrarPizza(pizza.getDescripcion());
    }
}