package co.edu.udistrital.model;





public abstract class DecoradorPizza extends PizzaBase {
    @Override
    public abstract String getDescripcion();
}