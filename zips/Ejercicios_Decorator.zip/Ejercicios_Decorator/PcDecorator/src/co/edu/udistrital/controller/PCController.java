package co.edu.udistrital.controller;

import co.edu.udistrital.model.ComputadoraBase;
import co.edu.udistrital.model.RAM;
import co.edu.udistrital.model.Refrigeracion;
import co.edu.udistrital.model.SSD;
import co.edu.udistrital.model.TarjetaVideo;
import co.edu.udistrital.view.VistaPC;



public class PCController {
    private VistaPC vista;
    private ComputadoraBase pc;

    public PCController() {
        this.vista = new VistaPC();
        this.pc = new ComputadoraBase();
    }

    public void iniciar() {
        vista.mostrarBienvenida();
        int opcion;
        
        do {
            vista.mostrarComponentes();
            opcion = vista.leerOpcion();
            
            switch(opcion) {
                case 1: pc = new RAM(pc); break;
                case 2: pc = new SSD(pc); break;
                case 3: pc = new TarjetaVideo(pc); break;
                case 4: pc = new Refrigeracion(pc); break;
                case 0: break;
                default: vista.mostrarError();
            }
        } while(opcion != 0);
        
        vista.mostrarConfiguracion(pc.getDescripcion());
    }
}