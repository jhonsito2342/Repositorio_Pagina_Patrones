
package co.edu.udistrital.view;


import java.util.Scanner;

public class VistaPC {
    private Scanner scanner;

    public VistaPC() {
        this.scanner = new Scanner(System.in);
    }

    public void mostrarBienvenida() {
        System.out.println("\n=== ENSAMBLADORA DE PC (DECORATOR) ===");
        System.out.println("Seleccione componentes para su PC:\n");
    }

    public void mostrarComponentes() {
        System.out.println("1. Añadir 16GB RAM");
        System.out.println("2. Añadir SSD 1TB");
        System.out.println("3. Añadir Tarjeta de Video RTX 3080");
        System.out.println("4. Añadir Sistema de Refrigeración Líquida");
        System.out.println("0. Finalizar configuración");
        System.out.print("Seleccione: ");
    }

    public int leerOpcion() {
        return scanner.nextInt();
    }

    public void mostrarError() {
        System.out.println("¡Opción no válida!");
    }

    public void mostrarConfiguracion(String descripcion) {
        System.out.println("\n=== SU CONFIGURACIÓN FINAL ===");
        System.out.println(descripcion);
        System.out.println("\n¡PC lista para ensamblar!");
    }
}