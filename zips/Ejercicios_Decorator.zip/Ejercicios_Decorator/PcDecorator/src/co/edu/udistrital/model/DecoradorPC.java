package co.edu.udistrital.model;




public abstract class DecoradorPC extends ComputadoraBase {
    @Override
    public abstract String getDescripcion();
}