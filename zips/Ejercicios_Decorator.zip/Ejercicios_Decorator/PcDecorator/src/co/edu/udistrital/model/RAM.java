
package co.edu.udistrital.model;





public class RAM extends DecoradorPC {
    private ComputadoraBase pc;

    public RAM(ComputadoraBase pc) {
        this.pc = pc;
    }

    @Override
    public String getDescripcion() {
        return pc.getDescripcion() + " + 16GB RAM DDR4";
    }
}