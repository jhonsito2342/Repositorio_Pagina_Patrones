/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */


public class YouTubeReal implements YouTubeService {
    private String nombreCanal;
    
    public YouTubeReal(String nombreCanal) {
        this.nombreCanal = nombreCanal;
    }
    
    @Override
    public void verVideo(String videoId) {
        System.out.println("[SERVICIO REAL] Reproduciendo video " + videoId + " del canal " + nombreCanal);
    }
    
    @Override
    public String getNombreCanal() {
        return nombreCanal;
    }
    
    @Override
    public boolean tieneConexion() {
        // En una implementación real, esto verificaría la conexión real
        return true;
    }
}