/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.view;


import java.util.Scanner;

/**
 *
 * @author Jhon
 */


public class VistaYouTube {
    private Scanner scanner;
    
    public VistaYouTube() {
        this.scanner = new Scanner(System.in);
    }
    
    public void mostrarMenu() {
        System.out.println("\n--- APLICACIÓN DE YOUTUBE ---");
        System.out.println("1. Ver video");
        System.out.println("2. Cambiar estado de conexión");
        System.out.println("3. Mostrar información del canal");
        System.out.println("4. Salir");
        System.out.print("Seleccione opción: ");
    }
    
    public int leerOpcion() {
        return scanner.nextInt();
    }
    
    public String leerVideoId() {
        System.out.print("Ingrese el ID del video: ");
        scanner.nextLine(); // Limpiar buffer
        return scanner.nextLine();
    }
    
    public boolean leerEstadoConexion() {
        System.out.print("¿Conexión activa? (s/n): ");
        String respuesta = scanner.next();
        return respuesta.equalsIgnoreCase("s");
    }
    
    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
    
    public void mostrarInfoCanal(String info) {
        System.out.println("\nInformación del canal:");
        System.out.println(info);
    }
}