/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.controller;

import co.edu.udistrital.model.YouTubeReal;
import co.edu.udistrital.model.YouTubeProxy;
import co.edu.udistrital.view.VistaYouTube;
import co.edu.udistrital.model.YouTubeService;

/**
 *
 * @author Jhon
 */


public class YouTubeController {
    private VistaYouTube vista;
    private YouTubeProxy youTubeProxy;
    
    public YouTubeController() {
        this.vista = new VistaYouTube();
        // Creamos el servicio real y el proxy
        YouTubeService youTubeReal = new YouTubeReal("Programación con Patrones");
        this.youTubeProxy = new YouTubeProxy(youTubeReal, true);
        
        // Mensajes iniciales (antes estaban en el Main)
        vista.mostrarMensaje("PROXY DE YOUTUBER - CONTROL DE REPRODUCCIÓN");
        vista.mostrarMensaje("=========================================");
    }
    
    public void iniciar() {
        int opcion;
        do {
            vista.mostrarMenu();
            opcion = vista.leerOpcion();
            
            switch(opcion) {
                case 1:
                    verVideo();
                    break;
                case 2:
                    cambiarConexion();
                    break;
                case 3:
                    mostrarInfoCanal();
                    break;
                case 4:
                    vista.mostrarMensaje("Saliendo de la aplicación...");
                    break;
                default:
                    vista.mostrarMensaje("Opción no válida");
            }
        } while(opcion != 4);
    }
    
    private void verVideo() {
        String videoId = vista.leerVideoId();
        youTubeProxy.verVideo(videoId);
    }
    
    private void cambiarConexion() {
        boolean nuevoEstado = vista.leerEstadoConexion();
        youTubeProxy.setConexionActiva(nuevoEstado);
        vista.mostrarMensaje("Estado de conexión actualizado: " + (nuevoEstado ? "CONECTADO" : "SIN CONEXIÓN"));
    }
    
    private void mostrarInfoCanal() {
        vista.mostrarInfoCanal("Canal: " + youTubeProxy.getNombreCanal());
    }
}