/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */
public class YouTubeProxy implements YouTubeService {
    private YouTubeService youTubeReal;
    private boolean conexionActiva;
    
    public YouTubeProxy(YouTubeService youTubeReal, boolean conexionInicial) {
        this.youTubeReal = youTubeReal;
        this.conexionActiva = conexionInicial;
    }
    
    @Override
    public void verVideo(String videoId) {
        if(tieneConexion()) {
            youTubeReal.verVideo(videoId);
        } else {
            System.out.println(getMensajeSinConexion());
        }
    }
    
    @Override
    public String getNombreCanal() {
        return youTubeReal.getNombreCanal();
    }
    
    @Override
    public boolean tieneConexion() {
        return conexionActiva;
    }
    
    public void setConexionActiva(boolean estado) {
        this.conexionActiva = estado;
    }
    
    private String getMensajeSinConexion() {
        return "[PROXY] Conéctate para seguir viendo a tu creador favorito: " + getNombreCanal();
    }
}