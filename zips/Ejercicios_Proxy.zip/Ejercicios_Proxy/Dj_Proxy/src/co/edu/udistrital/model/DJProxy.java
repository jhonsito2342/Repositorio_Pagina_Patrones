/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

import java.util.List;

/**
 *
 * @author Jhon
 */



public class DJProxy implements DJService {
    private DJReal djReal;
    
    public DJProxy(DJReal djReal) {
        this.djReal = djReal;
    }
    
    @Override
    public void agregarCancion(String cancion) {
        if(!cancionExiste(cancion)) {
            djReal.agregarCancion(cancion);
        } else {
            System.out.println(getMensajeCancionDuplicada(cancion));
        }
    }
    
    @Override
    public List<String> getPlaylist() {
        return djReal.getPlaylist();
    }
    
    @Override
    public boolean cancionExiste(String cancion) {
        return djReal.cancionExiste(cancion);
    }
    
    private String getMensajeCancionDuplicada(String cancion) {
        return "[PROXY DJ] La canción '" + cancion + "' ya está en la playlist";
    }
}