/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.controller;

import co.edu.udistrital.model.DJProxy;
import co.edu.udistrital.model.DJReal;
import co.edu.udistrital.view.VistaDJ;
import co.edu.udistrital.model.DJService;
import java.util.List;

/**
 *
 * @author Jhon
 */



public class DJController {
    private VistaDJ vista;
    private DJService djService;
    
    public DJController() {
        this.vista = new VistaDJ();
        // Creamos el DJ real y el proxy que lo controla
        this.djService = new DJProxy(new DJReal());
        
        // Mensajes iniciales
        vista.mostrarMensaje("PROXY DE DJ EN FIESTA - CONTROL DE PLAYLIST");
        vista.mostrarMensaje("=========================================");
    }
    
    public void iniciar() {
        int opcion;
        do {
            vista.mostrarMenu();
            opcion = vista.leerOpcion();
            
            switch(opcion) {
                case 1:
                    agregarCancion();
                    break;
                case 2:
                    mostrarPlaylist();
                    break;
                case 3:
                    vista.mostrarMensaje("Cerrando el sistema de DJ...");
                    break;
                default:
                    vista.mostrarMensaje("Opción no válida");
            }
        } while(opcion != 3);
    }
    
    private void agregarCancion() {
        String cancion = vista.leerCancion();
        djService.agregarCancion(cancion);
    }
    
    private void mostrarPlaylist() {
        List<String> playlist = djService.getPlaylist();
        vista.mostrarPlaylist(playlist);
    }
}