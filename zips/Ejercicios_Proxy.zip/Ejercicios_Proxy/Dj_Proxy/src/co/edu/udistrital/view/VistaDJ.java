/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.view;


import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Jhon
 */


public class VistaDJ {
    private Scanner scanner;
    
    public VistaDJ() {
        this.scanner = new Scanner(System.in);
    }
    
    public void mostrarMenu() {
        System.out.println("\n--- SISTEMA DE DJ EN FIESTA ---");
        System.out.println("1. Agregar canción");
        System.out.println("2. Ver playlist actual");
        System.out.println("3. Salir");
        System.out.print("Seleccione opción: ");
    }
    
    public int leerOpcion() {
        return scanner.nextInt();
    }
    
    public String leerCancion() {
        System.out.print("Ingrese el nombre de la canción: ");
        scanner.nextLine(); // Limpiar buffer
        return scanner.nextLine();
    }
    
    public void mostrarPlaylist(List<String> playlist) {
        System.out.println("\n--- PLAYLIST ACTUAL ---");
        if(playlist.isEmpty()) {
            System.out.println("La playlist está vacía");
        } else {
            for(int i = 0; i < playlist.size(); i++) {
                System.out.println((i+1) + ". " + playlist.get(i));
            }
        }
        System.out.println("----------------------");
    }
    
    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
}