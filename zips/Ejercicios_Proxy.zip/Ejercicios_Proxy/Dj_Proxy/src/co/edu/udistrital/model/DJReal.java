/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Jhon
 */


public class DJReal implements DJService {
    private List<String> playlist;
    
    public DJReal() {
        this.playlist = new ArrayList<>();
    }
    
    @Override
    public void agregarCancion(String cancion) {
        System.out.println("[DJ REAL] Agregando canción: " + cancion);
        playlist.add(cancion);
    }
    
    @Override
    public List<String> getPlaylist() {
        return new ArrayList<>(playlist); // Retorna copia para proteger la lista original
    }
    
    @Override
    public boolean cancionExiste(String cancion) {
        return playlist.contains(cancion);
    }
}