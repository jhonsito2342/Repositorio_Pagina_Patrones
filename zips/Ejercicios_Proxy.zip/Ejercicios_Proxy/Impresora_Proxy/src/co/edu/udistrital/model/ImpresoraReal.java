/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */

public class ImpresoraReal implements Impresora {
    private int hojasDisponibles;
    private int nivelTinta;
    
    public ImpresoraReal(int hojasDisponibles, int nivelTinta) {
        this.hojasDisponibles = hojasDisponibles;
        this.nivelTinta = nivelTinta;
    }
    
    @Override
    public void imprimir(String documento) {
        System.out.println("[IMPRESORA REAL] Imprimiendo documento: " + documento);
        hojasDisponibles--;
        nivelTinta -= 10;
    }
    
    @Override
    public boolean tieneRecursos() {
        return hojasDisponibles > 0 && nivelTinta > 0;
    }
    
    @Override
    public String getEstado() {
        return "Hojas: " + hojasDisponibles + " | Tinta: " + nivelTinta + "%";
    }
    
    // Métodos para gestión interna
    public void recargarHojas(int cantidad) {
        hojasDisponibles += cantidad;
    }
    
    public void recargarTinta(int cantidad) {
        nivelTinta = Math.min(100, nivelTinta + cantidad);
    }

    public int getHojasDisponibles() {
        return hojasDisponibles;
    }

    public int getNivelTinta() {
        return nivelTinta;
    }
    
}