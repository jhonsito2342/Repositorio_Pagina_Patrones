/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.view;


import java.util.Scanner;

/**
 *
 * @author Jhon
 */


public class VistaImpresora {
    private Scanner scanner;
    
    public VistaImpresora() {
        this.scanner = new Scanner(System.in);
    }
    
    public void mostrarMenu() {
        System.out.println("\n--- SISTEMA DE IMPRESIÓN ESCOLAR ---");
        System.out.println("1. Imprimir documento");
        System.out.println("2. Ver estado de la impresora");
        System.out.println("3. Recargar recursos");
        System.out.println("4. Salir");
        System.out.print("Seleccione opción: ");
    }
    
    public int leerOpcion() {
        return scanner.nextInt();
    }
    
    public String leerDocumento() {
        System.out.print("Ingrese el documento a imprimir: ");
        scanner.nextLine(); // Limpiar buffer
        return scanner.nextLine();
    }
    
    public void mostrarEstado(String estado) {
        System.out.println("\nEstado actual:");
        System.out.println(estado);
    }
    
    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
    
    public int leerCantidad(String mensaje) {
        System.out.print(mensaje);
        return scanner.nextInt();
    }
}