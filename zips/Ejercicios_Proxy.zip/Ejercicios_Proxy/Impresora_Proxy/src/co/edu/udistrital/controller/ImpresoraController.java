/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.controller;

import co.edu.udistrital.model.Impresora;
import co.edu.udistrital.model.ImpresoraProxy;
import co.edu.udistrital.model.ImpresoraReal;
import co.edu.udistrital.view.VistaImpresora;

/**
 *
 * @author Jhon
 */
public class ImpresoraController {

    private VistaImpresora vista;
    private Impresora impresora;

    public ImpresoraController() {
        this.vista = new VistaImpresora();
        // Creamos la impresora real con 10 hojas y 50% de tinta
        ImpresoraReal real = new ImpresoraReal(10, 50);
        // El proxy controlará el acceso
        this.impresora = new ImpresoraProxy(real);
    }

    public void iniciar() {
        vista.mostrarMensaje("PROXY DE IMPRESORA ESCOLAR - CONTROL DE IMPRESIONES");
        vista.mostrarMensaje("=================================================");
        int opcion;
        do {
            vista.mostrarMenu();
            opcion = vista.leerOpcion();

            switch (opcion) {
                case 1:
                    imprimirDocumento();
                    break;
                case 2:
                    verEstado();
                    break;
                case 3:
                    recargarRecursos();
                    break;
                case 4:
                    vista.mostrarMensaje("Saliendo del sistema...");
                    break;
                default:
                    vista.mostrarMensaje("Opción no válida");
            }
        } while (opcion != 4);
    }

    private void imprimirDocumento() {
        String documento = vista.leerDocumento();
        impresora.imprimir(documento);
    }

    private void verEstado() {
        vista.mostrarEstado(impresora.getEstado());
    }

    private void recargarRecursos() {
        vista.mostrarMensaje("\n--- RECARGAR RECURSOS ---");
        int hojas = vista.leerCantidad("Cantidad de hojas a agregar: ");
        int tinta = vista.leerCantidad("Porcentaje de tinta a agregar: ");

        // Nota: En una implementación real, esto debería hacerse a través del proxy
        // o tener métodos específicos en la interfaz
        if (impresora instanceof ImpresoraProxy) {
            ImpresoraProxy proxy = (ImpresoraProxy) impresora;
            proxy.recargarHojas(hojas);
            proxy.recargarTinta(tinta);
            vista.mostrarMensaje("Recursos recargados con éxito!");
        } else {
            vista.mostrarMensaje("Error: No se puede recargar en esta configuración");
        }
    }
}
