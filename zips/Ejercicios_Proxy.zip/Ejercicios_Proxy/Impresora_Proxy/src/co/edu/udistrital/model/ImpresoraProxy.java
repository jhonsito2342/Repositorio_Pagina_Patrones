/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */


public class ImpresoraProxy implements Impresora {
    private ImpresoraReal impresoraReal;
    
    public ImpresoraProxy(ImpresoraReal impresoraReal) {
        this.impresoraReal = impresoraReal;
    }
    
    @Override
    public void imprimir(String documento) {
        if(tieneRecursos()) {
            impresoraReal.imprimir(documento);
        } else {
            System.out.println("[PROXY] Error: " + getMensajeError());
        }
    }
    
    @Override
    public boolean tieneRecursos() {
        return impresoraReal.tieneRecursos();
    }
    
    @Override
    public String getEstado() {
        return impresoraReal.getEstado();
    }
    
    // Métodos para recarga a través del proxy
    public void recargarHojas(int cantidad) {
        impresoraReal.recargarHojas(cantidad);
        System.out.println("[PROXY] Recargadas " + cantidad + " hojas");
    }
    
    public void recargarTinta(int cantidad) {
        impresoraReal.recargarTinta(cantidad);
        System.out.println("[PROXY] Recargado " + cantidad + "% de tinta");
    }
    
    // Métodos para acceder a los valores reales (necesarios para el proxy)
    public int getHojasDisponibles() {
        return impresoraReal.getHojasDisponibles();
    }
    
    public int getNivelTinta() {
        return impresoraReal.getNivelTinta();
    }
    
    private String getMensajeError() {
        if(impresoraReal.getHojasDisponibles() <= 0) {
            return "¡No hay papel! Por favor recargar.";
        } else if(impresoraReal.getNivelTinta() <= 0) {
            return "¡Tinta agotada! Reemplaza el cartucho.";
        }
        return "Error desconocido";
    }
}