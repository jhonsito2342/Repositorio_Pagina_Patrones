/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
import subject.Cryptocurrency;
import observer.*;

public class Main {

    public static void main(String[] args) {
        Cryptocurrency bitcoin = new Cryptocurrency("Bitcoin", 50000.0);

        // Crear observadores
        PriceObserver emailObserver = new EmailNotifier("trader@example.com");
        PriceObserver mobileObserver = new MobileAppNotifier("DEVICE-12345");
        PriceObserver alertSystem = new PriceAlertSystem(55000.0);

        // Registrar observadores
        bitcoin.addObserver(emailObserver);
        bitcoin.addObserver(mobileObserver);
        bitcoin.addObserver(alertSystem);

        System.out.println("=== Simulación de cambios de precio ===");
        bitcoin.setPrice(51000.0);
        bitcoin.setPrice(52000.0);
        bitcoin.setPrice(55500.0); // Debería disparar la alerta
        bitcoin.setPrice(53000.0);

        // Remover un observador
        bitcoin.removeObserver(mobileObserver);
        System.out.println("\n=== Después de remover observador móvil ===");
        bitcoin.setPrice(54000.0);
    }
}
