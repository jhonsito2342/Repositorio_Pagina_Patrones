/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package subject;

import observer.PriceObserver;
import java.util.ArrayList;
import java.util.List;

public class Cryptocurrency {
    private String name;
    private double currentPrice;
    private List<PriceObserver> observers = new ArrayList<>();
    
    public Cryptocurrency(String name, double initialPrice) {
        this.name = name;
        this.currentPrice = initialPrice;
    }
    
    public void addObserver(PriceObserver observer) {
        observers.add(observer);
    }
    
    public void removeObserver(PriceObserver observer) {
        observers.remove(observer);
    }
    
    public void setPrice(double newPrice) {
        if(newPrice != currentPrice) {
            currentPrice = newPrice;
            notifyObservers();
        }
    }
    
    private void notifyObservers() {
        for(PriceObserver observer : observers) {
            observer.update(name, currentPrice);
        }
    }
}
