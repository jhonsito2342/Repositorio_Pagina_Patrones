/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package observer;

public class PriceAlertSystem implements PriceObserver {

    private double alertThreshold;

    public PriceAlertSystem(double threshold) {
        this.alertThreshold = threshold;
    }

    @Override
    public void update(String cryptoName, double currentPrice) {
        if (currentPrice > alertThreshold) {
            System.out.printf("¡ALERTA! %s superó el umbral: $%.2f > $%.2f\n",
                    cryptoName, currentPrice, alertThreshold);
        }
    }
}
