/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package observer;

public class MobileAppNotifier implements PriceObserver {

    private String deviceId;

    public MobileAppNotifier(String deviceId) {
        this.deviceId = deviceId;
    }

    @Override
    public void update(String cryptoName, double currentPrice) {
        System.out.printf("Notificación push a dispositivo %s: %s = $%.2f\n",
                deviceId, cryptoName, currentPrice);
    }
}
