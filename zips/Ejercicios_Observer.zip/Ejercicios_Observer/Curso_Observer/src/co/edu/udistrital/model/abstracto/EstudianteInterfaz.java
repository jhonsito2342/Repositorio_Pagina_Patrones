package co.edu.udistrital.model.abstracto;

public interface EstudianteInterfaz {
	//Metodo para actualizar cualquier cambio del Objeto Observado, en este caso, el Curso
	public String actualizar();
}
