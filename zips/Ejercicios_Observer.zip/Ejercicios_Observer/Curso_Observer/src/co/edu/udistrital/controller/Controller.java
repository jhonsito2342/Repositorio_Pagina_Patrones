package co.edu.udistrital.controller;

import co.edu.udistrital.model.concreto.CursoConcreto;
import co.edu.udistrital.model.concreto.EstudianteConcreto;
import co.edu.udistrital.view.Vista;

public class Controller {
	//Objeto tipo Vista para las impresiones en consola 
	private Vista vista;
	
	//Constructor que inicializa el objeto tipo Vista
	public Controller()
	{
		this.vista = new Vista();
	}
	
	//Metodo que controla la entrada y salida de datos de la aplicación
	public void run()
	{
		//Variables para los nombres de los estudiantes predeterminados
		String nombre1 =  "Juanito";
		String nombre2 =  "Pepito";
		String nombre3 = "María";
		
		//Variables para variar el nombre de la asignacion y la continuidad en el programa
		String asignacion = "";
		int cont = 0;
		
		//cursos predeterminados
		CursoConcreto curso1 = new CursoConcreto("Modelos de programación");
		CursoConcreto curso2 = new CursoConcreto("Calculo");
		
		//estudiante predeterminados
		EstudianteConcreto est1 = new EstudianteConcreto(curso1, nombre1);
		EstudianteConcreto est2 = new EstudianteConcreto(curso1, nombre2);		
		EstudianteConcreto est3 = new EstudianteConcreto(curso2, nombre3);
		
		//Agregar los estudiantes a los cursos
		curso1.agregar(est1);
		curso1.agregar(est2);
		
		curso2.agregar(est3);
		
		//Bucle para la ejecucion y continuidad de la aplicacion
		while(true)
		{
			int decisionCurso = Integer.parseInt(vista.leerCadenaDeTexto("Bienvenid@, ¿a qué curso desea acceder?"
					+ "\n1. Modelos de programación."
					+ "\n2. Cálculo."));
		
			switch(decisionCurso)
			{
			case 1:
				asignacion = vista.leerCadenaDeTexto("Ingrese el nombre de la nueva asignación: ");
				vista.mostrarInformacion(curso1.nuevaAsignacion(asignacion));
				vista.mostrarInformacion("Nueva asignacion creada: "  + curso1.getUltimaAsignacion());
				
				cont = Integer.parseInt(vista.leerCadenaDeTexto("¿Desea continuar en el programa?"
						+ "\n1. si"
						+ "\n2. no"));
				
				if(cont == 1)
				{
					cont = 0;
					asignacion = "";
					continue;
				}
				else
				{
					vista.mostrarInformacion("¡Gracias por usar el programa!");
					System.exit(0);
				}
			case 2:
				asignacion = vista.leerCadenaDeTexto("Ingrese el nombre de la nueva asignación: ");
				vista.mostrarInformacion(curso2.nuevaAsignacion(asignacion));
				vista.mostrarInformacion("Nueva asignacion creada: "  + curso2.getUltimaAsignacion());
				
				cont = Integer.parseInt(vista.leerCadenaDeTexto("¿Desea continuar en el programa?"
						+ "\n1. si"
						+ "\n2. no"));
				
				if(cont == 1)
				{
					cont = 0;
					asignacion = "";
					continue;
				}
				else
				{
					vista.mostrarInformacion("¡Gracias por usar el programa!");
					System.exit(0);
				}
			}
		}
	}
}

