package co.edu.udistrital.model.abstracto;

import co.edu.udistrital.model.concreto.EstudianteConcreto;

public interface CursoInterfaz {
	//Metodos para agregar y eliminar observadores(Estudiantes) 
	public String agregar(EstudianteConcreto estC);
	public String borrar(EstudianteConcreto estC);
	//Metodo que llamará al metodo actualizar() de todos los observadores(Estudiantes)
	public String notificar();
}
