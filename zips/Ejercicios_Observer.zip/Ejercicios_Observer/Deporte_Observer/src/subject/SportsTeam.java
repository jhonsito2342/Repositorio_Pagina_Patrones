/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package subject;

import observer.TeamObserver;
import java.util.ArrayList;
import java.util.List;

public class SportsTeam {

    private String teamName;
    private List<TeamObserver> observers = new ArrayList<>();

    public SportsTeam(String teamName) {
        this.teamName = teamName;
    }

    public void addObserver(TeamObserver observer) {
        observers.add(observer);
    }

    public void removeObserver(TeamObserver observer) {
        observers.remove(observer);
    }

    public void notifyObservers(String eventType, String eventDetails) {
        for (TeamObserver observer : observers) {
            observer.update(teamName, eventType, eventDetails);
        }
    }

    public void scoreGoal(String player) {
        notifyObservers("GOL", "¡" + player + " anotó un gol!");
    }

    public void playerInjured(String player, String injury) {
        notifyObservers("LESIÓN", player + " se lesionó: " + injury);
    }

    public void gameStarted(String opponent) {
        notifyObservers("INICIO", "Partido vs " + opponent + " comenzó");
    }
}
