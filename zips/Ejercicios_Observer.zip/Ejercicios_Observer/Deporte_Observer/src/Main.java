/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
import subject.SportsTeam;
import observer.*;

public class Main {

    public static void main(String[] args) {
        SportsTeam team = new SportsTeam("Águilas FC");

        // Crear observadores
        TeamObserver fan1 = new Fan("Juan Pérez");
        TeamObserver fan2 = new Fan("María García");
        TeamObserver reporter = new NewsReporter("Deportes TV");
        TeamObserver coach = new CoachDashboard();

        // Registrar observadores
        team.addObserver(fan1);
        team.addObserver(fan2);
        team.addObserver(reporter);
        team.addObserver(coach);

        System.out.println("=== SIMULACIÓN DE PARTIDO ===");
        team.gameStarted("Tigres Unidos");
        team.scoreGoal("Carlos Ruiz");
        team.playerInjured("Luis Méndez", "Esguince de tobillo");

        // Remover un fan durante el juego
        team.removeObserver(fan2);
        System.out.println("\n=== SEGUNDO TIEMPO ===");
        team.scoreGoal("Ana López");
    }
}
