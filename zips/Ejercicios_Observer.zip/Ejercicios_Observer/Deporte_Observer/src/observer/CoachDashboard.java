/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package observer;

public class CoachDashboard implements TeamObserver {
    @Override
    public void update(String teamName, String eventType, String eventDetails) {
        System.out.println("\n=== TABLERO DEL ENTRENADOR ===");
        System.out.println("Evento: " + eventType);
        System.out.println("Equipo: " + teamName);
        System.out.println("Detalles: " + eventDetails);
        System.out.println("=== Análisis estratégico... ===");
    }
}