/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package observer;

public class Fan implements TeamObserver {

    private String name;

    public Fan(String name) {
        this.name = name;
    }

    @Override
    public void update(String teamName, String eventType, String eventDetails) {
        System.out.printf("[Fan %s] %s: %s - %s\n",
                name, teamName, eventType, eventDetails);
    }
}
