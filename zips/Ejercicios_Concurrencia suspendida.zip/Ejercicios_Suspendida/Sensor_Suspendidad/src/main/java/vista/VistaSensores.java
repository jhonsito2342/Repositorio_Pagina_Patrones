/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import modelo.LecturaSensor;

public class VistaSensores {

    public void mostrarMenu() {
        System.out.println("\n=== MONITOR DE SENSORES ===");
        System.out.println("1. Agregar sensor");
        System.out.println("2. Suspender sensor");
        System.out.println("3. Reanudar sensor");
        System.out.println("4. Detener sensor");
        System.out.println("5. Ver lectura");
        System.out.println("6. Salir");
        System.out.print("Seleccione opción: ");
    }

    public String pedirIdSensor() {
        System.out.print("Ingrese ID del sensor: ");
        return System.console().readLine();
    }

    public void mostrarLectura(LecturaSensor lectura) {
        System.out.println(lectura != null ? lectura.toString() : "Sensor no encontrado");
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
}
