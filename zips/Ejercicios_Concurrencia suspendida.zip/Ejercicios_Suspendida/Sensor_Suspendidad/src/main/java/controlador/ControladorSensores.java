/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.MonitorSensores;
import modelo.LecturaSensor;
import vista.VistaSensores;

public class ControladorSensores {

    private final MonitorSensores monitor;
    private final VistaSensores vista;

    public ControladorSensores() {
        this.monitor = new MonitorSensores();
        this.vista = new VistaSensores();
        iniciar();
    }

    private void iniciar() {
        int opcion;
        do {
            vista.mostrarMenu();
            opcion = Integer.parseInt(System.console().readLine());
            String id;

            switch (opcion) {
                case 1:
                    id = vista.pedirIdSensor();
                    monitor.agregarSensor(id);
                    vista.mostrarMensaje("Sensor " + id + " agregado");
                    break;

                case 2:
                    id = vista.pedirIdSensor();
                    monitor.suspenderSensor(id);
                    vista.mostrarMensaje("Sensor " + id + " suspendido");
                    break;

                case 3:
                    id = vista.pedirIdSensor();
                    monitor.reanudarSensor(id);
                    vista.mostrarMensaje("Sensor " + id + " reanudado");
                    break;

                case 4:
                    id = vista.pedirIdSensor();
                    monitor.detenerSensor(id);
                    vista.mostrarMensaje("Sensor " + id + " detenido");
                    break;

                case 5:
                    id = vista.pedirIdSensor();
                    vista.mostrarLectura(monitor.getLectura(id));
                    break;
            }
        } while (opcion != 6);
    }
}
