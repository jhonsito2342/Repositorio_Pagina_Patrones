/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class LecturaSensor {

    private final String sensorId;
    private final double valor;

    public LecturaSensor(String sensorId, double valor) {
        this.sensorId = sensorId;
        this.valor = valor;
    }

    public String getSensorId() {
        return sensorId;
    }

    public double getValor() {
        return valor;
    }

    @Override
    public String toString() {
        return String.format("Sensor %s: %.2f", sensorId, valor);
    }
}
