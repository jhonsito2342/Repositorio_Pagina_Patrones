/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.HashMap;
import java.util.Map;

public class MonitorSensores {

    private final Map<String, Thread> hilosSensores = new HashMap<>();
    private final Map<String, Sensor> sensores = new HashMap<>();

    public void agregarSensor(String id) {
        Sensor sensor = new Sensor(id);
        Thread hilo = new Thread(sensor);
        sensores.put(id, sensor);
        hilosSensores.put(id, hilo);
        hilo.start();
    }

    public void suspenderSensor(String id) {
        if (sensores.containsKey(id)) {
            sensores.get(id).suspender();
        }
    }

    public void reanudarSensor(String id) {
        if (sensores.containsKey(id)) {
            sensores.get(id).reanudar();
        }
    }

    public void detenerSensor(String id) {
        if (sensores.containsKey(id)) {
            sensores.get(id).detener();
        }
    }

    public LecturaSensor getLectura(String id) {
        return sensores.containsKey(id) ? sensores.get(id).getUltimaLectura() : null;
    }
}
