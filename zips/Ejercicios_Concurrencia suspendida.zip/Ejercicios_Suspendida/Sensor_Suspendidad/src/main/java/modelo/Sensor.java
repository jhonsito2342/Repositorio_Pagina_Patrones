/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.Random;

public class Sensor implements Runnable {

    private final String id;
    private volatile boolean suspendido = false;
    private volatile boolean activo = true;
    private double ultimaLectura;
    private final Random random = new Random();

    public Sensor(String id) {
        this.id = id;
    }

    public synchronized void suspender() {
        suspendido = true;
    }

    public synchronized void reanudar() {
        suspendido = false;
        notify();
    }

    public void detener() {
        activo = false;
        reanudar();
    }

    public LecturaSensor getUltimaLectura() {
        return new LecturaSensor(id, ultimaLectura);
    }

    @Override
    public void run() {
        try {
            while (activo) {
                synchronized (this) {
                    while (suspendido) {
                        wait();
                    }
                }

                // Simular lectura de sensor
                ultimaLectura = 20 + (random.nextDouble() * 10); // Valores entre 20-30
                System.out.println("Sensor " + id + " leyó: " + ultimaLectura);

                Thread.sleep(2000);
            }
            System.out.println("Sensor " + id + " detenido");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.out.println("Sensor " + id + " interrumpido");
        }
    }
}
