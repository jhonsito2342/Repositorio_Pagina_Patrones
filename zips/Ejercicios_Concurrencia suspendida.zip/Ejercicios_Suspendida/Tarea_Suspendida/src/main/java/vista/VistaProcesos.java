/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

public class VistaProcesos {

    public void mostrarMenu() {
        System.out.println("\n=== MENÚ PROCESOS ===");
        System.out.println("1. Agregar proceso");
        System.out.println("2. Suspender proceso");
        System.out.println("3. Reanudar proceso");
        System.out.println("4. Detener proceso");
        System.out.println("5. Salir");
        System.out.print("Seleccione opción: ");
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }

    public String pedirIdProceso() {
        System.out.print("Ingrese ID del proceso: ");
        return System.console().readLine();
    }
}
