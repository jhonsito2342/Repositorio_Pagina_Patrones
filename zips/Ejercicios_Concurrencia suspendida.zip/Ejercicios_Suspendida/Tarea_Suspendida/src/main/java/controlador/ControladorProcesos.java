/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */package controlador;

import modelo.GestorProcesos;
import vista.VistaProcesos;

public class ControladorProcesos {

    private final GestorProcesos gestor;
    private final VistaProcesos vista;

    public ControladorProcesos() {
        this.gestor = new GestorProcesos();
        this.vista = new VistaProcesos();
        iniciar();
    }

    private void iniciar() {
        int opcion;
        do {
            vista.mostrarMenu();
            opcion = Integer.parseInt(System.console().readLine());

            switch (opcion) {
                case 1:
                    String idNuevo = vista.pedirIdProceso();
                    gestor.agregarProceso(idNuevo);
                    vista.mostrarMensaje("Proceso " + idNuevo + " creado");
                    break;

                case 2:
                    String idSuspender = vista.pedirIdProceso();
                    gestor.suspenderProceso(idSuspender);
                    vista.mostrarMensaje("Proceso " + idSuspender + " suspendido");
                    break;

                case 3:
                    String idReanudar = vista.pedirIdProceso();
                    gestor.reanudarProceso(idReanudar);
                    vista.mostrarMensaje("Proceso " + idReanudar + " reanudado");
                    break;

                case 4:
                    String idDetener = vista.pedirIdProceso();
                    gestor.detenerProceso(idDetener);
                    vista.mostrarMensaje("Proceso " + idDetener + " detenido");
                    break;
            }
        } while (opcion != 5);
    }
}
