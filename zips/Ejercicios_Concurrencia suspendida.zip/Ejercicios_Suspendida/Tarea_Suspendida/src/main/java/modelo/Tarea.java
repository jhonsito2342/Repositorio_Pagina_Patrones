/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class Tarea {

    private String cuentaOrigen;
    private String cuentaDestino;
    private double monto;

    public Tarea(String origen, String destino, double monto) {
        this.cuentaOrigen = origen;
        this.cuentaDestino = destino;
        this.monto = monto;
    }

    public String getCuentaOrigen() {
        return cuentaOrigen;
    }

    public String getCuentaDestino() {
        return cuentaDestino;
    }

    public double getMonto() {
        return monto;
    }
}
