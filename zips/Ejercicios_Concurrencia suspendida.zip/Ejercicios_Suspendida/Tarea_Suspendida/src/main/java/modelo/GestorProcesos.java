/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.HashMap;
import java.util.Map;

public class GestorProcesos {

    private final Map<String, Thread> procesos = new HashMap<>();
    private final Map<String, Proceso> objetosProceso = new HashMap<>();

    public void agregarProceso(String id) {
        Proceso proceso = new Proceso(id);
        Thread hilo = new Thread(proceso);
        objetosProceso.put(id, proceso);
        procesos.put(id, hilo);
        hilo.start();
    }

    public void suspenderProceso(String id) {
        if (objetosProceso.containsKey(id)) {
            objetosProceso.get(id).suspender();
        }
    }

    public void reanudarProceso(String id) {
        if (objetosProceso.containsKey(id)) {
            objetosProceso.get(id).reanudar();
        }
    }

    public void detenerProceso(String id) {
        if (objetosProceso.containsKey(id)) {
            objetosProceso.get(id).detener();
        }
    }
}
