/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class Proceso implements Runnable {

    private final String id;
    private volatile boolean suspendido = false;
    private volatile boolean enEjecucion = true;

    public Proceso(String id) {
        this.id = id;
    }

    public void suspender() {
        suspendido = true;
    }

    public synchronized void reanudar() {
        suspendido = false;
        notify();
    }

    public void detener() {
        enEjecucion = false;
        reanudar(); // Para salir del wait()
    }

    @Override
    public void run() {
        while (enEjecucion) {
            try {
                synchronized (this) {
                    while (suspendido) {
                        wait();
                    }
                }

                System.out.println("Proceso " + id + " trabajando...");
                Thread.sleep(1000); // Simular trabajo

            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.out.println("Proceso " + id + " interrumpido");
            }
        }
        System.out.println("Proceso " + id + " finalizado");
    }
}
