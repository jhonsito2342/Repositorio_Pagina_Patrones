/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

public class VistaDescargas {

    public void mostrarMenu() {
        System.out.println("\n=== GESTOR DE DESCARGAS ===");
        System.out.println("1. Iniciar descarga");
        System.out.println("2. Pausar descarga");
        System.out.println("3. Reanudar descarga");
        System.out.println("4. Cancelar descarga");
        System.out.println("5. Ver progreso");
        System.out.println("6. Salir");
        System.out.print("Seleccione opción: ");
    }

    public String pedirURL() {
        System.out.print("Ingrese URL: ");
        return System.console().readLine();
    }

    public void mostrarProgreso(String url, int progreso) {
        System.out.println(url + " - Progreso: " + progreso + "%");
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
}
