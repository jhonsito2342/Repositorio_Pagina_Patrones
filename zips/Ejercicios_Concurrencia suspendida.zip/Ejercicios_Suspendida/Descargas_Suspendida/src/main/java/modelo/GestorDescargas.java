/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.HashMap;
import java.util.Map;

public class GestorDescargas {

    private final Map<String, Thread> hilosDescarga = new HashMap<>();
    private final Map<String, Descarga> descargas = new HashMap<>();

    public void iniciarDescarga(String url) {
        Descarga descarga = new Descarga(url);
        Thread hilo = new Thread(descarga);
        descargas.put(url, descarga);
        hilosDescarga.put(url, hilo);
        hilo.start();
    }

    public void pausarDescarga(String url) {
        if (descargas.containsKey(url)) {
            descargas.get(url).pausar();
        }
    }

    public void reanudarDescarga(String url) {
        if (descargas.containsKey(url)) {
            descargas.get(url).reanudar();
        }
    }

    public void cancelarDescarga(String url) {
        if (descargas.containsKey(url)) {
            descargas.get(url).cancelar();
        }
    }

    public int getProgreso(String url) {
        return descargas.containsKey(url) ? descargas.get(url).getProgreso() : 0;
    }
}
