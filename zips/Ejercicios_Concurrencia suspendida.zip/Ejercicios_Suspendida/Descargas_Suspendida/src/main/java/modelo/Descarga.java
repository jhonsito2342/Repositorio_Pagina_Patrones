/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class Descarga implements Runnable {

    private final String url;
    private volatile boolean pausada = false;
    private volatile boolean cancelada = false;
    private int progreso = 0;

    public Descarga(String url) {
        this.url = url;
    }

    public synchronized void pausar() {
        pausada = true;
    }

    public synchronized void reanudar() {
        pausada = false;
        notify();
    }

    public void cancelar() {
        cancelada = true;
        reanudar(); // Para salir del wait()
    }

    public int getProgreso() {
        return progreso;
    }

    @Override
    public void run() {
        try {
            System.out.println("Iniciando descarga: " + url);

            while (progreso < 100 && !cancelada) {
                synchronized (this) {
                    while (pausada) {
                        wait();
                    }
                }

                Thread.sleep(500); // Simular descarga
                progreso += 5;
                System.out.println(url + " - Progreso: " + progreso + "%");
            }

            if (cancelada) {
                System.out.println("Descarga cancelada: " + url);
            } else {
                System.out.println("Descarga completada: " + url);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.out.println("Descarga interrumpida: " + url);
        }
    }
}
