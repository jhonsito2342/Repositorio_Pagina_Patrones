/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.GestorDescargas;
import vista.VistaDescargas;

public class ControladorDescargas {
    private final GestorDescargas gestor;
    private final VistaDescargas vista;

    public ControladorDescargas() {
        this.gestor = new GestorDescargas();
        this.vista = new VistaDescargas();
        iniciar();
    }

    private void iniciar() {
        int opcion;
        do {
            vista.mostrarMenu();
            opcion = Integer.parseInt(System.console().readLine());
            String url;
            
            switch (opcion) {
                case 1:
                    url = vista.pedirURL();
                    gestor.iniciarDescarga(url);
                    break;
                    
                case 2:
                    url = vista.pedirURL();
                    gestor.pausarDescarga(url);
                    break;
                    
                case 3:
                    url = vista.pedirURL();
                    gestor.reanudarDescarga(url);
                    break;
                    
                case 4:
                    url = vista.pedirURL();
                    gestor.cancelarDescarga(url);
                    break;
                    
                case 5:
                    url = vista.pedirURL();
                    vista.mostrarProgreso(url, gestor.getProgreso(url));
                    break;
            }
        } while (opcion != 6);
    }
}