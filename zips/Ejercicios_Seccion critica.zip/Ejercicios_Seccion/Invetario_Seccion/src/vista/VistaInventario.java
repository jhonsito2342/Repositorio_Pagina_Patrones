/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

public class VistaInventario {
    public void mostrarMenu() {
        System.out.println("\n=== SISTEMA DE INVENTARIO ===");
        System.out.println("1. Agregar producto");
        System.out.println("2. Ver stock");
        System.out.println("3. Transferir producto");
        System.out.println("4. Simular transferencias concurrentes");
        System.out.println("5. Salir");
    }

    public String obtenerIdProducto() {
        System.out.print("Ingrese ID del producto: ");
        return System.console().readLine();
    }

    public int obtenerCantidad() {
        System.out.print("Ingrese cantidad: ");
        return Integer.parseInt(System.console().readLine());
    }

    public void mostrarStock(String productoId, int stock) {
        System.out.println("Stock de " + productoId + ": " + stock);
    }

    public void mostrarResultado(boolean exito, String operacion) {
        System.out.println(operacion + (exito ? " exitosa" : " fallida"));
    }

    public int obtenerOpcion() {
        System.out.print("Seleccione una opción: ");
        return Integer.parseInt(System.console().readLine());
    }
}