/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.Almacen;
import modelo.Inventario;
import modelo.Producto;
import vista.VistaInventario;

public class ControladorInventario {

    private Almacen almacen1;
    private Almacen almacen2;
    private VistaInventario vista;

    public ControladorInventario() {
        this.almacen1 = new Almacen("ALM001");
        this.almacen2 = new Almacen("ALM002");
        this.vista = new VistaInventario();

        // Agregar algunos productos de ejemplo
        almacen1.agregarProducto(new Producto("PROD001", 100));
        almacen1.agregarProducto(new Producto("PROD002", 150));
        almacen2.agregarProducto(new Producto("PROD001", 50));
        almacen2.agregarProducto(new Producto("PROD003", 200));
    }

    public void iniciar() {
        int opcion;
        do {
            vista.mostrarMenu();
            opcion = vista.obtenerOpcion();

            switch (opcion) {
                case 1:
                    agregarProducto();
                    break;
                case 2:
                    verStock();
                    break;
                case 3:
                    transferirProducto();
                    break;
                case 4:
                    simularTransferenciasConcurrentes();
                    break;
                case 5:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción no válida");
            }
        } while (opcion != 5);
    }

    private void agregarProducto() {
        String productoId = vista.obtenerIdProducto();
        int cantidad = vista.obtenerCantidad();

        Producto producto = almacen1.getProducto(productoId);
        if (producto == null) {
            producto = new Producto(productoId, cantidad);
            almacen1.agregarProducto(producto);
        } else {
            producto.ajustarStock(cantidad);
        }

        vista.mostrarResultado(true, "Agregar producto");
    }

    private void verStock() {
        String productoId = vista.obtenerIdProducto();

        Producto producto1 = almacen1.getProducto(productoId);
        Producto producto2 = almacen2.getProducto(productoId);

        if (producto1 != null) {
            vista.mostrarStock(productoId + " en " + almacen1.getId(), producto1.getStock());
        }
        if (producto2 != null) {
            vista.mostrarStock(productoId + " en " + almacen2.getId(), producto2.getStock());
        }
        if (producto1 == null && producto2 == null) {
            System.out.println("Producto no encontrado");
        }
    }

    private void transferirProducto() {
        String productoId = vista.obtenerIdProducto();
        int cantidad = vista.obtenerCantidad();

        boolean exito = Almacen.transferirProducto(almacen1, almacen2, productoId, cantidad);
        vista.mostrarResultado(exito, "Transferencia");
    }

    private void simularTransferenciasConcurrentes() {
        System.out.println("\nSimulando 10 transferencias concurrentes...");

        for (int i = 0; i < 10; i++) {
            final String productoId = "PROD00" + (i % 3 + 1); // PROD001, PROD002 o PROD003
            final int cantidad = (i % 2 + 1) * 10; // 10 o 20 unidades
            final boolean direccion = i % 2 == 0;

            new Thread(() -> {
                if (direccion) {
                    Inventario.realizarTransferencia(almacen1, almacen2, productoId, cantidad);
                } else {
                    Inventario.realizarTransferencia(almacen2, almacen1, productoId, cantidad);
                }
            }).start();
        }
    }
}
