/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class Inventario {
    public static void realizarTransferencia(Almacen origen, Almacen destino, String productoId, int cantidad) {
        boolean exito = Almacen.transferirProducto(origen, destino, productoId, cantidad);
        System.out.println("Transferencia de " + cantidad + " unidades de " + productoId + 
                         (exito ? " exitosa" : " fallida") + 
                         " de almacén " + origen.getId() + 
                         " a almacén " + destino.getId());
    }
}