/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Producto {
    private final String id;
    private int stock;
    private final Lock lock = new ReentrantLock();

    public Producto(String id, int stockInicial) {
        this.id = id;
        this.stock = stockInicial;
    }

    public String getId() {
        return id;
    }

    public int getStock() {
        return stock;
    }

    public void ajustarStock(int cantidad) {
        lock.lock();
        try {
            stock += cantidad;
        } finally {
            lock.unlock();
        }
    }

    public boolean moverStock(int cantidad) {
        lock.lock();
        try {
            if (stock >= cantidad) {
                stock -= cantidad;
                return true;
            }
            return false;
        } finally {
            lock.unlock();
        }
    }
}