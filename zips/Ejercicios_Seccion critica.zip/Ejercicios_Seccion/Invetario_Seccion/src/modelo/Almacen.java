/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.HashMap;
import java.util.Map;

public class Almacen {
    private final String id;
    private final Map<String, Producto> productos = new HashMap<>();
    private final Object lock = new Object();

    public Almacen(String id) {
        this.id = id;
    }

    public void agregarProducto(Producto producto) {
        synchronized(lock) {
            productos.put(producto.getId(), producto);
        }
    }

    public Producto getProducto(String productoId) {
        synchronized(lock) {
            return productos.get(productoId);
        }
    }

    // Sección crítica para transferencia entre almacenes
    public static boolean transferirProducto(Almacen origen, Almacen destino, String productoId, int cantidad) {
        // Ordenar almacenes por ID para evitar deadlock
        Almacen primero = origen.id.compareTo(destino.id) < 0 ? origen : destino;
        Almacen segundo = primero == origen ? destino : origen;

        synchronized(primero) {
            synchronized(segundo) {
                Producto productoOrigen = origen.getProducto(productoId);
                Producto productoDestino = destino.getProducto(productoId);

                if (productoOrigen == null || productoDestino == null) {
                    return false;
                }

                if (productoOrigen.moverStock(cantidad)) {
                    productoDestino.ajustarStock(cantidad);
                    return true;
                }
                return false;
            }
        }
    }

    public String getId() {
        return id;
    }
}