/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.VentaBoletos;
import modelo.Teatro;
import vista.VistaTeatro;

public class ControladorTeatro {

    private VentaBoletos ventaBoletos;
    private VistaTeatro vista;
    private Teatro teatro;

    public ControladorTeatro() {
        this.teatro = new Teatro(100); // Teatro con 100 asientos
        this.ventaBoletos = new VentaBoletos(teatro);
        this.vista = new VistaTeatro();
    }

    public void iniciar() {
        int opcion;
        do {
            vista.mostrarMenu();
            opcion = vista.obtenerOpcion();

            switch (opcion) {
                case 1:
                    procesarCompra("sincronizado");
                    break;
                case 2:
                    procesarCompra("bloque");
                    break;
                case 3:
                    vista.mostrarAsientos(teatro.getAsientosDisponibles());
                    break;
                case 4:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción no válida");
            }
        } while (opcion != 4);
    }

    private void procesarCompra(String metodo) {
        int cantidad = vista.obtenerCantidad();
        boolean exito = ventaBoletos.comprarBoletos(cantidad, metodo);
        vista.mostrarResultadoVenta(exito, cantidad);
    }

    // Método para simular compras concurrentes
    public void simularComprasConcurrentes() {
        System.out.println("\nSimulando 10 compras concurrentes...");

        for (int i = 0; i < 10; i++) {
            final int cantidad = (i % 3) + 1; // 1, 2 o 3 boletos
            new Thread(() -> {
                boolean exito = ventaBoletos.comprarBoletos(cantidad, "sincronizado");
                System.out.println("Hilo " + Thread.currentThread().getId()
                        + (exito ? " compró " : " no pudo comprar ")
                        + cantidad + " boleto(s)");
            }).start();
        }
    }
}
