/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

public class VistaTeatro {

    public void mostrarMenu() {
        System.out.println("\n=== SISTEMA DE VENTA DE BOLETOS ===");
        System.out.println("1. Comprar boletos (método sincronizado)");
        System.out.println("2. Comprar boletos (bloque sincronizado)");
        System.out.println("3. Ver asientos disponibles");
        System.out.println("4. Salir");
    }

    public void mostrarAsientos(int disponibles) {
        System.out.println("Asientos disponibles: " + disponibles);
    }

    public void mostrarResultadoVenta(boolean exito, int cantidad) {
        if (exito) {
            System.out.println("¡Venta exitosa! " + cantidad + " boletos comprados.");
        } else {
            System.out.println("No hay suficientes asientos disponibles para " + cantidad + " boletos.");
        }
    }

    public int obtenerOpcion() {
        System.out.print("Seleccione una opción: ");
        return Integer.parseInt(System.console().readLine());
    }

    public int obtenerCantidad() {
        System.out.print("Ingrese cantidad de boletos: ");
        return Integer.parseInt(System.console().readLine());
    }
}
