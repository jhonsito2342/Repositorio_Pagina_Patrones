
import controlador.ControladorTeatro;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
public class Main {

    public static void main(String[] args) {
        ControladorTeatro controlador = new ControladorTeatro();

        // Ejecutar simulación de compras concurrentes
        controlador.simularComprasConcurrentes();

        // Iniciar interfaz de usuario
        try {
            Thread.sleep(2000); // Esperar a que termine la simulación
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        controlador.iniciar();
    }
}
