/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class Teatro {

    private int asientosDisponibles;
    private final Object lock = new Object(); // Objeto para sincronización

    public Teatro(int capacidad) {
        this.asientosDisponibles = capacidad;
    }

    // Sección crítica protegida con synchronized
    public synchronized boolean venderBoleto(int cantidad) {
        if (asientosDisponibles >= cantidad) {
            // Simular procesamiento
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }

            asientosDisponibles -= cantidad;
            return true;
        }
        return false;
    }

    // Sección crítica protegida con bloque synchronized
    public boolean reservarBoleto(int cantidad) {
        synchronized (lock) {
            if (asientosDisponibles >= cantidad) {
                // Simular procesamiento
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }

                asientosDisponibles -= cantidad;
                return true;
            }
            return false;
        }
    }

    public int getAsientosDisponibles() {
        return asientosDisponibles;
    }
}
