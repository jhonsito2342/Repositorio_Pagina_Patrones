/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class VentaBoletos {

    private Teatro teatro;

    public VentaBoletos(Teatro teatro) {
        this.teatro = teatro;
    }

    public boolean comprarBoletos(int cantidad, String metodo) {
        if ("sincronizado".equals(metodo)) {
            return teatro.venderBoleto(cantidad);
        } else {
            return teatro.reservarBoleto(cantidad);
        }
    }
}
