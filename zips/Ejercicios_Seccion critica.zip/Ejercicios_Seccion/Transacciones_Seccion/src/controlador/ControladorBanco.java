/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.CuentaBancaria;
import modelo.Transaccion;
import vista.VistaBanco;

public class ControladorBanco {
    private CuentaBancaria cuenta;
    private VistaBanco vista;
    private CuentaBancaria cuentaDestino;

    public ControladorBanco() {
        this.cuenta = new CuentaBancaria(1000.0); // Saldo inicial $1000
        this.cuentaDestino = new CuentaBancaria(500.0); // Otra cuenta con $500
        this.vista = new VistaBanco();
    }

    public void iniciar() {
        int opcion;
        do {
            vista.mostrarMenu();
            opcion = vista.obtenerOpcion();

            switch (opcion) {
                case 1:
                    vista.mostrarSaldo(cuenta.getSaldo());
                    break;
                case 2:
                    depositar();
                    break;
                case 3:
                    retirar();
                    break;
                case 4:
                    transferir();
                    break;
                case 5:
                    simularTransferenciasConcurrentes();
                    break;
                case 6:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción no válida");
            }
        } while (opcion != 6);
    }

    private void depositar() {
        double monto = vista.obtenerMonto("depositar");
        cuenta.depositar(monto);
        vista.mostrarResultado(true, "Depósito");
    }

    private void retirar() {
        double monto = vista.obtenerMonto("retirar");
        boolean exito = cuenta.retirar(monto);
        vista.mostrarResultado(exito, "Retiro");
    }

    private void transferir() {
        double monto = vista.obtenerMonto("transferir");
        boolean exito = CuentaBancaria.transferir(cuenta, cuentaDestino, monto);
        vista.mostrarResultado(exito, "Transferencia");
    }

    private void simularTransferenciasConcurrentes() {
        System.out.println("\nSimulando 10 transferencias concurrentes...");
        
        for (int i = 0; i < 10; i++) {
            final double monto = (i % 3 + 1) * 50; // $50, $100 o $150
            final boolean direccion = i % 2 == 0;
            
            new Thread(() -> {
                if (direccion) {
                    Transaccion.realizarTransferencia(cuenta, cuentaDestino, monto);
                } else {
                    Transaccion.realizarTransferencia(cuentaDestino, cuenta, monto);
                }
            }).start();
        }
    }
}