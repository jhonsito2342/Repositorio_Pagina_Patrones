/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

public class VistaBanco {

    public void mostrarMenu() {
        System.out.println("\n=== SISTEMA BANCARIO ===");
        System.out.println("1. Ver saldo");
        System.out.println("2. Depositar");
        System.out.println("3. Retirar");
        System.out.println("4. Transferir");
        System.out.println("5. Simular transferencias concurrentes");
        System.out.println("6. Salir");
    }

    public void mostrarSaldo(double saldo) {
        System.out.printf("Saldo actual: %.2f\n", saldo);
    }

    public double obtenerMonto(String operacion) {
        System.out.printf("Ingrese monto a %s: ", operacion);
        return Double.parseDouble(System.console().readLine());
    }

    public void mostrarResultado(boolean exito, String operacion) {
        System.out.println(operacion + (exito ? " exitosa" : " fallida"));
    }

    public int obtenerOpcion() {
        System.out.print("Seleccione una opción: ");
        return Integer.parseInt(System.console().readLine());
    }
}
