/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class CuentaBancaria {

    private double saldo;
    private final Lock lock = new ReentrantLock();

    public CuentaBancaria(double saldoInicial) {
        this.saldo = saldoInicial;
    }

    // Sección crítica con ReentrantLock
    public boolean retirar(double monto) {
        lock.lock();
        try {
            if (saldo >= monto) {
                // Simular procesamiento
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }

                saldo -= monto;
                return true;
            }
            return false;
        } finally {
            lock.unlock();
        }
    }

    // Sección crítica con synchronized
    public synchronized void depositar(double monto) {
        // Simular procesamiento
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        saldo += monto;
    }

    public synchronized double getSaldo() {
        return saldo;
    }

    // Transferencia entre cuentas con orden consistente de bloqueos
    public static boolean transferir(CuentaBancaria origen, CuentaBancaria destino, double monto) {
        // Ordenar cuentas por hash para evitar deadlock
        CuentaBancaria primera = System.identityHashCode(origen) < System.identityHashCode(destino) ? origen : destino;
        CuentaBancaria segunda = primera == origen ? destino : origen;

        primera.lock.lock();
        try {
            segunda.lock.lock();
            try {
                if (origen.retirar(monto)) {
                    destino.depositar(monto);
                    return true;
                }
                return false;
            } finally {
                segunda.lock.unlock();
            }
        } finally {
            primera.lock.unlock();
        }
    }
}
