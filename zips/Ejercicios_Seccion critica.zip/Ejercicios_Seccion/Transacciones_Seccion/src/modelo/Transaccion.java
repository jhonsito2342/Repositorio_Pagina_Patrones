/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class Transaccion {

    public static void realizarTransferencia(CuentaBancaria origen, CuentaBancaria destino, double monto) {
        boolean exito = CuentaBancaria.transferir(origen, destino, monto);
        System.out.println("Transferencia de " + monto
                + (exito ? " exitosa" : " fallida")
                + " de cuenta con saldo " + origen.getSaldo()
                + " a cuenta con saldo " + destino.getSaldo());
    }
}
