/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Main;

import Adapters.MongoDBAdapter;
import Adapters.OracleAdapter;
import Interfaces.Database;
import Vendors.MongoDB;
import Vendors.OracleDB;

/**
 *
 * @author Jhon
 */
public class Main {

    public static void main(String[] args) {
        // Usando Oracle con el adaptador
        Database oracleDB = new OracleAdapter(new OracleDB());
        oracleDB.connect();
        oracleDB.query("SELECT * FROM users");
        oracleDB.disconnect();

        System.out.println();

        // Usando MongoDB con el adaptador
        Database mongoDB = new MongoDBAdapter(new MongoDB());
        mongoDB.connect();
        mongoDB.query("{user: 'admin'}");
        mongoDB.disconnect();
    }
}
