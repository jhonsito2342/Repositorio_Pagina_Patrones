/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Adapters;

import Interfaces.Database;
import Vendors.OracleDB;

/**
 *
 * @author Jhon
 */
public class OracleAdapter implements Database {

    private OracleDB oracleDB;

    public OracleAdapter(OracleDB oracleDB) {
        this.oracleDB = oracleDB;
    }

    @Override
    public void connect() {
        oracleDB.oracleConnect();
    }

    @Override
    public void query(String sql) {
        oracleDB.oracleQuery(sql);
    }

    @Override
    public void disconnect() {
        oracleDB.oracleClose();
    }
}
