/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Adapters;

import Interfaces.Database;
import Vendors.MongoDB;

/**
 *
 * @author Jhon
 */
public class MongoDBAdapter implements Database {

    private MongoDB mongoDB;

    public MongoDBAdapter(MongoDB mongoDB) {
        this.mongoDB = mongoDB;
    }

    @Override
    public void connect() {
        mongoDB.mongoConnect();
    }

    @Override
    public void query(String query) {
        mongoDB.mongoFind(query);
    }

    @Override
    public void disconnect() {
        mongoDB.mongoDisconnect();
    }
}
