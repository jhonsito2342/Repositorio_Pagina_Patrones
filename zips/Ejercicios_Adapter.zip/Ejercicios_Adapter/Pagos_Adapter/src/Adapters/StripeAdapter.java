/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Adapters;

import Interfaces.PaymentProcessor;
import Vendors.StripeAPI;

/**
 *
 * @author Jhon
 */
public class StripeAdapter implements PaymentProcessor {

    private StripeAPI stripe;

    public StripeAdapter(StripeAPI stripe) {
        this.stripe = stripe;
    }

    @Override
    public void processPayment(double amount) {
        stripe.charge(amount);
    }

    @Override
    public void refundPayment(double amount) {
        stripe.refundCharge(amount);
    }

    @Override
    public boolean validatePayment() {
        return stripe.verify();
    }
}
