/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Adapters;

import Interfaces.PaymentProcessor;
import Vendors.PayPalSDK;

/**
 *
 * @author Jhon
 */
public class PayPalAdapter implements PaymentProcessor {

    private PayPalSDK payPal;

    public PayPalAdapter(PayPalSDK payPal) {
        this.payPal = payPal;
    }

    @Override
    public void processPayment(double amount) {
        payPal.sendPayment(amount);
    }

    @Override
    public void refundPayment(double amount) {
        payPal.issueRefund(amount);
    }

    @Override
    public boolean validatePayment() {
        return payPal.checkStatus();
    }
}
