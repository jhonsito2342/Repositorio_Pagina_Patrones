/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Main;

import Adapters.PayPalAdapter;
import Adapters.StripeAdapter;
import Interfaces.PaymentProcessor;
import Vendors.PayPalSDK;
import Vendors.StripeAPI;

/**
 *
 * @author Jhon
 */
public class Main {

    public static void main(String[] args) {
        // Procesamiento con PayPal
        PaymentProcessor payPal = new PayPalAdapter(new PayPalSDK());
        payPal.processPayment(100.50);
        payPal.validatePayment();
        payPal.refundPayment(25.00);

        System.out.println();

        // Procesamiento con Stripe
        PaymentProcessor stripe = new StripeAdapter(new StripeAPI());
        stripe.processPayment(75.99);
        stripe.validatePayment();
        stripe.refundPayment(10.00);
    }
}
