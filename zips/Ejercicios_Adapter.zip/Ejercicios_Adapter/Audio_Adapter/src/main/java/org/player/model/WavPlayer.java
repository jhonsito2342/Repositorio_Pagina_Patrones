package org.player.model;

public class WavPlayer {
    private String filename;
    private String format;

    public WavPlayer() {
    }

    public void playWav(String filename) {
        this.filename = filename;
        this.format = "wav";
        System.out.println("Playing WAV file: " + filename);
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }
}
