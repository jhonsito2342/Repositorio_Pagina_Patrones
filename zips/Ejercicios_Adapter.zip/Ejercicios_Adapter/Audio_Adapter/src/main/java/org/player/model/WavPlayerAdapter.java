package org.player.model;

public class WavPlayerAdapter implements AudioPlayer {
    private WavPlayer wavPlayer;
    private String filename;
    private String format;

    public WavPlayerAdapter() {
        this.wavPlayer = new WavPlayer();
    }

    @Override
    public void play(String filename, String format) {
        this.filename = filename;
        this.format = format;
        wavPlayer.playWav(filename);
    }

    public WavPlayer getWavPlayer() {
        return wavPlayer;
    }

    public void setWavPlayer(WavPlayer wavPlayer) {
        this.wavPlayer = wavPlayer;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }
}
