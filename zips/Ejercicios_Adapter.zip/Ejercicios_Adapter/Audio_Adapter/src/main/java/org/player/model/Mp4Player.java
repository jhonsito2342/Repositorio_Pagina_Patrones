package org.player.model;

public class Mp4Player {
    private String filename;
    private String format;

    public Mp4Player() {
    }

    public void playMp4(String filename) {
        this.filename = filename;
        this.format = "mp4";
        System.out.println("Playing MP4 file: " + filename);
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }
}
