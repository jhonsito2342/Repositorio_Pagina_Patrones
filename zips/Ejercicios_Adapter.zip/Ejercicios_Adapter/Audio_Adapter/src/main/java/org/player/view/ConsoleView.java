package org.player.view;

import java.util.Scanner;

public class ConsoleView {
    private Scanner scanner;

    public ConsoleView() {
        this.scanner = new Scanner(System.in);
    }

    public void print(String message) {
        System.out.println(message);
    }

    public String readString(String message) {
        print(message);
        return scanner.nextLine();
    }

    public boolean readBoolean(String message) {
        print(message + " (true/false)");
        while (!scanner.hasNextBoolean()) {
            print("Invalid input. Please enter 'true' or 'false'.");
            scanner.next();
            print(message + " (true/false)");
        }
        boolean value = scanner.nextBoolean();
        scanner.nextLine();
        return value;
    }

    public Scanner getScanner() {
        return scanner;
    }

    public void setScanner(Scanner scanner) {
        this.scanner = scanner;
    }
}
