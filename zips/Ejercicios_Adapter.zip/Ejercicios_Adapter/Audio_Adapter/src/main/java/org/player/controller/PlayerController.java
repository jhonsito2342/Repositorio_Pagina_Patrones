package org.player.controller;

import org.player.model.AudioPlayer;
import org.player.model.Mp3Player;
import org.player.model.Mp4PlayerAdapter;
import org.player.model.WavPlayerAdapter;
import org.player.view.ConsoleView;

public class PlayerController {
    private ConsoleView view;
    private AudioPlayer audioPlayer;
    private String filename;
    private String format;

    public PlayerController() {
        this.view = new ConsoleView();
    }

    public void processUserInput() {
        filename = view.readString("Enter the filename: ");
        format = view.readString("Enter the format (mp3, mp4, wav): ");

        if ("mp3".equalsIgnoreCase(format)) {
            audioPlayer = new Mp3Player();
        } else if ("mp4".equalsIgnoreCase(format)) {
            audioPlayer = new Mp4PlayerAdapter();
        } else if ("wav".equalsIgnoreCase(format)) {
            audioPlayer = new WavPlayerAdapter();
        } else {
            System.out.println("Invalid format. Defaulting to MP3.");
            audioPlayer = new Mp3Player();
            format = "mp3";
        }

        audioPlayer.play(filename, format);
    }

    public void run() {
        boolean continueRunning = true;

        view.print("Welcome to Audio Player");

        while (continueRunning) {
            processUserInput();

            continueRunning = view.readBoolean("Do you want to play another file?");

            if (!continueRunning) {
                view.print("Thank you for using Audio Player!");
            }
        }
    }

    public ConsoleView getView() {
        return view;
    }

    public void setView(ConsoleView view) {
        this.view = view;
    }

    public AudioPlayer getAudioPlayer() {
        return audioPlayer;
    }

    public void setAudioPlayer(AudioPlayer audioPlayer) {
        this.audioPlayer = audioPlayer;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }
}

