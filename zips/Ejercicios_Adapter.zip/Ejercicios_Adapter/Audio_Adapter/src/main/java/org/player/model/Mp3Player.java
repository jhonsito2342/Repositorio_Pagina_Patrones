package org.player.model;

public class Mp3Player implements AudioPlayer {
    private String filename;
    private String format;

    public Mp3Player() {
    }

    @Override
    public void play(String filename, String format) {
        this.filename = filename;
        this.format = format;
        System.out.println("Playing MP3 file: " + filename);
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }
}
