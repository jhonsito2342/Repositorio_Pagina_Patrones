package org.player.controller;

public class AplMain {
    public static void main(String[] args) {
        PlayerController controller = new PlayerController();
        controller.run();
    }
}
