package org.player.model;

public interface AudioPlayer {
    void play(String filename, String format);
}
