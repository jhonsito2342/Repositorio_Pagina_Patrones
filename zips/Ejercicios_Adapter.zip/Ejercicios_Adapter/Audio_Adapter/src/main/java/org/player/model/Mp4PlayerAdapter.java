package org.player.model;

public class Mp4PlayerAdapter implements AudioPlayer {
    private Mp4Player mp4Player;
    private String filename;
    private String format;

    public Mp4PlayerAdapter() {
        this.mp4Player = new Mp4Player();
    }

    @Override
    public void play(String filename, String format) {
        this.filename = filename;
        this.format = format;
        mp4Player.playMp4(filename);
    }

    public Mp4Player getMp4Player() {
        return mp4Player;
    }

    public void setMp4Player(Mp4Player mp4Player) {
        this.mp4Player = mp4Player;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }
}
