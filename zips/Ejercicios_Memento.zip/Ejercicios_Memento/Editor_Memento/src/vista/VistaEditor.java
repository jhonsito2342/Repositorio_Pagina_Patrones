/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import java.util.Scanner;

/**
 * Clase responsable de la interacción con el usuario
 */
public class VistaEditor {

    private Scanner scanner = new Scanner(System.in);

    public void mostrarMenu() {
        System.out.println("\n=== EDITOR DE TEXTO ===");
        System.out.println("1. Escribir texto");
        System.out.println("2. Configurar estilo");
        System.out.println("3. Mostrar documento");
        System.out.println("4. Deshacer");
        System.out.println("5. Rehacer");
        System.out.println("6. Salir");
    }

    public int obtenerOpcion() {
        System.out.print("Seleccione una opción: ");
        return scanner.nextInt();
    }

    public String obtenerTexto() {
        System.out.print("Ingrese texto: ");
        scanner.nextLine(); // Limpiar buffer
        return scanner.nextLine();
    }

    public String obtenerEstilo() {
        System.out.print("Ingrese estilo de fuente (Arial/Times New Roman/Consolas): ");
        return scanner.next();
    }

    public int obtenerTamañoFuente() {
        System.out.print("Ingrese tamaño de fuente: ");
        return scanner.nextInt();
    }

    public void mostrarDocumento(String estado) {
        System.out.println("\n--- DOCUMENTO ACTUAL ---");
        System.out.println(estado);
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
}
