/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.Stack;

/**
 * Clase que gestiona el historial de estados del documento (mementos) Actúa
 * como Caretaker en el patrón Memento
 */
public class GestorHistorial {

    private Stack<MementoDocumento> historial = new Stack<>();
    private Stack<MementoDocumento> rehacer = new Stack<>();

    /**
     * Guarda un estado del documento en el historial
     *
     * @param memento Memento a guardar
     */
    public void guardarEstado(MementoDocumento memento) {
        historial.push(memento);
        rehacer.clear(); // Al realizar nueva acción, limpiamos el stack de rehacer
    }

    /**
     * Deshace la última acción
     *
     * @return Memento con el estado anterior o null si no hay historial
     */
    public MementoDocumento deshacer() {
        if (historial.size() <= 1) {
            return null; // No deshacer estado inicial
        }
        MementoDocumento actual = historial.pop();
        rehacer.push(actual);
        return historial.peek(); // Devuelve el estado anterior
    }

    /**
     * Rehace la última acción deshecha
     *
     * @return Memento con el estado rehecho o null si no hay acciones para
     * rehacer
     */
    public MementoDocumento rehacer() {
        if (rehacer.isEmpty()) {
            return null;
        }

        MementoDocumento estado = rehacer.pop();
        historial.push(estado);
        return estado;
    }

    public boolean sePuedeDeshacer() {
        return historial.size() > 1;
    }

    public boolean sePuedeRehacer() {
        return !rehacer.isEmpty();
    }
}
