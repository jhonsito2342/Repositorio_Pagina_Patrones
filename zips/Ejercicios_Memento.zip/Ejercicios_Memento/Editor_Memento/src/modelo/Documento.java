/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 * Clase que representa un documento de texto y puede crear/restaurar mementos
 * Actúa como Originator en el patrón Memento
 */
public class Documento {

    private String contenido;
    private String estiloFuente;
    private int tamañoFuente;

    public Documento() {
        this.contenido = "";
        this.estiloFuente = "Arial";
        this.tamañoFuente = 12;
    }

    public void escribir(String texto) {
        this.contenido += texto;
    }

    public void configurarEstilo(String estilo, int tamaño) {
        this.estiloFuente = estilo;
        this.tamañoFuente = tamaño;
    }

    public String getContenido() {
        return contenido;
    }

    public String getEstado() {
        return "Contenido: " + contenido + "\nEstilo: " + estiloFuente
                + ", Tamaño: " + tamañoFuente;
    }

    /**
     * Crea un memento con el estado actual del documento
     *
     * @return Memento que contiene el estado actual
     */
    public MementoDocumento crearMemento() {
        return new MementoDocumento(contenido, estiloFuente, tamañoFuente);
    }

    /**
     * Restaura el estado del documento a partir de un memento
     *
     * @param memento Memento con el estado a restaurar
     */
    public void restaurarDesdeMemento(MementoDocumento memento) {
        this.contenido = memento.getContenido();
        this.estiloFuente = memento.getEstiloFuente();
        this.tamañoFuente = memento.getTamañoFuente();
    }
}
