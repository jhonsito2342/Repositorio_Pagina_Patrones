/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 * Clase Memento que almacena el estado interno de un Documento Implementación
 * clásica del patrón Memento
 */
public class MementoDocumento {

    private final String contenido;
    private final String estiloFuente;
    private final int tamañoFuente;

    // Constructor solo accesible desde el paquete modelo (Documento puede crearlo)
    MementoDocumento(String contenido, String estiloFuente, int tamañoFuente) {
        this.contenido = contenido;
        this.estiloFuente = estiloFuente;
        this.tamañoFuente = tamañoFuente;
    }

    // Métodos getters accesibles solo desde el paquete modelo (solo Documento puede restaurar)
    String getContenido() {
        return contenido;
    }

    String getEstiloFuente() {
        return estiloFuente;
    }

    int getTamañoFuente() {
        return tamañoFuente;
    }
}
