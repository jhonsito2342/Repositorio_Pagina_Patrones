/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.Documento;
import modelo.GestorHistorial;
import modelo.MementoDocumento;
import vista.VistaEditor;

/**
 * Controlador que maneja la lógica de la aplicación y coordina Modelo y Vista
 */
public class ControladorEditor {

    private Documento documento;
    private GestorHistorial historial;
    private VistaEditor vista;

    public ControladorEditor() {
        this.documento = new Documento();
        this.historial = new GestorHistorial();
        this.vista = new VistaEditor();
        // Guardar estado inicial
        historial.guardarEstado(documento.crearMemento());
    }

    public void iniciar() {
        int opcion;
        do {
            vista.mostrarMenu();
            opcion = vista.obtenerOpcion();

            switch (opcion) {
                case 1:
                    agregarTexto();
                    break;
                case 2:
                    configurarEstilo();
                    break;
                case 3:
                    mostrarDocumento();
                    break;
                case 4:
                    deshacer();
                    break;
                case 5:
                    rehacer();
                    break;
                case 6:
                    vista.mostrarMensaje("Saliendo del editor...");
                    break;
                default:
                    vista.mostrarMensaje("Opción no válida");
            }
        } while (opcion != 6);
    }

    private void agregarTexto() {
        String texto = vista.obtenerTexto();
        documento.escribir(texto);
        historial.guardarEstado(documento.crearMemento());
        vista.mostrarMensaje("Texto agregado correctamente");
    }

    private void configurarEstilo() {
        String estilo = vista.obtenerEstilo();
        int tamaño = vista.obtenerTamañoFuente();
        documento.configurarEstilo(estilo, tamaño);
        historial.guardarEstado(documento.crearMemento());
        vista.mostrarMensaje("Estilo configurado correctamente");
    }

    private void mostrarDocumento() {
        vista.mostrarDocumento(documento.getEstado());
    }

    private void deshacer() {
        if (!historial.sePuedeDeshacer()) {
            vista.mostrarMensaje("No hay acciones para deshacer");
            return;
        }

        MementoDocumento memento = historial.deshacer();
        if (memento != null) {
            documento.restaurarDesdeMemento(memento);
            vista.mostrarMensaje("Acción deshecha");
        }
    }

    private void rehacer() {
        if (!historial.sePuedeRehacer()) {
            vista.mostrarMensaje("No hay acciones para rehacer");
            return;
        }

        MementoDocumento memento = historial.rehacer();
        if (memento != null) {
            documento.restaurarDesdeMemento(memento);
            vista.mostrarMensaje("Acción rehecha");
        }
    }
}
