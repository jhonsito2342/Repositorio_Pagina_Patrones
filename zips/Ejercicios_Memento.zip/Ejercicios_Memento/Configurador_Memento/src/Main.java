
import controlador.ControladorConfigurador;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
/**
 * Clase principal que inicia la aplicación
 */
public class Main {

    public static void main(String[] args) {
        ControladorConfigurador controlador = new ControladorConfigurador();
        controlador.iniciar();
    }
}
