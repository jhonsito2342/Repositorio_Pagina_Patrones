/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.ConfiguracionApp;
import modelo.GestorVersiones;
import modelo.MementoConfiguracion;
import vista.VistaConfigurador;

/**
 * Controlador que maneja la lógica de la aplicación y coordina Modelo y Vista
 */
public class ControladorConfigurador {

    private ConfiguracionApp configuracion;
    private GestorVersiones gestorVersiones;
    private VistaConfigurador vista;

    public ControladorConfigurador() {
        this.configuracion = new ConfiguracionApp();
        this.gestorVersiones = new GestorVersiones();
        this.vista = new VistaConfigurador();
        // Guardar estado inicial
        gestorVersiones.guardarVersion(configuracion.crearMemento());
    }

    public void iniciar() {
        int opcion;
        do {
            vista.mostrarMenu();
            opcion = vista.obtenerOpcion();

            switch (opcion) {
                case 1:
                    agregarConfiguracion();
                    break;
                case 2:
                    cambiarVersion();
                    break;
                case 3:
                    mostrarConfiguracion();
                    break;
                case 4:
                    deshacer();
                    break;
                case 5:
                    rehacer();
                    break;
                case 6:
                    mostrarHistorial();
                    break;
                case 7:
                    vista.mostrarMensaje("Saliendo del configurador...");
                    break;
                default:
                    vista.mostrarMensaje("Opción no válida");
            }
        } while (opcion != 7);
    }

    private void agregarConfiguracion() {
        String clave = vista.obtenerClave();
        String valor = vista.obtenerValor();
        configuracion.setConfiguracion(clave, valor);
        gestorVersiones.guardarVersion(configuracion.crearMemento());
        vista.mostrarMensaje("Configuración agregada correctamente");
    }

    private void cambiarVersion() {
        String version = vista.obtenerVersion();
        configuracion.setVersion(version);
        gestorVersiones.guardarVersion(configuracion.crearMemento());
        vista.mostrarMensaje("Versión actualizada a " + version);
    }

    private void mostrarConfiguracion() {
        configuracion.mostrarConfiguracion();
    }

    private void deshacer() {
        if (!gestorVersiones.hayVersionAnterior()) {
            vista.mostrarMensaje("No hay versiones anteriores");
            return;
        }

        MementoConfiguracion memento = gestorVersiones.getVersionAnterior();
        configuracion.restaurarDesdeMemento(memento);
        vista.mostrarMensaje("Configuración restaurada a versión anterior");
    }

    private void rehacer() {
        if (!gestorVersiones.hayVersionSiguiente()) {
            vista.mostrarMensaje("No hay versiones siguientes");
            return;
        }

        MementoConfiguracion memento = gestorVersiones.getVersionSiguiente();
        configuracion.restaurarDesdeMemento(memento);
        vista.mostrarMensaje("Configuración restaurada a versión siguiente");
    }

    private void mostrarHistorial() {
        gestorVersiones.mostrarHistorial();
    }
}
