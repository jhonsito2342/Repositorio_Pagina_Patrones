/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import java.util.Scanner;

/**
 * Clase responsable de la interacción con el usuario
 */
public class VistaConfigurador {

    private Scanner scanner = new Scanner(System.in);

    public void mostrarMenu() {
        System.out.println("\n=== CONFIGURADOR DE APLICACIÓN ===");
        System.out.println("1. Agregar configuración");
        System.out.println("2. Cambiar versión");
        System.out.println("3. Mostrar configuración actual");
        System.out.println("4. Deshacer cambio");
        System.out.println("5. Rehacer cambio");
        System.out.println("6. Mostrar historial");
        System.out.println("7. Salir");
    }

    public int obtenerOpcion() {
        System.out.print("Seleccione una opción: ");
        return scanner.nextInt();
    }

    public String obtenerClave() {
        System.out.print("Ingrese clave de configuración: ");
        scanner.nextLine(); // Limpiar buffer
        return scanner.nextLine();
    }

    public String obtenerValor() {
        System.out.print("Ingrese valor: ");
        return scanner.nextLine();
    }

    public String obtenerVersion() {
        System.out.print("Ingrese nueva versión: ");
        return scanner.next();
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
}
