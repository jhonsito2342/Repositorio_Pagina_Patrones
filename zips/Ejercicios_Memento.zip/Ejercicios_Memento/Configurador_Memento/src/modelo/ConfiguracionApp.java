/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.HashMap;
import java.util.Map;

/**
 * Clase que representa la configuración de una aplicación Actúa como Originator
 * en el patrón Memento
 */
public class ConfiguracionApp {

    private Map<String, String> configuraciones;
    private String version;

    public ConfiguracionApp() {
        this.configuraciones = new HashMap<>();
        this.version = "1.0";
    }

    public void setConfiguracion(String clave, String valor) {
        configuraciones.put(clave, valor);
    }

    public String getConfiguracion(String clave) {
        return configuraciones.get(clave);
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getVersion() {
        return version;
    }

    public void mostrarConfiguracion() {
        System.out.println("\nVersión: " + version);
        configuraciones.forEach((k, v) -> System.out.println(k + ": " + v));
    }

    /**
     * Crea un memento con el estado actual de la configuración
     *
     * @return Memento que contiene el estado actual
     */
    public MementoConfiguracion crearMemento() {
        return new MementoConfiguracion(new HashMap<>(configuraciones), version);
    }

    /**
     * Restaura el estado de la configuración a partir de un memento
     *
     * @param memento Memento con el estado a restaurar
     */
    public void restaurarDesdeMemento(MementoConfiguracion memento) {
        this.configuraciones = new HashMap<>(memento.getConfiguraciones());
        this.version = memento.getVersion();
    }
}
