/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.Map;

/**
 * Clase Memento que almacena el estado interno de ConfiguracionApp
 */
public class MementoConfiguracion {

    private final Map<String, String> configuraciones;
    private final String version;

    // Constructor accesible solo desde el paquete modelo
    MementoConfiguracion(Map<String, String> configuraciones, String version) {
        this.configuraciones = configuraciones;
        this.version = version;
    }

    // Getters accesibles solo desde el paquete modelo
    Map<String, String> getConfiguraciones() {
        return configuraciones;
    }

    String getVersion() {
        return version;
    }
}
