/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;
import java.util.List;

/**
 * Clase que gestiona las versiones de configuración (mementos) Actúa como
 * Caretaker en el patrón Memento
 */
public class GestorVersiones {

    private List<MementoConfiguracion> versiones = new ArrayList<>();
    private int posicionActual = -1;

    /**
     * Guarda una nueva versión de la configuración
     *
     * @param memento Memento a guardar
     */
    public void guardarVersion(MementoConfiguracion memento) {
        // Eliminar versiones futuras si estamos en medio del historial
        if (posicionActual < versiones.size() - 1) {
            versiones = versiones.subList(0, posicionActual + 1);
        }
        versiones.add(memento);
        posicionActual = versiones.size() - 1;
    }

    /**
     * Obtiene la versión anterior
     *
     * @return Memento con la versión anterior o null si no hay
     */
    public MementoConfiguracion getVersionAnterior() {
        if (posicionActual <= 0) {
            return null;
        }
        posicionActual--;
        return versiones.get(posicionActual);
    }

    /**
     * Obtiene la versión siguiente
     *
     * @return Memento con la versión siguiente o null si no hay
     */
    public MementoConfiguracion getVersionSiguiente() {
        if (posicionActual >= versiones.size() - 1) {
            return null;
        }
        posicionActual++;
        return versiones.get(posicionActual);
    }

    public boolean hayVersionAnterior() {
        return posicionActual > 0;
    }

    public boolean hayVersionSiguiente() {
        return posicionActual < versiones.size() - 1;
    }

    public void mostrarHistorial() {
        System.out.println("\n--- HISTORIAL DE VERSIONES ---");
        for (int i = 0; i < versiones.size(); i++) {
            System.out.println((i == posicionActual ? "> " : "  ") + "Versión " + (i + 1));
        }
    }
}
