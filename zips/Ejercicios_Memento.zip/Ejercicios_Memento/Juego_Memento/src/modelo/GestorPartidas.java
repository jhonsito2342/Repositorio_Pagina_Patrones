/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;
import java.util.List;

/**
 * Clase que gestiona los puntos de guardado del juego (mementos) Actúa como
 * Caretaker en el patrón Memento
 */
public class GestorPartidas {

    private List<MementoPartida> partidasGuardadas = new ArrayList<>();

    /**
     * Guarda el estado actual del juego
     *
     * @param memento Memento a guardar
     */
    public void guardarPartida(MementoPartida memento) {
        partidasGuardadas.add(memento);
    }

    /**
     * Obtiene una partida guardada por su índice
     *
     * @param indice Índice de la partida guardada
     * @return Memento con el estado del juego o null si no existe
     */
    public MementoPartida getPartida(int indice) {
        if (indice < 0 || indice >= partidasGuardadas.size()) {
            return null;
        }
        return partidasGuardadas.get(indice);
    }

    /**
     * Obtiene la última partida guardada
     *
     * @return Memento con el último estado guardado o null si no hay
     */
    public MementoPartida getUltimaPartida() {
        if (partidasGuardadas.isEmpty()) {
            return null;
        }
        return partidasGuardadas.get(partidasGuardadas.size() - 1);
    }

    public List<String> listarPartidas() {
        List<String> lista = new ArrayList<>();
        for (int i = 0; i < partidasGuardadas.size(); i++) {
            MementoPartida m = partidasGuardadas.get(i);
            lista.add(String.format("Partida %d: %s - Puntos: %d",
                    i + 1, m.getUbicacion(), m.getPuntuacion()));
        }
        return lista;
    }
}
