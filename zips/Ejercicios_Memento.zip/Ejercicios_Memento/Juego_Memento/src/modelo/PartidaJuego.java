/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 * Clase que representa una partida del juego y puede crear/restaurar mementos
 * Actúa como Originator en el patrón Memento
 */
public class PartidaJuego {
    private EstadoJuego estado;

    public PartidaJuego() {
        this.estado = new EstadoJuego("Inicio");
    }

    public void ejecutarAccion(String accion) {
        // Simulación de acciones del juego
        switch (accion.toLowerCase()) {
            case "avanzar":
                estado.moverA("Bosque");
                estado.agregarPuntos(10);
                break;
            case "recoger":
                estado.agregarItem("Espada");
                estado.agregarPuntos(5);
                break;
            case "luchar":
                estado.modificarSalud(-20);
                estado.agregarPuntos(30);
                estado.completarMision("Derrotar enemigo");
                break;
            case "descansar":
                estado.modificarSalud(30);
                estado.moverA("Campamento");
                break;
            default:
                estado.agregarPuntos(1);
        }
    }

    public EstadoJuego getEstado() {
        return estado;
    }

    /**
     * Crea un memento con el estado actual del juego
     * @return Memento que contiene el estado actual
     */
    public MementoPartida crearMemento() {
        return new MementoPartida(
            estado.getUbicacion(),
            estado.getSalud(),
            estado.getPuntuacion(),
            estado.getInventario(),
            estado.getMisionesCompletadas()
        );
    }

    /**
     * Restaura el estado del juego a partir de un memento
     * @param memento Memento con el estado a restaurar
     */
    public void restaurarDesdeMemento(MementoPartida memento) {
        this.estado = new EstadoJuego(memento.getUbicacion());
        this.estado.modificarSalud(memento.getSalud() - 100); // Ajuste para setear salud
        this.estado.agregarPuntos(memento.getPuntuacion());
        memento.getInventario().forEach(this.estado::agregarItem);
        memento.getMisionesCompletadas().forEach(this.estado::completarMision);
    }
}