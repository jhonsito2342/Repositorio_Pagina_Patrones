/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.HashSet;
import java.util.Set;

/**
 * Clase que representa el estado del juego en un momento dado
 */
public class EstadoJuego {
    private String ubicacion;
    private int salud;
    private int puntuacion;
    private Set<String> inventario;
    private Set<String> misionesCompletadas;

    public EstadoJuego(String ubicacion) {
        this.ubicacion = ubicacion;
        this.salud = 100;
        this.puntuacion = 0;
        this.inventario = new HashSet<>();
        this.misionesCompletadas = new HashSet<>();
    }

    // Métodos para modificar el estado
    public void moverA(String nuevaUbicacion) {
        this.ubicacion = nuevaUbicacion;
    }

    public void modificarSalud(int cambio) {
        this.salud = Math.max(0, Math.min(100, salud + cambio));
    }

    public void agregarPuntos(int puntos) {
        this.puntuacion += puntos;
    }

    public void agregarItem(String item) {
        inventario.add(item);
    }

    public void removerItem(String item) {
        inventario.remove(item);
    }

    public void completarMision(String mision) {
        misionesCompletadas.add(mision);
    }

    // Getters
    public String getUbicacion() { return ubicacion; }
    public int getSalud() { return salud; }
    public int getPuntuacion() { return puntuacion; }
    public Set<String> getInventario() { return new HashSet<>(inventario); }
    public Set<String> getMisionesCompletadas() { return new HashSet<>(misionesCompletadas); }

    @Override
    public String toString() {
        return "Ubicación: " + ubicacion + 
               "\nSalud: " + salud + 
               "\nPuntuación: " + puntuacion + 
               "\nInventario: " + inventario + 
               "\nMisiones completadas: " + misionesCompletadas;
    }
}