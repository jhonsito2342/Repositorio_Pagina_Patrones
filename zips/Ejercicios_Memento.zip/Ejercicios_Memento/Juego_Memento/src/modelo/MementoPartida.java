/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.Set;

/**
 * Clase Memento que almacena el estado interno de PartidaJuego
 */
public class MementoPartida {

    private final String ubicacion;
    private final int salud;
    private final int puntuacion;
    private final Set<String> inventario;
    private final Set<String> misionesCompletadas;

    // Constructor accesible solo desde el paquete modelo
    MementoPartida(String ubicacion, int salud, int puntuacion,
            Set<String> inventario, Set<String> misionesCompletadas) {
        this.ubicacion = ubicacion;
        this.salud = salud;
        this.puntuacion = puntuacion;
        this.inventario = inventario;
        this.misionesCompletadas = misionesCompletadas;
    }

    // Getters accesibles solo desde el paquete modelo
    String getUbicacion() {
        return ubicacion;
    }

    int getSalud() {
        return salud;
    }

    int getPuntuacion() {
        return puntuacion;
    }

    Set<String> getInventario() {
        return inventario;
    }

    Set<String> getMisionesCompletadas() {
        return misionesCompletadas;
    }
}
