/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.GestorPartidas;
import modelo.MementoPartida;
import modelo.PartidaJuego;
import modelo.EstadoJuego;
import vista.VistaJuego;

import java.util.List;

/**
 * Controlador que maneja la lógica del juego y coordina Modelo y Vista
 */
public class ControladorJuego {

    private PartidaJuego partida;
    private GestorPartidas gestorPartidas;
    private VistaJuego vista;
    private boolean enPartida;

    public ControladorJuego() {
        this.gestorPartidas = new GestorPartidas();
        this.vista = new VistaJuego();
        this.enPartida = false;
    }

    public void iniciar() {
        int opcion;
        do {
            if (enPartida) {
                menuJuego();
            } else {
                menuPrincipal();
            }
        } while (true);
    }

    private void menuPrincipal() {
        vista.mostrarMenuPrincipal();
        int opcion = vista.obtenerOpcion();

        switch (opcion) {
            case 1:
                nuevaPartida();
                break;
            case 2:
                cargarPartida();
                break;
            case 3:
                vista.mostrarMensaje("Gracias por jugar. ¡Hasta pronto!");
                System.exit(0);
                break;
            default:
                vista.mostrarMensaje("Opción no válida");
        }
    }

    private void menuJuego() {
        vista.mostrarMenuJuego();
        int opcion = vista.obtenerOpcion();

        switch (opcion) {
            case 1:
                partida.ejecutarAccion("avanzar");
                vista.mostrarMensaje("Has avanzado al bosque");
                break;
            case 2:
                partida.ejecutarAccion("recoger");
                vista.mostrarMensaje("Has recogido una espada");
                break;
            case 3:
                partida.ejecutarAccion("luchar");
                vista.mostrarMensaje("Has luchado contra un enemigo");
                break;
            case 4:
                partida.ejecutarAccion("descansar");
                vista.mostrarMensaje("Has descansado en el campamento");
                break;
            case 5:
                guardarPartida();
                break;
            case 6:
                vista.mostrarEstado(partida.getEstado().toString());
                break;
            case 7:
                enPartida = false;
                break;
            default:
                partida.ejecutarAccion("otra");
                vista.mostrarMensaje("Acción no reconocida");
        }
    }

    private void nuevaPartida() {
        this.partida = new PartidaJuego();
        this.enPartida = true;
        vista.mostrarMensaje("Nueva partida creada. ¡Buena suerte!");
    }

    private void cargarPartida() {
        List<String> partidas = gestorPartidas.listarPartidas();
        vista.mostrarPartidas(partidas);

        if (!partidas.isEmpty()) {
            int seleccion = vista.seleccionarPartida();
            MementoPartida memento = gestorPartidas.getPartida(seleccion);

            if (memento != null) {
                this.partida = new PartidaJuego();
                partida.restaurarDesdeMemento(memento);
                this.enPartida = true;
                vista.mostrarMensaje("Partida cargada correctamente");
                vista.mostrarEstado(partida.getEstado().toString());
            } else {
                vista.mostrarMensaje("Partida no válida");
            }
        }
    }

    private void guardarPartida() {
        MementoPartida memento = partida.crearMemento();
        gestorPartidas.guardarPartida(memento);
        vista.mostrarMensaje("Partida guardada correctamente");
    }
}
