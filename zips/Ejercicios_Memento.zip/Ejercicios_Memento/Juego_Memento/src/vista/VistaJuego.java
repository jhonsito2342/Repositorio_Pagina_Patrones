/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import java.util.List;
import java.util.Scanner;

/**
 * Clase responsable de la interacción con el usuario
 */
public class VistaJuego {

    private Scanner scanner = new Scanner(System.in);

    public void mostrarMenuPrincipal() {
        System.out.println("\n=== JUEGO DE AVENTURAS ===");
        System.out.println("1. Nueva partida");
        System.out.println("2. Cargar partida");
        System.out.println("3. Salir");
    }

    public void mostrarMenuJuego() {
        System.out.println("\n--- MENÚ DE JUEGO ---");
        System.out.println("1. Avanzar");
        System.out.println("2. Recoger objeto");
        System.out.println("3. Luchar");
        System.out.println("4. Descansar");
        System.out.println("5. Guardar partida");
        System.out.println("6. Mostrar estado");
        System.out.println("7. Volver al menú principal");
    }

    public int obtenerOpcion() {
        System.out.print("Seleccione una opción: ");
        return scanner.nextInt();
    }

    public void mostrarEstado(String estado) {
        System.out.println("\n--- ESTADO ACTUAL ---");
        System.out.println(estado);
    }

    public void mostrarPartidas(List<String> partidas) {
        System.out.println("\n--- PARTIDAS GUARDADAS ---");
        if (partidas.isEmpty()) {
            System.out.println("No hay partidas guardadas");
        } else {
            partidas.forEach(System.out::println);
        }
    }

    public int seleccionarPartida() {
        System.out.print("Seleccione el número de partida: ");
        return scanner.nextInt() - 1; // Convertir a índice base 0
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
}
