
package co.edu.udistrital.model;



public class Viajero {
    private String nombre;

    public Viajero(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }
}