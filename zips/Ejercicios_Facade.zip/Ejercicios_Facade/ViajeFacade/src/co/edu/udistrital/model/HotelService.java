/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */


public class HotelService {
    public boolean reservarHotel(String nombre, String destino, String fecha) {
        System.out.println("🏨 Buscando hoteles en " + destino);
        System.out.println("✅ Hotel reservado para " + nombre);
        return true;
    }
}