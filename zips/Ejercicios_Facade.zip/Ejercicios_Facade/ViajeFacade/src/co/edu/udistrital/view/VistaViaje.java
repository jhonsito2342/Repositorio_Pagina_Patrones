
package co.edu.udistrital.view;

import java.util.Scanner;



public class VistaViaje {
    private Scanner scanner;

    public VistaViaje() {
        this.scanner = new Scanner(System.in);
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }

    public String leerNombre() {
        System.out.print("Ingrese su nombre: ");
        return scanner.nextLine();
    }

    public String leerDestino() {
        System.out.print("Ingrese destino: ");
        return scanner.nextLine();
    }

    public String leerFecha() {
        System.out.print("Ingrese fecha (dd/mm/aaaa): ");
        return scanner.nextLine();
    }

    public void mostrarResultado(boolean exito, String destino, String fecha) {
        if (exito) {
            System.out.println("\n✅ Viaje a " + destino + " para " + fecha + " planificado con éxito");
        } else {
            System.out.println("\n❌ No se pudo planificar el viaje");
        }
    }
}