package co.edu.udistrital.controller;



public class Main {
    public static void main(String[] args) {
        ViajeController controller = new ViajeController();
        controller.iniciar();
    }
}