/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */


public class VueloService {
    public boolean reservarVuelo(String nombre, String destino, String fecha) {
        System.out.println("✈️ Buscando vuelos a " + destino + " para " + fecha);
        System.out.println("✅ Vuelo reservado para " + nombre);
        return true;
    }
}