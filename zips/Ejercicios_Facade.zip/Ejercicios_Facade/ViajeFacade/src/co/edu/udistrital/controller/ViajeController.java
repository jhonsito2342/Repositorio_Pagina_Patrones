
package co.edu.udistrital.controller;

import co.edu.udistrital.model.ViajeFacade;
import co.edu.udistrital.model.Viajero;
import co.edu.udistrital.view.VistaViaje;





public class ViajeController {
    private VistaViaje vista;
    private ViajeFacade facade;

    public ViajeController() {
        this.vista = new VistaViaje();
        this.facade = new ViajeFacade();
        vista.mostrarMensaje("=== SISTEMA DE PLANIFICACIÓN DE VIAJES (FACADE) ===");
    }

    public void iniciar() {
        String nombre = vista.leerNombre();
        String destino = vista.leerDestino();
        String fecha = vista.leerFecha();

        Viajero viajero = new Viajero(nombre);
        boolean exito = facade.planificarViaje(viajero, destino, fecha);

        vista.mostrarResultado(exito, destino, fecha);
    }
}