/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */



public class TrasladoService {
    public boolean programarTraslado(String nombre, String destino) {
        System.out.println("🚗 Coordinando traslado en " + destino);
        System.out.println("✅ Traslado programado para " + nombre);
        return true;
    }
}