package co.edu.udistrital.model;



public class ViajeFacade {

    private VueloService vueloService;
    private HotelService hotelService;
    private TrasladoService trasladoService;
    private SeguroService seguroService;

    public ViajeFacade() {
        this.vueloService = new VueloService();
        this.hotelService = new HotelService();
        this.trasladoService = new TrasladoService();
        this.seguroService = new SeguroService();
    }

    public boolean planificarViaje(Viajero viajero, String destino, String fecha) {
        System.out.println("\nIniciando planificación...");

        boolean vueloOK = vueloService.reservarVuelo(viajero.getNombre(), destino, fecha);
        boolean hotelOK = hotelService.reservarHotel(viajero.getNombre(), destino, fecha);
        boolean trasladoOK = trasladoService.programarTraslado(viajero.getNombre(), destino);
        boolean seguroOK = seguroService.contratarSeguro(viajero.getNombre());

        return vueloOK && hotelOK && trasladoOK && seguroOK;
    }
}
