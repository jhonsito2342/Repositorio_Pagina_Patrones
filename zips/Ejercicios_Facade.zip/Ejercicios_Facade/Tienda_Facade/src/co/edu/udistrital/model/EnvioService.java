
package co.edu.udistrital.model;



public class EnvioService {
    public boolean programarEnvio(String cliente, String direccion) {
        System.out.println("🚚 Programando envío a: " + direccion);
        System.out.println("✅ Envío programado para " + cliente);
        return true;
    }
}