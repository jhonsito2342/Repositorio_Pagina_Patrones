package co.edu.udistrital.model;




public class CompraFacade {
    private InventarioService inventario;
    private PagoService pago;
    private EnvioService envio;
    private NotificacionService notificacion;

    public CompraFacade() {
        this.inventario = new InventarioService();
        this.pago = new PagoService();
        this.envio = new EnvioService();
        this.notificacion = new NotificacionService();
    }

    public boolean realizarCompra(Cliente cliente, Producto producto, String direccion) {
        System.out.println("\nProcesando compra...");
        
        boolean disponible = inventario.verificarDisponibilidad(producto.getNombre());
        boolean pagoAprobado = pago.procesarPago(cliente.getNombre(), producto.getPrecio());
        boolean envioProgramado = envio.programarEnvio(cliente.getNombre(), direccion);
        
        if (disponible && pagoAprobado && envioProgramado) {
            notificacion.enviarConfirmacion(cliente.getNombre());
            return true;
        }
        return false;
    }
}