
package co.edu.udistrital.controller;

import co.edu.udistrital.model.Cliente;
import co.edu.udistrital.model.CompraFacade;
import co.edu.udistrital.model.Producto;
import co.edu.udistrital.view.VistaTienda;






public class TiendaController {
    private VistaTienda vista;
    private CompraFacade facade;

    public TiendaController() {
        this.vista = new VistaTienda();
        this.facade = new CompraFacade();
        vista.mostrarMensaje("=== TIENDA ONLINE (FACADE) ===");
    }

    public void iniciar() {
        String nombre = vista.leerNombre();
        String producto = vista.leerProducto();
        double precio = vista.leerPrecio();
        String direccion = vista.leerDireccion();

        Cliente cliente = new Cliente(nombre);
        Producto prod = new Producto(producto, precio);
        
        boolean exito = facade.realizarCompra(cliente, prod, direccion);
        vista.mostrarResultado(exito, producto);
    }
}