
package co.edu.udistrital.view;

import java.util.Scanner;



public class VistaTienda {
    private Scanner scanner;

    public VistaTienda() {
        this.scanner = new Scanner(System.in);
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }

    public String leerNombre() {
        System.out.print("Nombre del cliente: ");
        return scanner.nextLine();
    }

    public String leerProducto() {
        System.out.print("Producto a comprar: ");
        return scanner.nextLine();
    }

    public double leerPrecio() {
        System.out.print("Precio del producto: ");
        return scanner.nextDouble();
    }

    public String leerDireccion() {
        System.out.print("Dirección de envío: ");
        scanner.nextLine();
        return scanner.nextLine();
    }

    public void mostrarResultado(boolean exito, String producto) {
        if (exito) {
            System.out.println("\n✅ Compra de '" + producto + "' realizada con éxito");
        } else {
            System.out.println("\n❌ Error al procesar la compra");
        }
    }
}