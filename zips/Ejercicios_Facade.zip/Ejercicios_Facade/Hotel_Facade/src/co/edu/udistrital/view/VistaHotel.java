
package co.edu.udistrital.view;

import java.util.Scanner;


public class VistaHotel {
    private Scanner scanner;
    
    public VistaHotel() {
        this.scanner = new Scanner(System.in);
    }
    
    public String leerNombre() {
        System.out.print("Ingrese su nombre: ");
        return scanner.nextLine();
    }
    
    public int leerDias() {
        System.out.print("Ingrese días de estadía: ");
        return scanner.nextInt();
    }
    
    public String leerTipoHabitacion() {
        System.out.print("Tipo de habitación (Individual/Doble/Suite): ");
        scanner.nextLine();
        return scanner.nextLine();
    }
    
    public void mostrarMensaje(String msg) {
        System.out.println(msg);
    }
    
    public void mostrarResultado(boolean exito) {
        if(exito) {
            System.out.println("¡Reserva realizada con éxito!");
        } else {
            System.out.println("No se pudo completar la reserva");
        }
    }
}