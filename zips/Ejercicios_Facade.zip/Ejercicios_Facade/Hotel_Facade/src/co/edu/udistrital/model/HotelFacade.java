package co.edu.udistrital.model;

public class HotelFacade {

    private DisponibilidadService disponibilidad;
    private ReservaService reserva;
    private PagoService pago;

    public HotelFacade() {
        this.disponibilidad = new DisponibilidadService();
        this.reserva = new ReservaService();
        this.pago = new PagoService();
    }

    public boolean realizarReserva(Cliente cliente, String tipoHabitacion, int dias) {
        if (disponibilidad.verificarDisponibilidad(tipoHabitacion)) {
            if (pago.verificarPago(cliente, dias)) {
                return reserva.registrarReserva(cliente, tipoHabitacion, dias);
            }
        }
        return false;
    }
}
