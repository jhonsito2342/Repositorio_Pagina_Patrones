
package co.edu.udistrital.controller;

import co.edu.udistrital.model.Cliente;
import co.edu.udistrital.model.HotelFacade;
import co.edu.udistrital.view.VistaHotel;



public class HotelController {
    private VistaHotel vista;
    private HotelFacade facade;

    public HotelController() {
        this.vista = new VistaHotel();
        this.facade = new HotelFacade();
    }

    public void iniciar() {
        vista.mostrarMensaje("SISTEMA DE RESERVA DE HOTEL (PATRÓN FACADE)");
        
        String nombre = vista.leerNombre();
        int dias = vista.leerDias();
        String tipoHabitacion = vista.leerTipoHabitacion();
        
        Cliente cliente = new Cliente(nombre);
        boolean reservaExitosa = facade.realizarReserva(cliente, tipoHabitacion, dias);
        
        vista.mostrarResultado(reservaExitosa);
    }
}