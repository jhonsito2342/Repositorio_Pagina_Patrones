package co.edu.udistrital.controller;



public class Main {
    public static void main(String[] args) {
        HotelController controller = new HotelController();
        controller.iniciar();
    }
}
