/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */


public class ReservaService {
    public boolean registrarReserva(Cliente cliente, String tipoHabitacion, int dias) {
        System.out.println("Registrando reserva para " + cliente.getNombre());
        // Lógica compleja de reserva
        return true;
    }
}