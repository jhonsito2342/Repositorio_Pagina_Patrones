/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */

public interface ProductoLimpiezaPrototype extends Cloneable {
    ProductoLimpiezaPrototype clonar();
    void personalizar(String nombreComercial, String colorEnvase, int cantidadMl);
    String getInfo();
    String getTipo();
}