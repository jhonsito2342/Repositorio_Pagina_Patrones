/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.view;

import java.util.Scanner;

/**
 *
 * @author Jhon
 */
public class VistaConsola {

    private Scanner sc;

    public VistaConsola() {
        sc = new Scanner(System.in);
    }

    public void limpiarBuffer() {
        if (sc.hasNextLine()) {
            sc.nextLine();
        }
    }

    public void mostrarInformacion(String mensaje) {
        System.out.println(mensaje);
    }

    public int leerDatoEntero() {
        int dato = sc.nextInt();
        limpiarBuffer();
        return dato;
    }

    public String leerDatoTexto() {
        String dato = sc.nextLine();
        return dato;
    }

    public void mostrarMenu() {
        mostrarInformacion("\n--- SISTEMA DE FORMULACIÓN QUÍMICA ---");
        mostrarInformacion("1. Crear producto Detergente");
        mostrarInformacion("2. Crear producto Desinfectante");
        mostrarInformacion("3. Crear producto Limpiador Multiusos");
        mostrarInformacion("4. Mostrar todos los productos");
        mostrarInformacion("5. Salir");
        mostrarInformacion("Seleccione una opción: ");
    }

    public String pedirNombreComercial() {
        mostrarInformacion("Ingrese el nombre comercial: ");
        return leerDatoTexto();
    }

    public String pedirColorEnvase() {
        mostrarInformacion("Ingrese el color del envase: ");
        return leerDatoTexto();
    }

    public int pedirCantidadMl() {
        mostrarInformacion("Ingrese la cantidad en ml: ");
        return leerDatoEntero();
    }
}
