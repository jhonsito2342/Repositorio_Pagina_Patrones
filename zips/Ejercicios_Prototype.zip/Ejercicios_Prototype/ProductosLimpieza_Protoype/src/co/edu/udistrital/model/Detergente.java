/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */

public class Detergente implements ProductoLimpiezaPrototype {

    private final double pH = 9.5;
    private final String ingredienteActivo = "Dodecilbenceno sulfonato de sodio";
    private String nombreComercial;
    private String colorEnvase;
    private int cantidadMl;
    private final String tipo = "Detergente";

    public Detergente() {
        // Valores por defecto
        this.nombreComercial = "Detergente Base";
        this.colorEnvase = "Azul";
        this.cantidadMl = 1000;
    }

    @Override
    public ProductoLimpiezaPrototype clonar() {
        Detergente clon = new Detergente();
        clon.nombreComercial = this.nombreComercial;
        clon.colorEnvase = this.colorEnvase;
        clon.cantidadMl = this.cantidadMl;
        return clon;
    }

    @Override
    public void personalizar(String nombreComercial, String colorEnvase, int cantidadMl) {
        this.nombreComercial = nombreComercial;
        this.colorEnvase = colorEnvase;
        this.cantidadMl = cantidadMl;
    }

    @Override
    public String getInfo() {
        return String.format("%s: %s\n"
                + "pH: %.1f | Ingrediente Activo: %s\n"
                + "Envase: %s | Cantidad: %d ml\n"
                + "-----------------------------",
                tipo, nombreComercial, pH, ingredienteActivo, colorEnvase, cantidadMl);
    }

    @Override
    public String getTipo() {
        return tipo;
    }
}
