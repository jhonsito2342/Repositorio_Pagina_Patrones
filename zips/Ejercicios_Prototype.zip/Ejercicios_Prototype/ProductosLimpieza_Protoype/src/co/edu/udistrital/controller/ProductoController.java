/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.controller;

import co.edu.udistrital.model.Desinfectante;
import co.edu.udistrital.model.Detergente;
import co.edu.udistrital.model.LimpiadorMultiusos;
import co.edu.udistrital.view.VistaConsola;
import co.edu.udistrital.model.ProductoLimpiezaPrototype;

/**
 *
 * @author Jhon
 */
public class ProductoController {

    private ProductoLimpiezaPrototype[] productos;
    private int contador;
    private VistaConsola vista;

    public ProductoController() {
        this.productos = new ProductoLimpiezaPrototype[15]; // Máximo 15 productos
        this.contador = 0;
        this.vista = new VistaConsola();
    }

    public void iniciar() {
        int opcion;
        do {
            vista.mostrarMenu();
            opcion = vista.leerDatoEntero();

            switch (opcion) {
                case 1:
                    crearProducto(new Detergente());
                    break;
                case 2:
                    crearProducto(new Desinfectante());
                    break;
                case 3:
                    crearProducto(new LimpiadorMultiusos());
                    break;
                case 4:
                    listarProductos();
                    break;
                case 5:
                    vista.mostrarInformacion("Saliendo del sistema...");
                    break;
                default:
                    vista.mostrarInformacion("Opción no válida");
            }
        } while (opcion != 5);
    }

    private void crearProducto(ProductoLimpiezaPrototype prototipo) {
        if (contador < productos.length) {
            String nombre = vista.pedirNombreComercial();
            String color = vista.pedirColorEnvase();
            int cantidad = vista.pedirCantidadMl();

            ProductoLimpiezaPrototype clon = prototipo.clonar();
            clon.personalizar(nombre, color, cantidad);

            productos[contador] = clon;
            contador++;

            vista.mostrarInformacion("\nProducto creado con éxito:");
            vista.mostrarInformacion(clon.getInfo());
        } else {
            vista.mostrarInformacion("No se pueden crear más productos. Límite alcanzado.");
        }
    }

    private void listarProductos() {
        vista.mostrarInformacion("\n--- LISTA DE PRODUCTOS ---");
        for (int i = 0; i < contador; i++) {
            vista.mostrarInformacion(productos[i].getInfo());
        }
        vista.mostrarInformacion("Total productos: " + contador);
    }
}
