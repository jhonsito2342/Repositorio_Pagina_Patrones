/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */


public class LimpiadorMultiusos implements ProductoLimpiezaPrototype {
    private final double pH = 7.0;
    private final String ingredienteActivo = "Alquilpoliglucósidos";
    private String nombreComercial;
    private String colorEnvase;
    private int cantidadMl;
    private final String tipo = "Limpiador Multiusos";

    public LimpiadorMultiusos() {
        // Valores por defecto
        this.nombreComercial = "Multiusos Base";
        this.colorEnvase = "Verde";
        this.cantidadMl = 500;
    }

    @Override
    public ProductoLimpiezaPrototype clonar() {
        LimpiadorMultiusos clon = new LimpiadorMultiusos();
        clon.nombreComercial = this.nombreComercial;
        clon.colorEnvase = this.colorEnvase;
        clon.cantidadMl = this.cantidadMl;
        return clon;
    }

    @Override
    public void personalizar(String nombreComercial, String colorEnvase, int cantidadMl) {
        this.nombreComercial = nombreComercial;
        this.colorEnvase = colorEnvase;
        this.cantidadMl = cantidadMl;
    }

    @Override
    public String getInfo() {
        return String.format("%s: %s\n" +
                           "pH: %.1f | Ingrediente Activo: %s\n" +
                           "Envase: %s | Cantidad: %d ml\n" +
                           "-----------------------------",
                           tipo, nombreComercial, pH, ingredienteActivo, colorEnvase, cantidadMl);
    }

    @Override
    public String getTipo() {
        return tipo;
    }
}