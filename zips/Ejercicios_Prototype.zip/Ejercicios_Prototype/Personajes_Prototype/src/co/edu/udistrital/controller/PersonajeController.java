/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.controller;

import co.edu.udistrital.model.Arquero;
import co.edu.udistrital.model.Guerrero;
import co.edu.udistrital.model.Mago;
import co.edu.udistrital.model.PersonajePrototype;
import co.edu.udistrital.view.VistaConsola;

/**
 *
 * @author Jhon
 */
public class PersonajeController {

    private PersonajePrototype[] personajes;
    private int contador;
    private VistaConsola view;

    public PersonajeController() {
        this.personajes = new PersonajePrototype[10];
        this.contador = 0;
        this.view = new VistaConsola();
    }

    public void iniciar() {
        view.mostrarInformacion("SISTEMA DE CLONACIÓN DE PERSONAJES");
        view.mostrarInformacion("=================================");
        int opcion;
        do {
            view.mostrarMenu();
            opcion = view.leerDatoEntero();
            view.limpiarBuffer();
            switch (opcion) {
                case 1:
                    crearPersonaje(new Guerrero());
                    break;
                case 2:
                    crearPersonaje(new Mago());
                    break;
                case 3:
                    crearPersonaje(new Arquero());
                    break;
                case 4:
                    listarPersonajes();
                    break;
                case 5:
                    view.mostrarInformacion("Saliendo del sistema...");
                    break;
                default:
                    view.mostrarInformacion("Opción no válida");
            }
        } while (opcion != 5);
    }

    private void crearPersonaje(PersonajePrototype prototipo) {
        if (contador < personajes.length) {
            view.pedirNombre();
            String nombre = view.leerDatoTexto();

            view.pedirNivel();
            int nivel = view.leerDatoEntero();
            view.limpiarBuffer(); // Limpiar buffer

            PersonajePrototype clon = prototipo.clonar();
            clon.personalizar(nombre, nivel);

            personajes[contador] = clon;
            contador++;

            view.mostrarPersonaje(clon.getInfo());
        } else {
            view.mostrarInformacion("No se pueden crear más personajes. Límite alcanzado.");
        }
    }

    private void listarPersonajes() {
        String[] lista = new String[contador];
        for (int i = 0; i < contador; i++) {
            lista[i] = personajes[i].getInfo();
        }
        view.mostrarTodosPersonajes(lista);
    }
}
