/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */
public interface PersonajePrototype extends Cloneable {

    PersonajePrototype clonar();

    void personalizar(String nombre, int nivel);

    String getInfo();
}
