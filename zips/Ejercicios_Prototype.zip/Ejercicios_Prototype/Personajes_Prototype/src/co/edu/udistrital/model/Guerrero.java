/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */



public class Guerrero implements PersonajePrototype {

    private String nombre;
    private int nivel;
    private final String tipo = "Guerrero";
    private int fuerza;
    private int resistencia;

    public Guerrero() {
        // Valores por defecto
        this.nombre = "Guerrero Base";
        this.nivel = 1;
        this.fuerza = 10;
        this.resistencia = 8;
    }

    @Override
    public PersonajePrototype clonar() {
        Guerrero clon = new Guerrero();
        clon.nombre = this.nombre;
        clon.nivel = this.nivel;
        clon.fuerza = this.fuerza;
        clon.resistencia = this.resistencia;
        return clon;
    }

    @Override
    public void personalizar(String nombre, int nivel) {
        this.nombre = nombre;
        this.nivel = nivel;
    }

    @Override
    public String getInfo() {
        return String.format("%s: %s (Nivel %d) - Fuerza: %d, Resistencia: %d",
                tipo, nombre, nivel, fuerza, resistencia);
    }
}
