/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */

public class Arquero implements PersonajePrototype {
    private String nombre;
    private int nivel;
    private final String tipo = "Arquero";
    private int precision;
    private int velocidad;

    public Arquero() {
        // Valores por defecto
        this.nombre = "Arquero Base";
        this.nivel = 1;
        this.precision = 15;
        this.velocidad = 10;
    }

    @Override
    public PersonajePrototype clonar() {
        Arquero clon = new Arquero();
        clon.nombre = this.nombre;
        clon.nivel = this.nivel;
        clon.precision = this.precision;
        clon.velocidad = this.velocidad;
        return clon;
    }

    @Override
    public void personalizar(String nombre, int nivel) {
        this.nombre = nombre;
        this.nivel = nivel;
    }

    @Override
    public String getInfo() {
        return String.format("%s: %s (Nivel %d) - Precisión: %d, Velocidad: %d", 
                            tipo, nombre, nivel, precision, velocidad);
    }
}