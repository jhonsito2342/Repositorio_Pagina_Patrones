/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */



public class Mago implements PersonajePrototype {

    private String nombre;
    private int nivel;
    private final String tipo = "Mago";
    private int poderMagico;
    private int mana;

    public Mago() {
        // Valores por defecto
        this.nombre = "Mago Base";
        this.nivel = 1;
        this.poderMagico = 12;
        this.mana = 100;
    }

    @Override
    public PersonajePrototype clonar() {
        Mago clon = new Mago();
        clon.nombre = this.nombre;
        clon.nivel = this.nivel;
        clon.poderMagico = this.poderMagico;
        clon.mana = this.mana;
        return clon;
    }

    @Override
    public void personalizar(String nombre, int nivel) {
        this.nombre = nombre;
        this.nivel = nivel;
    }

    @Override
    public String getInfo() {
        return String.format("%s: %s (Nivel %d) - Poder Mágico: %d, Maná: %d",
                tipo, nombre, nivel, poderMagico, mana);
    }
}
