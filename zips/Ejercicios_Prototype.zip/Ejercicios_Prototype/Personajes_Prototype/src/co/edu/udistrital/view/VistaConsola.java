/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.view;

import java.util.Scanner;

/**
 *
 * @author Jhon
 */
public class VistaConsola {

    private Scanner sc;

    public VistaConsola() {
        sc = new Scanner(System.in);
    }

    public void mostrarInformacion(String mensaje) {
        System.out.println(mensaje);
    }

    public int leerDatoEntero() {
        int dato = 0;
        dato = sc.nextInt();
        return dato;
    }

    public String leerDatoTexto() {
        String dato = "";
        dato = sc.nextLine();
        return dato;
    }

    public void mostrarMenu() {
        System.out.println("\n--- MENÚ DE PERSONAJES ---");
        System.out.println("1. Crear Guerrero");
        System.out.println("2. Crear Mago");
        System.out.println("3. Crear Arquero");
        System.out.println("4. Mostrar personajes creados");
        System.out.println("5. Salir");
        System.out.print("Seleccione una opción: ");
    }

    public void mostrarPersonaje(String info) {
        System.out.println("\nPersonaje creado:");
        System.out.println(info);
    }

    public void mostrarTodosPersonajes(String[] lista) {
        System.out.println("\n--- LISTA DE PERSONAJES ---");
        for (String personaje : lista) {
            System.out.println(personaje);
        }
    }

    public void pedirNombre() {
        System.out.print("Ingrese nombre del personaje: ");
    }

    public void pedirNivel() {
        System.out.print("Ingrese nivel del personaje: ");
    }

    public void limpiarBuffer() {
        if (sc.hasNextLine()) {
            sc.nextLine();
        }
    }
}
