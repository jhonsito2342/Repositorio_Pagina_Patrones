/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */


public interface RecetaPastelPrototype extends Cloneable {
    RecetaPastelPrototype clonar();
    void personalizar(String relleno, String decoracion, String nombrePastel);
    String getInfo();
}