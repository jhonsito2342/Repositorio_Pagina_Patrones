/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */

public class PastelChocolate implements RecetaPastelPrototype {
    private final String tipoBizcocho = "Chocolate";
    private final int harina = 250; // gramos
    private final int huevos = 3;
    private final int leche = 150; // ml
    private String relleno;
    private String decoracion;
    private String nombrePastel;

    public PastelChocolate() {
        // Valores por defecto
        this.relleno = "Ganache de chocolate";
        this.decoracion = "Virutas de chocolate";
        this.nombrePastel = "Pastel de Chocolate Clásico";
    }

    @Override
    public RecetaPastelPrototype clonar() {
        PastelChocolate clon = new PastelChocolate();
        clon.relleno = this.relleno;
        clon.decoracion = this.decoracion;
        clon.nombrePastel = this.nombrePastel;
        return clon;
    }

    @Override
    public void personalizar(String relleno, String decoracion, String nombrePastel) {
        this.relleno = relleno;
        this.decoracion = decoracion;
        this.nombrePastel = nombrePastel;
    }

    @Override
    public String getInfo() {
        return String.format("🍰 %s\n" +
                          "Bizcocho: %s\n" +
                          "Ingredientes base: %dg harina, %d huevos, %dml leche\n" +
                          "Relleno: %s | Decoración: %s\n" +
                          "--------------------------------",
                          nombrePastel, tipoBizcocho, harina, huevos, leche, relleno, decoracion);
    }
}