/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.view;

import co.edu.udistrital.model.RecetaPastelPrototype;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Jhon
 */
public class VistaConsola {
    private Scanner sc;

    public VistaConsola() {
        sc = new Scanner(System.in);
    }

    public void mostrarMenu() {
        System.out.println("\n--- PASTELERÍA PROTOTYPE ---");
        System.out.println("1. Crear pastel de Vainilla");
        System.out.println("2. Crear pastel de Chocolate");
        System.out.println("3. Mostrar todas las recetas");
        System.out.println("4. Salir");
        System.out.print("Seleccione una opción: ");
    }

    public int leerOpcion() {
        return sc.nextInt();
    }

    public void limpiarBuffer() {
        sc.nextLine();
    }

    public String pedirDato(String mensaje) {
        System.out.print(mensaje);
        return sc.nextLine();
    }

    public void mostrarRecetas(List<RecetaPastelPrototype> recetas) {
        System.out.println("\n--- RECETAS REGISTRADAS ---");
        for (RecetaPastelPrototype receta : recetas) {
            System.out.println(receta.getInfo());
        }
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
}
