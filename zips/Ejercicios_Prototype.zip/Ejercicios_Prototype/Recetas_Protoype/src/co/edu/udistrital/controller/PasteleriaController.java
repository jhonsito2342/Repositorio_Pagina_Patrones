/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.controller;

import co.edu.udistrital.model.PastelChocolate;
import co.edu.udistrital.model.PastelVainilla;
import co.edu.udistrital.model.RecetaPastelPrototype;
import co.edu.udistrital.view.VistaConsola;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Jhon
 */
public class PasteleriaController {

    private List<RecetaPastelPrototype> recetas;
    private VistaConsola vista;

    public PasteleriaController() {
        this.recetas = new ArrayList<>();
        this.vista = new VistaConsola();
    }

    public void iniciar() {
        int opcion;
        do {
            vista.mostrarMenu();
            opcion = vista.leerOpcion();
            vista.limpiarBuffer();

            switch (opcion) {
                case 1:
                    crearPastel(new PastelVainilla());
                    break;
                case 2:
                    crearPastel(new PastelChocolate());
                    break;
                case 3:
                    vista.mostrarRecetas(recetas);
                    break;
                case 4:
                    vista.mostrarMensaje("Saliendo del sistema...");
                    break;
                default:
                    vista.mostrarMensaje("Opción no válida");
            }
        } while (opcion != 4);
    }

    private void crearPastel(RecetaPastelPrototype prototipo) {
        String nombre = vista.pedirDato("Nombre del pastel: ");
        String relleno = vista.pedirDato("Tipo de relleno: ");
        String decoracion = vista.pedirDato("Decoración: ");

        RecetaPastelPrototype clon = prototipo.clonar();
        clon.personalizar(relleno, decoracion, nombre);

        recetas.add(clon);
        vista.mostrarMensaje("\n¡Pastel creado con éxito!\n" + clon.getInfo());
    }
}
