/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */


public class PastelVainilla implements RecetaPastelPrototype {
    private final String tipoBizcocho = "Vainilla";
    private final int harina = 300; // gramos
    private final int huevos = 4;
    private final int leche = 200; // ml
    private String relleno;
    private String decoracion;
    private String nombrePastel;

    public PastelVainilla() {
        // Valores por defecto
        this.relleno = "Crema pastelera";
        this.decoracion = "Fondant blanco";
        this.nombrePastel = "Pastel de Vainilla Clásico";
    }

    @Override
    public RecetaPastelPrototype clonar() {
        PastelVainilla clon = new PastelVainilla();
        clon.relleno = this.relleno;
        clon.decoracion = this.decoracion;
        clon.nombrePastel = this.nombrePastel;
        return clon;
    }

    @Override
    public void personalizar(String relleno, String decoracion, String nombrePastel) {
        this.relleno = relleno;
        this.decoracion = decoracion;
        this.nombrePastel = nombrePastel;
    }

    @Override
    public String getInfo() {
        return String.format("🍰 %s\n" +
                          "Bizcocho: %s\n" +
                          "Ingredientes base: %dg harina, %d huevos, %dml leche\n" +
                          "Relleno: %s | Decoración: %s\n" +
                          "--------------------------------",
                          nombrePastel, tipoBizcocho, harina, huevos, leche, relleno, decoracion);
    }
}