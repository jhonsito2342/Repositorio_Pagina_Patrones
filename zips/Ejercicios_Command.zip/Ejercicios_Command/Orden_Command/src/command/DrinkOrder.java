/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package command;

import receiver.Kitchen;

public class DrinkOrder implements OrderCommand {
    private Kitchen kitchen;
    private String drink;
    private String size;
    
    public DrinkOrder(Kitchen kitchen, String drink, String size) {
        this.kitchen = kitchen;
        this.drink = drink;
        this.size = size;
    }
    
    @Override
    public void execute() {
        kitchen.prepareDrink(drink, size);
    }
    
    @Override
    public String getDescription() {
        return size + " de " + drink;
    }
}