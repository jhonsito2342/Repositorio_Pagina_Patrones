/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package command;

import receiver.Kitchen;

public class PizzaOrder implements OrderCommand {
    private Kitchen kitchen;
    private String toppings;
    
    public PizzaOrder(Kitchen kitchen, String toppings) {
        this.kitchen = kitchen;
        this.toppings = toppings;
    }
    
    @Override
    public void execute() {
        kitchen.preparePizza(toppings);
    }
    
    @Override
    public String getDescription() {
        return "Pizza con " + toppings;
    }
}