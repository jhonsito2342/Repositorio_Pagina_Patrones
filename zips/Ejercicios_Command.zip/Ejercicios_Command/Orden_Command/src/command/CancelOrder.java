/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package command;

import receiver.Kitchen;

public class CancelOrder implements OrderCommand {
    private Kitchen kitchen;
    private OrderCommand orderToCancel;
    
    public CancelOrder(Kitchen kitchen, OrderCommand orderToCancel) {
        this.kitchen = kitchen;
        this.orderToCancel = orderToCancel;
    }
    
    @Override
    public void execute() {
        System.out.println("Cancelando: " + orderToCancel.getDescription());
        // Lógica para cancelar cada tipo de orden
        if(orderToCancel instanceof BurgerOrder) {
 //           kitchen.cancelBurger(((BurgerOrder)orderToCancel).getType());
        } else if(orderToCancel instanceof PizzaOrder) {
   //         kitchen.cancelPizza(((PizzaOrder)orderToCancel).getToppings());
        } else if(orderToCancel instanceof DrinkOrder) {
     //       kitchen.cancelDrink(((DrinkOrder)orderToCancel).getDrink());
        }
    }
    
    @Override
    public String getDescription() {
        return "Cancelar: " + orderToCancel.getDescription();
    }
}