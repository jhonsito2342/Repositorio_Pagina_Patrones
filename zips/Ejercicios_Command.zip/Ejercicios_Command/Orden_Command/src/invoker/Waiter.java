/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package invoker;

import command.CancelOrder;
import command.OrderCommand;
import java.util.Stack;
import receiver.Kitchen;

public class Waiter {
    private Stack<OrderCommand> orderHistory = new Stack<>();
    
    public void takeOrder(OrderCommand order) {
        order.execute();
        orderHistory.push(order);
    }
    
    public void cancelLastOrder() {
        if(!orderHistory.isEmpty()) {
            OrderCommand lastOrder = orderHistory.pop();
            OrderCommand cancel = new CancelOrder(new Kitchen(), lastOrder);
            cancel.execute();
        }
    }
    
    public void showOrderHistory() {
        System.out.println("\n=== Historial de pedidos ===");
        orderHistory.forEach(order -> 
            System.out.println("- " + order.getDescription()));
    }
}