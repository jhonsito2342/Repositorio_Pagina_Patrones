/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

import command.*;
import invoker.Waiter;
import receiver.Kitchen;

public class Main {

    public static void main(String[] args) {
        Kitchen kitchen = new Kitchen();
        Waiter waiter = new Waiter();

        // Crear órdenes
        OrderCommand burger = new BurgerOrder(kitchen, "Clásica");
        OrderCommand pizza = new PizzaOrder(kitchen, "jamón y champiñones");
        OrderCommand drink = new DrinkOrder(kitchen, "Refresco", "Grande");

        System.out.println("=== Tomando pedidos ===");
        waiter.takeOrder(burger);
        waiter.takeOrder(pizza);
        waiter.takeOrder(drink);

        waiter.showOrderHistory();

        System.out.println("\n=== Cancelando último pedido ===");
        waiter.cancelLastOrder();

        waiter.showOrderHistory();
    }
}
