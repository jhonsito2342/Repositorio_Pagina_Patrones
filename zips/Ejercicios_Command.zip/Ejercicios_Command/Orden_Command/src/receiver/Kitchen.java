/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package receiver;

public class Kitchen {
    public void prepareBurger(String type) {
        System.out.println("Preparando hamburguesa " + type);
    }
    
    public void preparePizza(String toppings) {
        System.out.println("Preparando pizza con " + toppings);
    }
    
    public void prepareDrink(String drink, String size) {
        System.out.println("Preparando " + size + " de " + drink);
    }
    
    public void cancelBurger(String type) {
        System.out.println("Cancelando hamburguesa " + type);
    }
    
    public void cancelPizza(String toppings) {
        System.out.println("Cancelando pizza con " + toppings);
    }
    
    public void cancelDrink(String drink) {
        System.out.println("Cancelando " + drink);
    }
}