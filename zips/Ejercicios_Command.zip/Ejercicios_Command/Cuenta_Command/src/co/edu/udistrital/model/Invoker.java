package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.IOperacion;
import java.util.ArrayList;
import java.util.List;

// Invoker del patrón Command: recibe comandos y los ejecuta cuando se ordene.
public class Invoker {

	private List<IOperacion> operaciones = new ArrayList<>();

	public void recibirOperacion(IOperacion operacion) {
		this.operaciones.add(operacion);
	}

	public void realizarOperaciones() {
		this.operaciones.forEach(x -> x.execute());
		this.operaciones.clear();
	}

    public List<IOperacion> getOperaciones() {
        return operaciones;
    }

}
