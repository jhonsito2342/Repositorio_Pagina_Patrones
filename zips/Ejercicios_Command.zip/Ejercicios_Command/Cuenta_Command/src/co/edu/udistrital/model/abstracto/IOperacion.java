package co.edu.udistrital.model.abstracto;

//Command
// Interfaz Command del patrón Command. Define la operación que ejecutarán los comandos.
@FunctionalInterface
public interface IOperacion {

	void execute();
}
