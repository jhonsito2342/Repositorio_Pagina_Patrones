package co.edu.udistrital.controller;

public class AplMain {

	public static void main(String[] args) {         
            
            
            ControllerPrincipal cntrlPrin;
            cntrlPrin = new ControllerPrincipal();
            cntrlPrin.run();
	}

}
