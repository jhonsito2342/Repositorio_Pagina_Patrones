/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 *
 * @author Jhon
 */
import javax.swing.*;
import java.awt.*;

public class BancoAmigoGUI extends JFrame {

    // Atributos públicos
    public JButton btnSalir;
    public JRadioButton rbtnDepositar;
    public JButton btnAnadirMovimiento;
    public JRadioButton rbtnRetirar;
    public JTextField txtMonto;
    public JTextArea txtMovimientos;
    public JButton btnRealizarMovimientos;
    public JLabel lblNombre;
    public JLabel lblSaldo;

    public BancoAmigoGUI() {
        setTitle("Bienvenido a su BancoAmigo");
        setSize(600, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // ===== Panel superior =====
        JPanel panelSuperior = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelSuperior.setBackground(new Color(30, 30, 30));

        btnSalir = new JButton("Salir");
        estiloBoton(btnSalir, new Color(220, 53, 69), Color.WHITE);
        panelSuperior.add(btnSalir);
        add(panelSuperior, BorderLayout.NORTH);

        // ===== Panel central =====
        JPanel panelCentro = new JPanel();
        panelCentro.setLayout(new BoxLayout(panelCentro, BoxLayout.Y_AXIS));
        panelCentro.setBackground(new Color(240, 240, 240));
        panelCentro.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        lblNombre = new JLabel("");
        lblNombre.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblNombre.setAlignmentX(Component.CENTER_ALIGNMENT);
        panelCentro.add(lblNombre);

        lblSaldo = new JLabel("");
        lblSaldo.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        lblSaldo.setAlignmentX(Component.CENTER_ALIGNMENT);
        panelCentro.add(lblSaldo);

        // RadioButtons para operaciones
        JPanel panelRadios = new JPanel();
        panelRadios.setBackground(panelCentro.getBackground());

        rbtnDepositar = new JRadioButton("Depositar");
        rbtnRetirar = new JRadioButton("Retirar");
        rbtnDepositar.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        rbtnRetirar.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        rbtnDepositar.setBackground(panelCentro.getBackground());
        rbtnRetirar.setBackground(panelCentro.getBackground());

        ButtonGroup grupoOperaciones = new ButtonGroup();
        grupoOperaciones.add(rbtnDepositar);
        grupoOperaciones.add(rbtnRetirar);

        panelRadios.add(rbtnDepositar);
        panelRadios.add(rbtnRetirar);
        panelCentro.add(panelRadios);

        // Campo de monto
        JPanel panelMonto = new JPanel();
        panelMonto.setBackground(panelCentro.getBackground());
        JLabel lblMonto = new JLabel("Monto:");
        lblMonto.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtMonto = new JTextField(10);
        txtMonto.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        panelMonto.add(lblMonto);
        panelMonto.add(txtMonto);
        panelCentro.add(panelMonto);

        add(panelCentro, BorderLayout.CENTER);

        // ===== Panel inferior =====
        JPanel panelInferior = new JPanel(new BorderLayout());
        panelInferior.setBackground(new Color(230, 230, 250));
        panelInferior.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel lblInfo = new JLabel("Movimientos pendientes:");
        lblInfo.setFont(new Font("Segoe UI", Font.BOLD, 14));
        panelInferior.add(lblInfo, BorderLayout.NORTH);

        txtMovimientos = new JTextArea(5, 30);
        txtMovimientos.setEditable(false);
        txtMovimientos.setFont(new Font("Courier New", Font.PLAIN, 13));
        panelInferior.add(new JScrollPane(txtMovimientos), BorderLayout.CENTER);

        JPanel panelBotonesMovimientos = new JPanel(new GridLayout(1, 2, 10, 0));
        btnAnadirMovimiento = new JButton("Añadir movimiento");
        btnRealizarMovimientos = new JButton("Realizar movimientos");
        estiloBoton(btnAnadirMovimiento, new Color(0, 123, 255), Color.WHITE);
        estiloBoton(btnRealizarMovimientos, new Color(108, 117, 125), Color.WHITE);
        panelBotonesMovimientos.setBackground(panelInferior.getBackground());
        panelBotonesMovimientos.add(btnAnadirMovimiento);
        panelBotonesMovimientos.add(btnRealizarMovimientos);
        panelInferior.add(panelBotonesMovimientos, BorderLayout.SOUTH);

        add(panelInferior, BorderLayout.SOUTH);
    }

    // Método para aplicar estilo bonito a los botones
    private void estiloBoton(JButton boton, Color fondo, Color texto) {
        boton.setBackground(fondo);
        boton.setForeground(texto);
        boton.setFocusPainted(false);
        boton.setFont(new Font("Segoe UI", Font.BOLD, 13));
        boton.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));

    }

    public void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }
}
