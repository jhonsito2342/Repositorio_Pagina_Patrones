package co.edu.udistrital.controller;

import co.edu.udistrital.model.Cuenta;
import co.edu.udistrital.model.DepositarImpl;
import co.edu.udistrital.model.Invoker;
import co.edu.udistrital.model.RetirarImpl;
import co.edu.udistrital.view.BancoAmigoGUI;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// Client del patrón Command: crea los comandos concretos y se los entrega al Invoker.
public class ControllerPrincipal implements ActionListener {

    private BancoAmigoGUI vista;
    private Cuenta cuenta;
    private Invoker ivk;

    public ControllerPrincipal() {
        this.vista = new BancoAmigoGUI();
        añadirListener();

    }

    public void run() {
        vista.setVisible(true);
        vista.setLocationRelativeTo(null);
        String titular = "Helios account";
        double saldo = 1000;
        cuenta = new Cuenta(titular, saldo);
        ivk = new Invoker();
        vista.lblNombre.setText(titular);
        vista.lblSaldo.setText(String.valueOf(saldo));
    }

    private void añadirListener() {
        vista.btnAnadirMovimiento.addActionListener(this);
        vista.btnRealizarMovimientos.addActionListener(this);
        vista.btnSalir.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // Crea el comando según lo seleccionado y lo pasa al Invoker

        if (e.getSource() == vista.btnAnadirMovimiento) {
            try {
                double monto = Double.parseDouble(vista.txtMonto.getText());
                if (vista.rbtnDepositar.isSelected()) {
                    DepositarImpl opDepositar = new DepositarImpl(cuenta, monto);
                    ivk.recibirOperacion(opDepositar);
                    vista.txtMonto.setText("");
                    vista.txtMovimientos.append("Deposito de " + monto + ".\n");
                } else if (vista.rbtnRetirar.isSelected()) {
                    RetirarImpl opRetirar = new RetirarImpl(cuenta, monto);
                    ivk.recibirOperacion(opRetirar);
                    vista.txtMonto.setText("");
                    vista.txtMovimientos.append("Retiro de " + monto + ".\n");
                }
            } catch (NumberFormatException ex) {
                vista.mostrarError("Ingrese un monto válido.");
            }
        } else if (e.getSource() == vista.btnRealizarMovimientos) {
            ivk.realizarOperaciones();
            vista.txtMovimientos.setText("");

            vista.lblSaldo.setText(String.valueOf(cuenta.getSaldo()));
        } else if (e.getSource() == vista.btnSalir) {
            System.exit(0);
        }
    }
}
