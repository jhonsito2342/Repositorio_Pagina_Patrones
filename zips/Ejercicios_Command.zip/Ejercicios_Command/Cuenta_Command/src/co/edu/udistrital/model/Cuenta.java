package co.edu.udistrital.model;

//Receiver/Request
// Receiver del patrón Command: contiene la lógica de negocio (depositar, retirar).
public class Cuenta {

	private String titular;
	private double saldo;

	public Cuenta(String titular, double saldo) {	
		this.titular = titular;
		this.saldo = saldo;
	}

	public void retirar(double monto) {
		this.saldo = this.saldo - monto;
	}

	public void depositar(double monto) {
		this.saldo = this.saldo + monto;
	}

    public double getSaldo() {
        return saldo;
    }
        

}
