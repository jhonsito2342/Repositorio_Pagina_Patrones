package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.IOperacion;
// ConcreteCommand del patrón Command: encapsula la acción de depositar.

public class RetirarImpl implements IOperacion {

    private Cuenta cuenta;
    private double monto;
    
    // Constructor que recibe el Receiver y los parámetros.
    public RetirarImpl(Cuenta cuenta, double monto) {
        this.cuenta = cuenta;
        this.monto = monto;
    }

    // Ejecuta la operación sobre el Receiver (Cuenta)
    @Override
    public void execute() {
        this.cuenta.retirar(this.monto);
    }

}
