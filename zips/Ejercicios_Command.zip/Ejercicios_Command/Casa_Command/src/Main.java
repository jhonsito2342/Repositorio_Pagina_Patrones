/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

import command.*;
import invoker.RemoteControl;
import receiver.*;

public class Main {

    public static void main(String[] args) {
        // Dispositivos (receivers)
        Light livingRoomLight = new Light("Sala");
        Thermostat thermostat = new Thermostat();

        // Comandos
        Command lightOn = new LightOnCommand(livingRoomLight);
        Command lightOff = new LightOffCommand(livingRoomLight);
        Command tempUp = new ThermostatUpCommand(thermostat);
        Command tempDown = new ThermostatDownCommand(thermostat);

        // Macro comando (encender luz + subir temperatura)
        MacroCommand goodMorning = new MacroCommand();
        goodMorning.addCommand(lightOn);
        goodMorning.addCommand(tempUp);
        goodMorning.addCommand(tempUp);

        // Control remoto (invoker)
        RemoteControl remote = new RemoteControl();

        System.out.println("=== Prueba individual ===");
        remote.setCommand(lightOn);
        remote.pressButton();
        remote.setCommand(tempUp);
        remote.pressButton();
        remote.pressUndo();

        System.out.println("\n=== Prueba macro comando ===");
        remote.setCommand(goodMorning);
        remote.pressButton();
        remote.pressUndo();
    }
}
