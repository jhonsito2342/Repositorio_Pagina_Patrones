/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package receiver;

public class Thermostat {

    private int temperature = 20;

    public void increase() {
        temperature++;
        System.out.println("Termostato aumentado a " + temperature + "°C");
    }

    public void decrease() {
        temperature--;
        System.out.println("Termostato disminuido a " + temperature + "°C");
    }

    public int getTemperature() {
        return temperature;
    }
}
