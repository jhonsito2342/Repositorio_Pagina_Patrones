/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package command;

import receiver.Thermostat;

public class ThermostatUpCommand implements Command {

    private Thermostat thermostat;

    public ThermostatUpCommand(Thermostat thermostat) {
        this.thermostat = thermostat;
    }

    @Override
    public void execute() {
        thermostat.increase();
    }

    @Override
    public void undo() {
        thermostat.decrease();
    }
}
