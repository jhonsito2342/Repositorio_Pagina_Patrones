/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */



public class PayPal implements PaymentMethod {

    private String email;

    public PayPal(String email) {
        this.email = email;
    }

    @Override
    public void authorize(double amount) {
        System.out.printf("Autorizando $%.2f con PayPal (%s)... ", amount, email);
    }

    @Override
    public void charge(double amount) {
        System.out.printf("Cobrando $%.2f via PayPal\n", amount);
    }

    @Override
    public void refund(double amount) {
        System.out.printf("Reembolsando $%.2f a PayPal (%s)\n", amount, email);
    }
}
