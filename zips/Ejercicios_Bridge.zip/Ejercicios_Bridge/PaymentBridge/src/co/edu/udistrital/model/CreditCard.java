/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */



public class CreditCard implements PaymentMethod {

    private String cardNumber;
    private String expiry;

    public CreditCard(String cardNumber, String expiry) {
        this.cardNumber = cardNumber;
        this.expiry = expiry;
    }

    @Override
    public void authorize(double amount) {
        System.out.printf("Autorizando $%.2f con tarjeta %s... ", amount, maskCardNumber());
    }

    @Override
    public void charge(double amount) {
        System.out.printf("Cobrando $%.2f a tarjeta %s\n", amount, maskCardNumber());
    }

    @Override
    public void refund(double amount) {
        System.out.printf("Reembolsando $%.2f a tarjeta %s\n", amount, maskCardNumber());
    }

    private String maskCardNumber() {
        return "****-****-****-" + cardNumber.substring(15);
    }
}
