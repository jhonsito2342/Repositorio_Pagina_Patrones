package co.edu.udistrital.view;

import java.util.Scanner;

import java.util.Scanner;

public class PaymentView {

    private Scanner scanner = new Scanner(System.in);

    public void showWelcome() {
        System.out.println("=== SISTEMA DE PAGOS (BRIDGE PATTERN) ===");
    }

    public int selectPaymentMethod() {
        System.out.println("\nMétodo de pago:");
        System.out.println("1. Tarjeta de Crédito");
        System.out.println("2. PayPal");
        System.out.println("3. Crypto Wallet");
        System.out.print("Opción: ");
        return scanner.nextInt();
    }

    public int selectProcessorType() {
        System.out.println("\nTipo de procesador:");
        System.out.println("1. Procesador Básico");
        System.out.println("2. Procesador Seguro");
        System.out.print("Opción: ");
        return scanner.nextInt();
    }

    public double getAmount() {
        System.out.print("\nIngrese monto: ");
        return scanner.nextDouble();
    }

    public int showMenu(boolean isSecure) {
        System.out.println("\n=== OPCIONES ===");
        System.out.println("1. Procesar Pago");
        System.out.println("2. Reembolsar");
        if (isSecure) {
            System.out.println("3. Programar Pago Recurrente");
        }
        System.out.println("0. Salir");
        System.out.print("Seleccione: ");
        return scanner.nextInt();
    }

    public String getCardDetails() {
        System.out.print("Ingrese número de tarjeta (16 dígitos): ");
        return scanner.next();
    }

    public String getExpiry() {
        System.out.print("Ingrese fecha expiración (MM/YY): ");
        return scanner.next();
    }

    public String getEmail() {
        System.out.print("Ingrese email de PayPal: ");
        return scanner.next();
    }

    public String getWalletAddress() {
        System.out.print("Ingrese dirección de billetera: ");
        return scanner.next();
    }

    public String getCryptoType() {
        System.out.print("Ingrese tipo de cripto (BTC/ETH/etc): ");
        return scanner.next();
    }

    public int getMonths() {
        System.out.print("Ingrese meses para pago recurrente: ");
        return scanner.nextInt();
    }

    public void showError() {
        System.out.println("¡Opción inválida!");
    }
}
