/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */



public class BasicPaymentProcessor extends PaymentProcessor {

    public BasicPaymentProcessor(PaymentMethod paymentMethod) {
        super(paymentMethod);
    }

    @Override
    public void processPayment(double amount) {
        System.out.print("[Procesamiento Básico] ");
        paymentMethod.authorize(amount);
        paymentMethod.charge(amount);
        System.out.println("Pago básico completado: $" + amount);
    }

    @Override
    public void refundPayment(double amount) {
        System.out.print("[Procesamiento Básico] ");
        paymentMethod.refund(amount);
        System.out.println("Reembolso básico completado: $" + amount);
    }
}
