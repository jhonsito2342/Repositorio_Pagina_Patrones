/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */


public interface PaymentMethod {
    void authorize(double amount);
    void charge(double amount);
    void refund(double amount);
}