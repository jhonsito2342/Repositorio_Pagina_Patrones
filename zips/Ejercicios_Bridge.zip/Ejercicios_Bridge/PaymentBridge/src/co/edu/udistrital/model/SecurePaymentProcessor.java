/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */

public class SecurePaymentProcessor extends BasicPaymentProcessor {
    public SecurePaymentProcessor(PaymentMethod paymentMethod) {
        super(paymentMethod);
    }

    @Override
    public void processPayment(double amount) {
        System.out.print("[Procesamiento Seguro] ");
        paymentMethod.authorize(amount);
        validateSecurity();
        paymentMethod.charge(amount);
        System.out.println("Pago seguro completado: $" + amount);
    }

    private void validateSecurity() {
        System.out.print("Validando seguridad (2FA/3DSecure)... ");
    }

    public void scheduleRecurringPayment(double amount, int months) {
        System.out.printf("Programando pago recurrente: $%.2f por %d meses\n", amount, months);
        paymentMethod.authorize(amount * months);
    }
}