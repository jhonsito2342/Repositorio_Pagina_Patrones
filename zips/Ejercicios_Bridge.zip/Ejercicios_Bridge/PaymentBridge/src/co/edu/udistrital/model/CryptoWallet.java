/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */



public class CryptoWallet implements PaymentMethod {

    private String walletAddress;
    private String cryptoType;

    public CryptoWallet(String address, String cryptoType) {
        this.walletAddress = address;
        this.cryptoType = cryptoType;
    }

    @Override
    public void authorize(double amount) {
        System.out.printf("Verificando fondos de %.2f %s (%s)... ", amount, cryptoType, walletAddress.substring(0, 8));
    }

    @Override
    public void charge(double amount) {
        System.out.printf("Transfiriendo %.2f %s a nuestra billetera\n", amount, cryptoType);
    }

    @Override
    public void refund(double amount) {
        System.out.printf("Devolviendo %.2f %s a %s\n", amount, cryptoType, walletAddress.substring(0, 8));
    }
}
