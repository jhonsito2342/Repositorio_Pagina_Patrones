package co.edu.udistrital.controller;

public class Main {
    public static void main(String[] args) {
        PaymentController controller = new PaymentController();
        controller.start();
    }
}