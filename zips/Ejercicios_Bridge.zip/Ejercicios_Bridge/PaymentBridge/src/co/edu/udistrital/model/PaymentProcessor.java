package co.edu.udistrital.model;




public abstract class PaymentProcessor {

    protected PaymentMethod paymentMethod;

    public PaymentProcessor(PaymentMethod paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public abstract void processPayment(double amount);

    public abstract void refundPayment(double amount);
}
