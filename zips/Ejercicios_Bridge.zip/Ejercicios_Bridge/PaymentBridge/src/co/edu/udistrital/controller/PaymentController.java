package co.edu.udistrital.controller;

import co.edu.udistrital.model.BasicPaymentProcessor;
import co.edu.udistrital.model.CreditCard;
import co.edu.udistrital.model.CryptoWallet;
import co.edu.udistrital.model.PayPal;
import co.edu.udistrital.model.PaymentMethod;
import co.edu.udistrital.model.PaymentProcessor;
import co.edu.udistrital.model.SecurePaymentProcessor;
import co.edu.udistrital.view.PaymentView;



public class PaymentController {

    private PaymentView view;
    private PaymentProcessor processor;

    public PaymentController() {
        this.view = new PaymentView();
    }

    public void start() {
        view.showWelcome();
        setupPaymentSystem();
        handlePayments();
    }

    private void setupPaymentSystem() {
        int methodOption = view.selectPaymentMethod();
        PaymentMethod method = createPaymentMethod(methodOption);

        if (method != null) {
            int processorOption = view.selectProcessorType();
            processor = createPaymentProcessor(processorOption, method);
        }
    }

    private PaymentMethod createPaymentMethod(int option) {
        switch (option) {
            case 1:
                return new CreditCard(view.getCardDetails(), view.getExpiry());
            case 2:
                return new PayPal(view.getEmail());
            case 3:
                return new CryptoWallet(view.getWalletAddress(), view.getCryptoType());
            default:
                view.showError();
                return null;
        }
    }

    private PaymentProcessor createPaymentProcessor(int option, PaymentMethod method) {
        switch (option) {
            case 1:
                return new BasicPaymentProcessor(method);
            case 2:
                return new SecurePaymentProcessor(method);
            default:
                view.showError();
                return null;
        }
    }

    private void handlePayments() {
        if (processor == null) {
            return;
        }

        boolean isSecure = processor instanceof SecurePaymentProcessor;
        int option;

        do {
            option = view.showMenu(isSecure);
            double amount = view.getAmount();

            switch (option) {
                case 1:
                    processor.processPayment(amount);
                    break;
                case 2:
                    processor.refundPayment(amount);
                    break;
                case 3:
                    if (isSecure) {
                        ((SecurePaymentProcessor) processor)
                                .scheduleRecurringPayment(amount, view.getMonths());
                    }
                    break;
                case 0:
                    break;
                default:
                    view.showError();
            }
        } while (option != 0);
    }
}
