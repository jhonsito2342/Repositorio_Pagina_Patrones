/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */
public class ReproductorAvanzado extends ReproductorBasico {

    public ReproductorAvanzado(ReproductorImpl implementacion) {
        super(implementacion);
    }

    public void ajustarCalidad(int calidad) {
        System.out.print("Avanzado > ");
        implementacion.setCalidad(calidad);
    }

    public void habilitarSubtitulos(boolean activar) {
        System.out.print("Avanzado > ");
        implementacion.configurarSubtitulos(activar);
    }

    @Override
    public void mostrarMetadata() {
        System.out.print("Avanzado > ");
        implementacion.obtenerMetadataCompleta();
    }
}
