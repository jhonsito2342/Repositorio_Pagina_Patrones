package co.edu.udistrital.controller;

import co.edu.udistrital.model.AudioPlayer;
import co.edu.udistrital.model.Reproductor;
import co.edu.udistrital.model.ReproductorAvanzado;
import co.edu.udistrital.model.ReproductorBasico;
import co.edu.udistrital.model.ReproductorImpl;
import co.edu.udistrital.model.StreamPlayer;
import co.edu.udistrital.model.VideoPlayer;
import co.edu.udistrital.view.VistaMedia;

public class MediaController {

    private VistaMedia vista;
    private Reproductor reproductor;

    public MediaController() {
        this.vista = new VistaMedia();
    }

    public void iniciar() {
        vista.mostrarMenuPrincipal();
        int opcionMedio = vista.leerOpcion();

        ReproductorImpl implementacion = crearImplementacion(opcionMedio);
        if (implementacion == null) {
            return;
        }

        reproductor = crearReproductor(implementacion);
        if (reproductor == null) {
            return;
        }

        manejarControles();
    }

    private ReproductorImpl crearImplementacion(int opcion) {
        switch (opcion) {
            case 1:
                return new VideoPlayer();
            case 2:
                return new AudioPlayer();
            case 3:
                return new StreamPlayer();
            default:
                vista.mostrarError();
                return null;
        }
    }

    private Reproductor crearReproductor(ReproductorImpl impl) {
        System.out.println("\n1. Reproductor Básico");
        System.out.println("2. Reproductor Avanzado");
        System.out.print("Seleccione tipo: ");
        int opcion = vista.leerOpcion();

        switch (opcion) {
            case 1:
                return new ReproductorBasico(impl);
            case 2:
                return new ReproductorAvanzado(impl);
            default:
                vista.mostrarError();
                return null;
        }
    }

    private void manejarControles() {
        boolean esAvanzado = reproductor instanceof ReproductorAvanzado;
        int opcion;

        do {
            vista.mostrarMenuReproductor(esAvanzado);
            opcion = vista.leerOpcion();

            switch (opcion) {
                case 1:
                    reproductor.play();
                    break;
                case 2:
                    reproductor.pause();
                    break;
                case 3:
                    reproductor.stop();
                    break;
                case 4:
                    reproductor.mostrarMetadata();
                    break;
                case 5:
                    if (esAvanzado) {
                        ((ReproductorAvanzado) reproductor).ajustarCalidad(vista.leerCalidad());
                    }
                    break;
                case 6:
                    if (esAvanzado) {
                        System.out.println("¿Activar subtítulos? (1=Sí/0=No)");
                        ((ReproductorAvanzado) reproductor).habilitarSubtitulos(vista.leerOpcion() == 1);
                    }
                    break;
                case 0:
                    break;
                default:
                    vista.mostrarError();
            }
        } while (opcion != 0);
    }
}
