/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */



public class StreamPlayer implements ReproductorImpl {

    private String streamUrl = "";
    private int bufferSize = 1024;
    private boolean isLive = false;

    @Override
    public void iniciarReproduccion() {
        System.out.println("Iniciando stream: " + streamUrl
                + " | " + (isLive ? "LIVE" : "On-Demand"));
    }

    @Override
    public void pausarReproduccion() {
        System.out.println("Stream en pausa (buffering...)");
    }

    @Override
    public void detenerReproduccion() {
        System.out.println("Stream detenido. Cerrando conexión...");
    }

    @Override
    public void obtenerMetadata() {
        System.out.println("Stream: " + (isLive ? "Transmisión en vivo" : "Contenido bajo demanda"));
    }

    @Override
    public void obtenerMetadataCompleta() {
        System.out.println("Stream Metadata: " + streamUrl
                + " | Buffer: " + bufferSize + "KB"
                + " | Tipo: " + (isLive ? "LIVE" : "VOD"));
    }

    @Override
    public void setCalidad(int calidad) {
        this.bufferSize = calidad;
        System.out.println("Buffer ajustado a: " + bufferSize + "KB");
    }

    @Override
    public void configurarSubtitulos(boolean activar) {
        System.out.println("Subtítulos " + (activar ? "habilitados" : "deshabilitados")
                + " para stream");
    }
}
