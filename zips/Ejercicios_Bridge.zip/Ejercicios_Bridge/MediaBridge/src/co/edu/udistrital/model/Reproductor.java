package co.edu.udistrital.model;




public abstract class Reproductor {

    protected ReproductorImpl implementacion;

    public Reproductor(ReproductorImpl implementacion) {
        this.implementacion = implementacion;
    }

    public abstract void play();

    public abstract void pause();

    public abstract void stop();

    public abstract void mostrarMetadata();
}
