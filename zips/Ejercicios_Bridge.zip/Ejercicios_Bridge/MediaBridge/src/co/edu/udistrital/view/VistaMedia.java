package co.edu.udistrital.view;

import java.util.Scanner;

public class VistaMedia {

    private Scanner scanner = new Scanner(System.in);

    public void mostrarMenuPrincipal() {
        System.out.println("\n=== REPRODUCTOR MULTIMEDIA (BRIDGE) ===");
        System.out.println("1. Video Player");
        System.out.println("2. Audio Player");
        System.out.println("3. Stream Player");
        System.out.print("Seleccione medio: ");
    }

    public void mostrarMenuReproductor(boolean esAvanzado) {
        System.out.println("\n=== CONTROLES ===");
        System.out.println("1. Play");
        System.out.println("2. Pause");
        System.out.println("3. Stop");
        System.out.println("4. Mostrar Metadata");
        if (esAvanzado) {
            System.out.println("5. Ajustar Calidad");
            System.out.println("6. Subtítulos");
        }
        System.out.println("0. Salir");
        System.out.print("Opción: ");
    }

    public int leerOpcion() {
        return scanner.nextInt();
    }

    public int leerCalidad() {
        System.out.print("Ingrese calidad (360, 480, 720, 1080): ");
        return scanner.nextInt();
    }

    public void mostrarError() {
        System.out.println("¡Opción no válida!");
    }
}
