/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */
public class ReproductorBasico extends Reproductor {

    public ReproductorBasico(ReproductorImpl implementacion) {
        super(implementacion);
    }

    @Override
    public void play() {
        System.out.print("Básico > ");
        implementacion.iniciarReproduccion();
    }

    @Override
    public void pause() {
        System.out.print("Básico > ");
        implementacion.pausarReproduccion();
    }

    @Override
    public void stop() {
        System.out.print("Básico > ");
        implementacion.detenerReproduccion();
    }

    @Override
    public void mostrarMetadata() {
        System.out.print("Básico > ");
        implementacion.obtenerMetadata();
    }
}
