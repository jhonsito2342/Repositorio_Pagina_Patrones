/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */



public class VideoPlayer implements ReproductorImpl {
    private String currentFile = "";
    private int calidad = 720;
    private boolean subtitulos = false;

    @Override
    public void iniciarReproduccion() {
        System.out.println("Reproduciendo video: " + currentFile + " en " + calidad + "p");
    }

    @Override
    public void pausarReproduccion() {
        System.out.println("Video pausado");
    }

    @Override
    public void detenerReproduccion() {
        System.out.println("Video detenido. Liberando recursos...");
    }

    @Override
    public void obtenerMetadata() {
        System.out.println("Formato: MP4 | Duración: 120min");
    }

    @Override
    public void obtenerMetadataCompleta() {
        System.out.println("Video Metadata: MP4 120min | Codec: H.264 | Bitrate: 5000kbps");
    }

    @Override
    public void setCalidad(int calidad) {
        this.calidad = calidad;
        System.out.println("Calidad ajustada a: " + calidad + "p");
    }

    @Override
    public void configurarSubtitulos(boolean activar) {
        this.subtitulos = activar;
        System.out.println("Subtítulos " + (activar ? "activados" : "desactivados"));
    }
}