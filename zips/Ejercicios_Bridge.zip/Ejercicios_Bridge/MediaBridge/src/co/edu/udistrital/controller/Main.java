package co.edu.udistrital.controller;

public class Main {

    public static void main(String[] args) {
        MediaController controller = new MediaController();
        controller.iniciar();
    }
}
