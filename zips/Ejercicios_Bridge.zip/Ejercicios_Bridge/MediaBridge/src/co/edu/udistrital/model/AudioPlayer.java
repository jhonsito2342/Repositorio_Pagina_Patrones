/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */


public class AudioPlayer implements ReproductorImpl {
    private String currentTrack = "";
    private String formato = "MP3";
    private int bitrate = 192;

    @Override
    public void iniciarReproduccion() {
        System.out.println("Reproduciendo audio: " + currentTrack + " (" + formato + " @ " + bitrate + "kbps)");
    }

    @Override
    public void pausarReproduccion() {
        System.out.println("Audio pausado");
    }

    @Override
    public void detenerReproduccion() {
        System.out.println("Audio detenido. Liberando buffers...");
    }

    @Override
    public void obtenerMetadata() {
        System.out.println("Formato: " + formato + " | Bitrate: " + bitrate + "kbps");
    }

    @Override
    public void obtenerMetadataCompleta() {
        System.out.println("Audio Metadata: " + formato + " | Bitrate: " + bitrate + 
                         "kbps | Canales: Stereo | Sample Rate: 44.1kHz");
    }

    @Override
    public void setCalidad(int calidad) {
        this.bitrate = calidad;
        System.out.println("Bitrate ajustado a: " + bitrate + "kbps");
    }

    @Override
    public void configurarSubtitulos(boolean activar) {
        System.out.println("Subtítulos no disponibles en audio");
    }
}