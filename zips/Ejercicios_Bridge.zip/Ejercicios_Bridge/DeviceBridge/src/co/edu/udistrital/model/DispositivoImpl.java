package co.edu.udistrital.model;




public interface DispositivoImpl {

    void encenderImpl();

    void apagarImpl();

    void subirVolumenImpl();

    void bajarVolumenImpl();

    void setVolumen(int nivel);

    void modoEspecial(String modo);
}
