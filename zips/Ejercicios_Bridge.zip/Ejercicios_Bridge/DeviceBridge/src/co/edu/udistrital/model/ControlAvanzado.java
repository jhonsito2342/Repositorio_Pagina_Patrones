/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */


public class ControlAvanzado extends ControlRemoto {
    public ControlAvanzado(DispositivoImpl implementacion) {
        super(implementacion);
    }

    public void mute() {
        System.out.print("Control Avanzado > ");
        implementacion.setVolumen(0);
    }

    public void setVolumen(int nivel) {
        System.out.print("Control Avanzado > ");
        implementacion.setVolumen(nivel);
    }

    public void modoSilencio() {
        System.out.print("Control Avanzado > ");
        implementacion.modoEspecial("Silencio");
    }
}