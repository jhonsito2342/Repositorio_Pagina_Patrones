/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */
public class TV implements DispositivoImpl {

    private boolean encendida = false;
    private int volumen = 20;
    private String modoActual = "Normal";

    @Override
    public void encenderImpl() {
        encendida = true;
        System.out.println("TV encendida");
    }

    @Override
    public void apagarImpl() {
        encendida = false;
        System.out.println("TV apagada");
    }

    @Override
    public void subirVolumenImpl() {
        volumen = Math.min(100, volumen + 5);
        System.out.println("Volumen TV: " + volumen);
    }

    @Override
    public void bajarVolumenImpl() {
        volumen = Math.max(0, volumen - 5);
        System.out.println("Volumen TV: " + volumen);
    }

    @Override
    public void setVolumen(int nivel) {
        volumen = Math.max(0, Math.min(100, nivel));
        System.out.println("Volumen TV ajustado a: " + volumen);
    }

    @Override
    public void modoEspecial(String modo) {
        modoActual = modo;
        System.out.println("Modo " + modo + " activado");
    }
}
