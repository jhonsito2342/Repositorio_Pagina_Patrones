package co.edu.udistrital.model;

public abstract class Dispositivo {

    protected DispositivoImpl implementacion;

    public Dispositivo(DispositivoImpl implementacion) {
        this.implementacion = implementacion;
    }

    public abstract void encender();

    public abstract void apagar();

    public abstract void subirVolumen();

    public abstract void bajarVolumen();
}
