package co.edu.udistrital.controller;



public class Main {
    public static void main(String[] args) {
        DeviceController controller = new DeviceController();
        controller.iniciar();
    }
}