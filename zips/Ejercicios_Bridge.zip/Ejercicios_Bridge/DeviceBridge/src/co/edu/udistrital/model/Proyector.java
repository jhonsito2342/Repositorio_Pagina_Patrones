package co.edu.udistrital.model;




public class Proyector implements DispositivoImpl {

    private boolean encendido = false;
    private int volumen = 0;
    private String entrada = "HDMI";

    @Override
    public void encenderImpl() {
        encendido = true;
        System.out.println("Proyector encendido (Entrada: " + entrada + ")");
    }

    @Override
    public void apagarImpl() {
        encendido = false;
        System.out.println("Proyector apagado");
    }

    @Override
    public void subirVolumenImpl() {
        System.out.println("Proyector no tiene control de volumen");
    }

    @Override
    public void bajarVolumenImpl() {
        System.out.println("Proyector no tiene control de volumen");
    }

    @Override
    public void setVolumen(int nivel) {
        System.out.println("Proyector no tiene control de volumen");
    }

    @Override
    public void modoEspecial(String modo) {
        System.out.println("Modo proyección: " + modo + " (Brillo ajustado)");
    }
}
