package co.edu.udistrital.controller;

import co.edu.udistrital.model.ControlAvanzado;
import co.edu.udistrital.model.ControlRemoto;
import co.edu.udistrital.model.Dispositivo;
import co.edu.udistrital.model.DispositivoImpl;
import co.edu.udistrital.model.Proyector;
import co.edu.udistrital.model.Radio;
import co.edu.udistrital.model.TV;
import co.edu.udistrital.view.VistaDevice;

public class DeviceController {

    private VistaDevice vista;
    private Dispositivo dispositivo;

    public DeviceController() {
        this.vista = new VistaDevice();
    }

    public void iniciar() {
        vista.mostrarBienvenida();
        configurarDispositivo();
        manejarControles();
    }

    private void configurarDispositivo() {
        int opcionDispositivo = vista.seleccionarDispositivo();
        DispositivoImpl implementacion = crearImplementacion(opcionDispositivo);

        if (implementacion != null) {
            int opcionControl = vista.seleccionarControl();
            dispositivo = crearControl(opcionControl, implementacion);
        }
    }

    private DispositivoImpl crearImplementacion(int opcion) {
        switch (opcion) {
            case 1:
                return new TV();
            case 2:
                return new Radio();
            case 3:
                return new Proyector();
            default:
                vista.mostrarError();
                return null;
        }
    }

    private Dispositivo crearControl(int opcion, DispositivoImpl impl) {
        switch (opcion) {
            case 1:
                return new ControlRemoto(impl);
            case 2:
                return new ControlAvanzado(impl);
            default:
                vista.mostrarError();
                return null;
        }
    }

    private void manejarControles() {
        if (dispositivo == null) {
            return;
        }

        boolean esAvanzado = dispositivo instanceof ControlAvanzado;
        int opcion;

        do {
            opcion = vista.mostrarMenuControles(esAvanzado);

            switch (opcion) {
                case 1:
                    dispositivo.encender();
                    break;
                case 2:
                    dispositivo.apagar();
                    break;
                case 3:
                    dispositivo.subirVolumen();
                    break;
                case 4:
                    dispositivo.bajarVolumen();
                    break;
                case 5:
                    if (esAvanzado) {
                        ((ControlAvanzado) dispositivo).mute();
                    }
                    break;
                case 6:
                    if (esAvanzado) {
                        ((ControlAvanzado) dispositivo).setVolumen(vista.leerVolumen());
                    }
                    break;
                case 7:
                    if (esAvanzado) {
                        ((ControlAvanzado) dispositivo).modoSilencio();
                    }
                    break;
                case 0:
                    break;
                default:
                    vista.mostrarError();
            }
        } while (opcion != 0);
    }
}
