/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */



public class Radio implements DispositivoImpl {

    private boolean encendida = false;
    private int volumen = 15;
    private String estacion = "FM 98.5";

    @Override
    public void encenderImpl() {
        encendida = true;
        System.out.println("Radio encendida (" + estacion + ")");
    }

    @Override
    public void apagarImpl() {
        encendida = false;
        System.out.println("Radio apagada");
    }

    @Override
    public void subirVolumenImpl() {
        volumen = Math.min(50, volumen + 3);
        System.out.println("Volumen Radio: " + volumen);
    }

    @Override
    public void bajarVolumenImpl() {
        volumen = Math.max(0, volumen - 3);
        System.out.println("Volumen Radio: " + volumen);
    }

    @Override
    public void setVolumen(int nivel) {
        volumen = Math.max(0, Math.min(50, nivel));
        System.out.println("Volumen Radio ajustado a: " + volumen);
    }

    @Override
    public void modoEspecial(String modo) {
        System.out.println("Radio no soporta modo " + modo);
    }
}
