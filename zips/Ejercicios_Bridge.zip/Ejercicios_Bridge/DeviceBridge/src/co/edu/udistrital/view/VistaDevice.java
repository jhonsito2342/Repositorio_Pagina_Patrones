package co.edu.udistrital.view;

import java.util.Scanner;

public class VistaDevice {

    private Scanner scanner = new Scanner(System.in);

    public void mostrarBienvenida() {
        System.out.println("=== SISTEMA DE CONTROL DE DISPOSITIVOS (BRIDGE) ===");
    }

    public int seleccionarDispositivo() {
        System.out.println("\nSeleccione dispositivo:");
        System.out.println("1. Televisor");
        System.out.println("2. Radio");
        System.out.println("3. Proyector");
        System.out.print("Opción: ");
        return scanner.nextInt();
    }

    public int seleccionarControl() {
        System.out.println("\nSeleccione control:");
        System.out.println("1. Control Remoto Básico");
        System.out.println("2. Control Remoto Avanzado");
        System.out.print("Opción: ");
        return scanner.nextInt();
    }

    public int mostrarMenuControles(boolean esAvanzado) {
        System.out.println("\n=== CONTROLES ===");
        System.out.println("1. Encender");
        System.out.println("2. Apagar");
        System.out.println("3. Subir Volumen");
        System.out.println("4. Bajar Volumen");
        if (esAvanzado) {
            System.out.println("5. Silenciar");
            System.out.println("6. Ajustar Volumen Exacto");
            System.out.println("7. Modo Especial");
        }
        System.out.println("0. Salir");
        System.out.print("Seleccione: ");
        return scanner.nextInt();
    }

    public int leerVolumen() {
        System.out.print("Ingrese nivel de volumen: ");
        return scanner.nextInt();
    }

    public String leerModoEspecial() {
        System.out.print("Ingrese modo especial: ");
        scanner.nextLine();
        return scanner.nextLine();
    }

    public void mostrarError() {
        System.out.println("¡Opción no válida!");
    }
}
