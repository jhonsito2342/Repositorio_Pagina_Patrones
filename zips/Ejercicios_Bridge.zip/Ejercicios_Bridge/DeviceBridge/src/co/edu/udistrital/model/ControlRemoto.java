/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

/**
 *
 * @author Jhon
 */




public class ControlRemoto extends Dispositivo {
    public ControlRemoto(DispositivoImpl implementacion) {
        super(implementacion);
    }

    @Override
    public void encender() {
        System.out.print("Control Remoto > ");
        implementacion.encenderImpl();
    }

    @Override
    public void apagar() {
        System.out.print("Control Remoto > ");
        implementacion.apagarImpl();
    }

    @Override
    public void subirVolumen() {
        System.out.print("Control Remoto > ");
        implementacion.subirVolumenImpl();
    }

    @Override
    public void bajarVolumen() {
        System.out.print("Control Remoto > ");
        implementacion.bajarVolumenImpl();
    }
}