/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.*;
import vista.ShapeView;

public class ShapeController {
    private ShapeView view;

    public ShapeController() {
        this.view = new ShapeView();
        
        Shape[] shapes = {
            new Circle(5),
            new Rectangle(4, 6),
            new Circle(3)
        };
        
        AreaCalculatorVisitor areaCalculator = new AreaCalculatorVisitor();
        
        for (Shape shape : shapes) {
            shape.accept(areaCalculator);
        }
        
        view.showArea(areaCalculator.getTotalArea());
    }
}