/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class WordCountVisitor implements DocumentVisitor {

    private int wordCount;

    @Override
    public void visit(TextDocument document) {
        String content = document.getContent();
        wordCount += content.split("\\s+").length;
    }

    @Override
    public void visit(PdfDocument document) {
        String content = document.getContent();
        wordCount += content.split("\\s+").length;
    }

    public int getWordCount() {
        return wordCount;
    }
}
