/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class PdfDocument implements Document {

    private String content;
    private int pageCount;

    public PdfDocument(String content, int pageCount) {
        this.content = content;
        this.pageCount = pageCount;
    }

    @Override
    public void accept(DocumentVisitor visitor) {
        visitor.visit(this);
    }

    @Override
    public String getContent() {
        return content;
    }

    public int getPageCount() {
        return pageCount;
    }
}
