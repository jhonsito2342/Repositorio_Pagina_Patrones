/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.*;
import vista.DocumentView;

public class DocumentController {

    private DocumentView view;

    public DocumentController() {
        this.view = new DocumentView();

        Document[] documents = {
            new TextDocument("Este es un documento de texto simple"),
            new PdfDocument("PDF con contenido de ejemplo", 3),
            new TextDocument("Otro documento con más palabras")
        };

        WordCountVisitor wordCounter = new WordCountVisitor();

        for (Document doc : documents) {
            doc.accept(wordCounter);
        }

        view.showResult("Total de palabras: " + wordCounter.getWordCount());
    }
}
