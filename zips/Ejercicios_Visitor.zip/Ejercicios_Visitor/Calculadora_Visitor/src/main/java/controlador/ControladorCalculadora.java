/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.*;
import vista.VistaCalculadora;

public class ControladorCalculadora {

    private VistaCalculadora vista;

    public ControladorCalculadora() {
        this.vista = new VistaCalculadora();

        // Crear expresión: (5 + (3 - 2))
        Expresion expresion = new Operacion('+',
                new Numero(5),
                new Operacion('-',
                        new Numero(3),
                        new Numero(2)
                )
        );

        // Visitor para evaluar
        VisitanteEvaluador evaluador = new VisitanteEvaluador();
        expresion.aceptar(evaluador);
        vista.mostrarResultado(evaluador.getResultado());

        // Visitor para imprimir
        VisitanteImpresor impresor = new VisitanteImpresor();
        expresion.aceptar(impresor);
        vista.mostrarExpresion(impresor.getExpresion());
    }
}
