/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

// ConcreteElement
public class Numero implements Expresion {

    private int valor;

    public Numero(int valor) {
        this.valor = valor;
    }

    @Override
    public void aceptar(VisitanteExpresion visitante) {
        visitante.visitar(this);
    }

    public int getValor() {
        return valor;
    }
}
