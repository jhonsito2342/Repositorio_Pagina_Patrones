/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class VisitanteImpresor implements VisitanteExpresion {

    private StringBuilder expresion = new StringBuilder();

    @Override
    public void visitar(Numero numero) {
        expresion.append(numero.getValor());
    }

    @Override
    public void visitar(Operacion operacion) {
        expresion.append("(");
        operacion.getIzquierda().aceptar(this);
        expresion.append(" ").append(operacion.getOperador()).append(" ");
        operacion.getDerecha().aceptar(this);
        expresion.append(")");
    }

    public String getExpresion() {
        return expresion.toString();
    }
}
