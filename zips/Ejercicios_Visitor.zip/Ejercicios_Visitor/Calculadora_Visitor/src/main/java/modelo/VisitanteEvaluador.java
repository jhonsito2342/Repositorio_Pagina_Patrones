/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class VisitanteEvaluador implements VisitanteExpresion {
    private int resultado;

    @Override
    public void visitar(Numero numero) {
        resultado = numero.getValor();
    }

    @Override
    public void visitar(Operacion operacion) {
        VisitanteEvaluador visitanteIzq = new VisitanteEvaluador();
        VisitanteEvaluador visitanteDer = new VisitanteEvaluador();
        
        operacion.getIzquierda().aceptar(visitanteIzq);
        operacion.getDerecha().aceptar(visitanteDer);
        
        switch(operacion.getOperador()) {
            case '+': resultado = visitanteIzq.getResultado() + visitanteDer.getResultado(); break;
            case '-': resultado = visitanteIzq.getResultado() - visitanteDer.getResultado(); break;
        }
    }

    public int getResultado() {
        return resultado;
    }
}