/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

// ConcreteElement
public class Operacion implements Expresion {

    private char operador;
    private Expresion izquierda;
    private Expresion derecha;

    public Operacion(char operador, Expresion izq, Expresion der) {
        this.operador = operador;
        this.izquierda = izq;
        this.derecha = der;
    }

    @Override
    public void aceptar(VisitanteExpresion visitante) {
        visitante.visitar(this);
    }

    public char getOperador() {
        return operador;
    }

    public Expresion getIzquierda() {
        return izquierda;
    }

    public Expresion getDerecha() {
        return derecha;
    }
}
