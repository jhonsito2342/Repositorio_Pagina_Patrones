/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

public class VistaCalculadora {

    public void mostrarResultado(int resultado) {
        System.out.println("Resultado: " + resultado);
    }

    public void mostrarExpresion(String expresion) {
        System.out.println("Expresión: " + expresion);
    }
}
