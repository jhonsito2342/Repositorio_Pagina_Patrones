/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.Arrays;
import java.util.Comparator;

public class GestorReservas {
    // Método que implementa orden de bloqueos para múltiples recursos
    public static boolean reservarRecursos(Recurso... recursos) {
        // Ordenar recursos por ID para garantizar orden consistente
        Arrays.sort(recursos, Comparator.comparing(Recurso::getId));
        
        try {
            // Adquirir bloqueos en orden
            for (Recurso recurso : recursos) {
                recurso.getLock().lock();
            }
            
            // Verificar disponibilidad
            for (Recurso recurso : recursos) {
                if (recurso.isReservado()) {
                    return false;
                }
            }
            
            // Reservar recursos
            for (Recurso recurso : recursos) {
                recurso.reservar();
            }
            
            return true;
        } finally {
            // Liberar bloqueos en orden inverso
            for (int i = recursos.length - 1; i >= 0; i--) {
                recursos[i].getLock().unlock();
            }
        }
    }

    public static void liberarRecursos(Recurso... recursos) {
        Arrays.sort(recursos, Comparator.comparing(Recurso::getId));
        
        try {
            for (Recurso recurso : recursos) {
                recurso.getLock().lock();
            }
            
            for (Recurso recurso : recursos) {
                recurso.liberar();
            }
        } finally {
            for (int i = recursos.length - 1; i >= 0; i--) {
                recursos[i].getLock().unlock();
            }
        }
    }

}
