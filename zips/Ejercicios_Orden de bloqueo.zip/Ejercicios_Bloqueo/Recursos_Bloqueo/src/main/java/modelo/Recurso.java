/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Recurso {

    private final String id;
    private boolean reservado;
    private final Lock lock = new ReentrantLock();

    public Recurso(String id) {
        this.id = id;
        this.reservado = false;
    }

    public boolean reservar() {
        lock.lock();
        try {
            if (!reservado) {
                reservado = true;
                return true;
            }
            return false;
        } finally {
            lock.unlock();
        }
    }

    public void liberar() {
        lock.lock();
        try {
            reservado = false;
        } finally {
            lock.unlock();
        }
    }

    public String getId() {
        return id;
    }

    public boolean isReservado() {
        return reservado;
    }

    public Lock getLock() {
        return lock;
    }
}
