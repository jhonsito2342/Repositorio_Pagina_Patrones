/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.GestorReservas;
import modelo.Recurso;
import vista.VistaReservas;

public class ControladorReservas {
    private final Recurso[] recursos;
    private final VistaReservas vista;

    public ControladorReservas() {
        this.recursos = new Recurso[]{
            new Recurso("R001"),
            new Recurso("R002"),
            new Recurso("R003"),
            new Recurso("R004")
        };
        this.vista = new VistaReservas();
    }

    public void iniciar() {
        int opcion;
        do {
            vista.mostrarMenu();
            opcion = vista.obtenerOpcion();

            switch (opcion) {
                case 1:
                    reservarRecursos();
                    break;
                case 2:
                    liberarRecursos();
                    break;
                case 3:
                    vista.mostrarEstadoRecursos(recursos);
                    break;
                case 4:
                    simularReservasConcurrentes();
                    break;
                case 5:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción no válida");
            }
        } while (opcion != 5);
    }

    private void reservarRecursos() {
        String input = vista.obtenerRecursos();
        String[] ids = input.split(",");
        Recurso[] recursosAReservar = new Recurso[ids.length];
        
        for (int i = 0; i < ids.length; i++) {
            recursosAReservar[i] = buscarRecurso(ids[i].trim());
            if (recursosAReservar[i] == null) {
                System.out.println("Recurso " + ids[i] + " no encontrado");
                return;
            }
        }
        
        boolean exito = GestorReservas.reservarRecursos(recursosAReservar);
        vista.mostrarResultadoReserva(exito, input);
    }

    private void liberarRecursos() {
        String input = vista.obtenerRecursos();
        String[] ids = input.split(",");
        Recurso[] recursosALiberar = new Recurso[ids.length];
        
        for (int i = 0; i < ids.length; i++) {
            recursosALiberar[i] = buscarRecurso(ids[i].trim());
            if (recursosALiberar[i] == null) {
                System.out.println("Recurso " + ids[i] + " no encontrado");
                return;
            }
        }
        
        GestorReservas.liberarRecursos(recursosALiberar);
        System.out.println("Recursos liberados: " + input);
    }

    private Recurso buscarRecurso(String id) {
        for (Recurso recurso : recursos) {
            if (recurso.getId().equals(id)) {
                return recurso;
            }
        }
        return null;
    }

    private void simularReservasConcurrentes() {
        System.out.println("\nIniciando 10 reservas concurrentes...");
        
        for (int i = 0; i < 10; i++) {
            final int index = i;
            new Thread(() -> {
                Recurso[] recursos = {
                    this.recursos[index % this.recursos.length],
                    this.recursos[(index + 1) % this.recursos.length]
                };
                
                boolean exito = GestorReservas.reservarRecursos(recursos);
                System.out.println("Reserva de " + recursos[0].getId() + " y " + 
                                 recursos[1].getId() + " " + (exito ? "exitosa" : "fallida"));
                
                try {
                    Thread.sleep(1000); // Simular uso de recursos
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                
                GestorReservas.liberarRecursos(recursos);
            }).start();
        }
    }

}
