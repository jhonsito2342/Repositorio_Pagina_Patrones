/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import modelo.Recurso;

public class VistaReservas {

    public void mostrarMenu() {
        System.out.println("\n=== SISTEMA DE RESERVAS ===");
        System.out.println("1. Reservar recursos");
        System.out.println("2. Liberar recursos");
        System.out.println("3. Ver estado de recursos");
        System.out.println("4. Simular reservas concurrentes");
        System.out.println("5. Salir");
    }

    public void mostrarEstadoRecursos(Recurso[] recursos) {
        for (Recurso recurso : recursos) {
            System.out.println("Recurso " + recurso.getId() + ": "
                    + (recurso.isReservado() ? "Reservado" : "Disponible"));
        }
    }

    public void mostrarResultadoReserva(boolean exito, String recursos) {
        System.out.println("Reserva de " + recursos + " " + (exito ? "exitosa" : "fallida"));
    }

    public int obtenerOpcion() {
        System.out.print("Seleccione opción: ");
        return Integer.parseInt(System.console().readLine());
    }

    public String obtenerRecursos() {
        System.out.print("Ingrese IDs de recursos separados por coma: ");
        return System.console().readLine();
    }
}
