/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Almacen {
    private final String id;
    private final Map<String, Producto> productos = new HashMap<>();
    private final Lock lock = new ReentrantLock();

    public Almacen(String id) {
        this.id = id;
    }

    public void agregarProducto(Producto producto) {
        productos.put(producto.getId(), producto);
    }

    public Producto getProducto(String productoId) {
        return productos.get(productoId);
    }

    public String getId() {
        return id;
    }

    public Lock getLock() {
        return lock;
    }
}
