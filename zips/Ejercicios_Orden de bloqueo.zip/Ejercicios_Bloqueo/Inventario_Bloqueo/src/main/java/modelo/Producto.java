/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Producto {
    private final String id;
    private int cantidad;
    private final Lock lock = new ReentrantLock();

    public Producto(String id, int cantidadInicial) {
        this.id = id;
        this.cantidad = cantidadInicial;
    }

    public void agregar(int cantidad) {
        lock.lock();
        try {
            this.cantidad += cantidad;
        } finally {
            lock.unlock();
        }
    }

    public boolean retirar(int cantidad) {
        lock.lock();
        try {
            if (this.cantidad >= cantidad) {
                this.cantidad -= cantidad;
                return true;
            }
            return false;
        } finally {
            lock.unlock();
        }
    }

    public int getCantidad() {
        return cantidad;
    }

    public String getId() {
        return id;
    }

    public Lock getLock() {
        return lock;
    }
}