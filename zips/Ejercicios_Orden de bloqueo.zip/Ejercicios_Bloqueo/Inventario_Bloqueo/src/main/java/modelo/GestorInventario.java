/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.Arrays;
import java.util.Comparator;

public class GestorInventario {

    // Método que implementa orden de bloqueos para transferencia entre almacenes
    public static boolean transferirProducto(Almacen origen, Almacen destino,
            String productoId, int cantidad) {
        // Ordenar almacenes por ID para garantizar orden consistente
        Almacen[] almacenes = {origen, destino};
        Arrays.sort(almacenes, Comparator.comparing(Almacen::getId));

        almacenes[0].getLock().lock();
        try {
            almacenes[1].getLock().lock();
            try {
                Producto productoOrigen = origen.getProducto(productoId);
                Producto productoDestino = destino.getProducto(productoId);

                if (productoOrigen == null || productoDestino == null) {
                    return false;
                }

                // Ordenar productos por ID para garantizar orden consistente
                Producto[] productos = {productoOrigen, productoDestino};
                Arrays.sort(productos, Comparator.comparing(Producto::getId));

                productos[0].getLock().lock();
                try {
                    productos[1].getLock().lock();
                    try {
                        if (productoOrigen.retirar(cantidad)) {
                            productoDestino.agregar(cantidad);
                            return true;
                        }
                        return false;
                    } finally {
                        productos[1].getLock().unlock();
                    }
                } finally {
                    productos[0].getLock().unlock();
                }
            } finally {
                almacenes[1].getLock().unlock();
            }
        } finally {
            almacenes[0].getLock().unlock();
        }
    }
}
