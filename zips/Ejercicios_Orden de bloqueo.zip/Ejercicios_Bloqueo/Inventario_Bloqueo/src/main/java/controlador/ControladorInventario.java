/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.Almacen;
import modelo.GestorInventario;
import modelo.Producto;
import vista.VistaInventario;

public class ControladorInventario {

    private final Almacen[] almacenes;
    private final VistaInventario vista;

    public ControladorInventario() {
        this.almacenes = new Almacen[2];
        this.almacenes[0] = new Almacen("ALM001");
        this.almacenes[1] = new Almacen("ALM002");
        this.vista = new VistaInventario();

        // Agregar productos de ejemplo
        agregarProductosEjemplo();
    }

    private void agregarProductosEjemplo() {
        // Productos para almacén 1
        almacenes[0].agregarProducto(new Producto("PROD001", 100));
        almacenes[0].agregarProducto(new Producto("PROD002", 150));

        // Productos para almacén 2
        almacenes[1].agregarProducto(new Producto("PROD001", 50));
        almacenes[1].agregarProducto(new Producto("PROD003", 200));
    }

    public void iniciar() {
        int opcion;
        do {
            vista.mostrarMenu();
            opcion = vista.obtenerOpcion();

            switch (opcion) {
                case 1:
                    transferirProducto();
                    break;
                case 2:
                    vista.mostrarInventario(almacenes);
                    break;
                case 3:
                    simularTransferenciasConcurrentes();
                    break;
                case 4:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción no válida");
            }
        } while (opcion != 4);
    }

    private void transferirProducto() {
        String productoId = vista.obtenerProductoId();
        int cantidad = vista.obtenerCantidad();

        boolean exito = GestorInventario.transferirProducto(
                almacenes[0], almacenes[1], productoId, cantidad);

        vista.mostrarResultadoTransferencia(
                exito, productoId, cantidad,
                almacenes[0].getId(), almacenes[1].getId());
    }

    private void simularTransferenciasConcurrentes() {
        System.out.println("\nIniciando 10 transferencias concurrentes...");

        for (int i = 0; i < 10; i++) {
            final String productoId = "PROD00" + (i % 3 + 1);
            final int cantidad = (i % 2 + 1) * 10;
            final boolean direccion = i % 2 == 0;

            new Thread(() -> {
                boolean exito;
                if (direccion) {
                    exito = GestorInventario.transferirProducto(
                            almacenes[0], almacenes[1], productoId, cantidad);
                } else {
                    exito = GestorInventario.transferirProducto(
                            almacenes[1], almacenes[0], productoId, cantidad);
                }

                System.out.println("Transferencia de " + cantidad + " " + productoId
                        + " " + (exito ? "exitosa" : "fallida"));
            }).start();
        }
    }
}
