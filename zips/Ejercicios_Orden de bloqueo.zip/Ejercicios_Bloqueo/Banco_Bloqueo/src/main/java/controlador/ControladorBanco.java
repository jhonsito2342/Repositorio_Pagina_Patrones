/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.Cuenta;
import modelo.Transferencia;
import vista.VistaBanco;

public class ControladorBanco {

    private final Cuenta cuenta1;
    private final Cuenta cuenta2;
    private final VistaBanco vista;

    public ControladorBanco() {
        this.cuenta1 = new Cuenta("CT001", 1000.0);
        this.cuenta2 = new Cuenta("CT002", 2000.0);
        this.vista = new VistaBanco();
    }

    public void iniciar() {
        int opcion;
        do {
            vista.mostrarMenu();
            opcion = vista.obtenerOpcion();

            switch (opcion) {
                case 1:
                    vista.mostrarSaldo(cuenta1);
                    vista.mostrarSaldo(cuenta2);
                    break;
                case 2:
                    realizarTransferencia();
                    break;
                case 3:
                    simularTransferenciasConcurrentes();
                    break;
                case 4:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción no válida");
            }
        } while (opcion != 4);
    }

    private void realizarTransferencia() {
        double monto = vista.obtenerMonto();
        boolean exito = Transferencia.transferir(cuenta1, cuenta2, monto);
        vista.mostrarResultadoTransferencia(exito, monto);
    }

    private void simularTransferenciasConcurrentes() {
        System.out.println("\nIniciando 10 transferencias concurrentes...");

        for (int i = 0; i < 10; i++) {
            final double monto = (i % 3 + 1) * 100;
            final boolean direccion = i % 2 == 0;

            new Thread(() -> {
                boolean exito;
                if (direccion) {
                    exito = Transferencia.transferir(cuenta1, cuenta2, monto);
                } else {
                    exito = Transferencia.transferir(cuenta2, cuenta1, monto);
                }
                System.out.println("Transferencia de " + monto + " "
                        + (exito ? "exitosa" : "fallida"));
            }).start();
        }
    }
}
