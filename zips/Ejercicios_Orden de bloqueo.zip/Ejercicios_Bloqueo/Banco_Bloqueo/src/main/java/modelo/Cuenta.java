/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;


import java.util.concurrent.locks.Lock;

import java.util.concurrent.locks.ReentrantLock;

public class Cuenta {

    private final String numero;
    private double saldo;
    private final Lock lock = new ReentrantLock();

    public Cuenta(String numero, double saldoInicial) {
        this.numero = numero;
        this.saldo = saldoInicial;
    }

    public void depositar(double monto) {
        lock.lock();
        try {
            saldo += monto;
        } finally {
            lock.unlock();
        }
    }

    public boolean retirar(double monto) {
        lock.lock();
        try {
            if (saldo >= monto) {
                saldo -= monto;
                return true;
            }
            return false;
        } finally {
            lock.unlock();
        }
    }

    public double getSaldo() {
        return saldo;
    }

    public String getNumero() {
        return numero;
    }

    public Lock getLock() {
        return lock;
    }
}
