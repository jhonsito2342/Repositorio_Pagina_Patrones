/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

public class Transferencia {

    // Método que implementa el orden de bloqueos
    public static boolean transferir(Cuenta origen, Cuenta destino, double monto) {
        // Definir orden de bloqueo basado en el número de cuenta
        Cuenta primera = origen.getNumero().compareTo(destino.getNumero()) < 0 ? origen : destino;
        Cuenta segunda = primera == origen ? destino : origen;

        primera.getLock().lock();
        try {
            segunda.getLock().lock();
            try {
                if (origen.retirar(monto)) {
                    destino.depositar(monto);
                    return true;
                }
                return false;
            } finally {
                segunda.getLock().unlock();
            }
        } finally {
            primera.getLock().unlock();
        }
    }
}
