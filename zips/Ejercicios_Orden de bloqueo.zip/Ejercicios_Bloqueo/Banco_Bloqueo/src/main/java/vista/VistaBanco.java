/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import modelo.Almacen;
import modelo.Producto;

public class VistaBanco {

    public void mostrarMenu() {
        System.out.println("\n=== SISTEMA DE INVENTARIO ===");
        System.out.println("1. Transferir producto entre almacenes");
        System.out.println("2. Ver inventario");
        System.out.println("3. Simular transferencias concurrentes");
        System.out.println("4. Salir");
    }

    public void mostrarInventario(Almacen[] almacenes) {
        for (Almacen almacen : almacenes) {
            System.out.println("\nAlmacén " + almacen.getId() + ":");
            // Nota: En una aplicación real, necesitarías bloquear para leer
            System.out.println("Productos - [simplificado para ejemplo]");
        }
    }

    public void mostrarResultadoTransferencia(boolean exito, String productoId,
            int cantidad, String origen, String destino) {
        System.out.println("Transferencia de " + cantidad + " unidades de " + productoId
                + " de " + origen + " a " + destino
                + " " + (exito ? "exitosa" : "fallida"));
    }

    public String obtenerProductoId() {
        System.out.print("Ingrese ID del producto: ");
        return System.console().readLine();
    }

    public int obtenerCantidad() {
        System.out.print("Ingrese cantidad: ");
        return Integer.parseInt(System.console().readLine());
    }

    public int obtenerOpcion() {
        System.out.print("Seleccione opción: ");
        return Integer.parseInt(System.console().readLine());
    }
}
