/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Mascota;

/**
 *
 * @author Jhon
 */
public class Gato extends Mascota {

    public Gato(String nombre, int energia) {
        super(nombre, energia);
    }

    @Override
    public String describir() {
        return " " + nombre + " es un gato tranquilo con " + energia + "% de energia. Esta buscando una ventana.";
    }
}
