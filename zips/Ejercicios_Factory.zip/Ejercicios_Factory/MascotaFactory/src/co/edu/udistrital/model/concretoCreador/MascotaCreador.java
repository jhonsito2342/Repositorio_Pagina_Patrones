/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model.concretoCreador;

import co.edu.udistrital.model.Gato;
import co.edu.udistrital.model.Perezoso;
import co.edu.udistrital.model.Perro;
import co.edu.udistrital.model.abstracto.Mascota;
import co.edu.udistrital.model.abstracto.MascotaFactory;



/**
 *
 * @author Jhon
 */
public class MascotaCreador implements MascotaFactory {

    @Override
    public Mascota crearMascota(String nombre, int energia) {
        if (energia >= 70) {
            return new Perro(nombre, energia);
        } else if (energia >= 40) {
            return new Gato(nombre, energia);
        } else {
            return new Perezoso(nombre, energia);
        }
    }
}

