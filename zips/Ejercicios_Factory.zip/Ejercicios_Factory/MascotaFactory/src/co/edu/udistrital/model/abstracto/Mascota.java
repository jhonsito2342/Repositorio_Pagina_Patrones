package co.edu.udistrital.model.abstracto;

public abstract class Mascota {

    protected String nombre;
    protected int energia;

    public Mascota(String nombre, int energia) {
        this.nombre = nombre;
        this.energia = energia;
    }

    public abstract String describir();
}
