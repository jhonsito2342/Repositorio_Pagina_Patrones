package co.edu.udistrital.controller;

import co.edu.udistrital.model.abstracto.Mascota;
import co.edu.udistrital.model.abstracto.MascotaFactory;
import co.edu.udistrital.model.concretoCreador.MascotaCreador;
import co.edu.udistrital.view.VistaConsola;


public class Controller {

    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        vista.mostrarInformacion("CREACION DE MASCOTAS VIRTUALES");

        int energia = vista.leerDatoEntero("Digite el nivel de energia (0 a 100): ");
        vista.limpiarBuffer(); // Si usas nextInt antes de nextLine
        String nombre = vista.leerDatoTexto("Digite el nombre de la mascota: ");

        MascotaFactory fabrica = new MascotaCreador();
        Mascota mascota = fabrica.crearMascota(nombre, energia);

        vista.mostrarInformacion("MASCOTA CREADA:");
        vista.mostrarInformacion(mascota.describir());
    }
}
