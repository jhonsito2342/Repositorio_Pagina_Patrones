/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Mascota;

/**
 *
 * @author Jhon
 */
public class Perro extends Mascota {

    public Perro(String nombre, int energia) {
        super(nombre, energia);
    }

    @Override
    public String describir() {
        return " " + nombre + " es un perro lleno de energia con " + energia + "% de energia. ¡Quiere jugar!";
    }
}
