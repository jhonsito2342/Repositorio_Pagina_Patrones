/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model.concretoCreador;

import co.edu.udistrital.model.ClimaCalido;
import co.edu.udistrital.model.ClimaFrio;
import co.edu.udistrital.model.ClimaTemplado;
import co.edu.udistrital.model.abstracto.Clima;
import co.edu.udistrital.model.abstracto.ClimaFactory;

/**
 *
 * @author Jhon
 */
public class ClimaCreador implements ClimaFactory {

    @Override
    public Clima crearClima(String descripcion, int temperatura) {
        if (temperatura >= 25) {
            return new ClimaCalido(descripcion, temperatura);
        } else if (temperatura >= 15) {
            return new ClimaTemplado(descripcion, temperatura);
        } else {
            return new ClimaFrio(descripcion, temperatura);
        }
    }
}

