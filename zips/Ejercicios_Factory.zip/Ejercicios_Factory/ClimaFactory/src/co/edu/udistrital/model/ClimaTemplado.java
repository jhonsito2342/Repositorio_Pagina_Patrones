/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Clima;

/**
 *
 * @author Jhon
 */
public class ClimaTemplado extends Clima {

    public ClimaTemplado(String descripcion, int temperatura) {
        super(descripcion, temperatura);
    }

    @Override
    public String describir() {
        return "Clima templado con " + temperatura + "°C. " + descripcion;
    }
}