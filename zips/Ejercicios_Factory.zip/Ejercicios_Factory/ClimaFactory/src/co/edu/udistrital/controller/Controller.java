package co.edu.udistrital.controller;

import co.edu.udistrital.model.abstracto.Clima;
import co.edu.udistrital.model.abstracto.ClimaFactory;
import co.edu.udistrital.model.concretoCreador.ClimaCreador;
import co.edu.udistrital.view.VistaConsola;

public class Controller {

    private VistaConsola vista;

    public Controller() {
        vista = new VistaConsola();
    }

    public void run() {
        vista.mostrarInformacion("SISTEMA DE CLASIFICACION DE CLIMA");

        int temperatura = vista.leerDatoEntero("Digite la temperatura en °C: ");
        vista.limpiarBuffer();
        String descripcion = vista.leerDatoTexto("Describa el estado del clima: ");

        ClimaFactory fabrica = new ClimaCreador();
        Clima clima = fabrica.crearClima(descripcion, temperatura);

        vista.mostrarInformacion("CLIMA DETECTADO:");
        vista.mostrarInformacion(clima.describir());
    }
}
