package co.edu.udistrital.model.abstracto;

public abstract class Clima {

    protected String descripcion;
    protected int temperatura;

    public Clima(String descripcion, int temperatura) {
        this.descripcion = descripcion;
        this.temperatura = temperatura;
    }

    public abstract String describir();
}
