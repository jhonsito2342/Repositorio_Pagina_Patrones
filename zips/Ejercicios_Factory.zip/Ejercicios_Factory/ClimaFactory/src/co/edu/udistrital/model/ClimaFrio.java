/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Clima;

/**
 *
 * @author Jhon
 */

public class ClimaFrio extends Clima {

    public ClimaFrio(String descripcion, int temperatura) {
        super(descripcion, temperatura);
    }

    @Override
    public String describir() {
        return "Clima frio con " + temperatura + "°C. " + descripcion;
    }
}
