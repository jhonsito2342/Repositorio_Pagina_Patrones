package co.edu.udistrital.model.abstracto;

public abstract class Pizza {

    protected String ingrediente1;
    protected String ingrediente2;
    protected String ingrediente3;

    public Pizza(String ing1, String ing2, String ing3) {
        this.ingrediente1 = ing1;
        this.ingrediente2 = ing2;
        this.ingrediente3 = ing3;
    }

    public abstract String describir();

    public abstract String calcularPrecio();
}
