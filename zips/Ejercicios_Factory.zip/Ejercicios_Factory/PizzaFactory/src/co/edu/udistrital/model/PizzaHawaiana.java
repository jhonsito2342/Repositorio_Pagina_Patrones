/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Pizza;

/**
 *
 * @author Jhon
 */
public class PizzaHawaiana extends Pizza {

    public PizzaHawaiana(String ing1, String ing2, String ing3) {
        super(ing1, ing2, ing3);
    }

    @Override
    public String describir() {
        return " Pizza Hawaiana";
    }

    @Override
    public String calcularPrecio() {
        return "$22.000";
    }
}
