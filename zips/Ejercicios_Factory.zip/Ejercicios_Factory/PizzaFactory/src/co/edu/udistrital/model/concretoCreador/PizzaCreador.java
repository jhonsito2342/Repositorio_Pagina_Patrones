/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udistrital.model.concretoCreador;

import co.edu.udistrital.model.PizzaChampiñones;
import co.edu.udistrital.model.PizzaHawaiana;
import co.edu.udistrital.model.PizzaPeperoni;
import co.edu.udistrital.model.abstracto.Pizza;
import co.edu.udistrital.model.abstracto.PizzaFactory;

/**
 *
 * @author Jhon
 */
public class PizzaCreador implements PizzaFactory {

    @Override
    public Pizza crearPizza(String ing1, String ing2, String ing3) {
        String ingredientesCombinados = (ing1 + ing2 + ing3).toLowerCase();

        if (ingredientesCombinados.contains("peperoni")) {
            return new PizzaPeperoni(ing1, ing2, ing3);
        } else if (ingredientesCombinados.contains("champiñon") || ingredientesCombinados.contains("champiñones")) {
            return new PizzaChampiñones(ing1, ing2, ing3);
        } else if (ingredientesCombinados.contains("piña")) {
            return new PizzaHawaiana(ing1, ing2, ing3);
        } else {
            // Por defecto si no contiene ninguno de los ingredientes conocidos
            return new PizzaPeperoni(ing1, ing2, ing3);
        }
    }
}
