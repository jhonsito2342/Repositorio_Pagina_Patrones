package co.edu.udistrital.controller;

import co.edu.udistrital.model.abstracto.*;
import co.edu.udistrital.model.concretoCreador.*;
import co.edu.udistrital.view.VistaConsola;

public class ControllerPizza {

    private VistaConsola vista;

    public ControllerPizza() {
        vista = new VistaConsola();
    }

    public void run() {
        String ing1, ing2, ing3;

        vista.mostrarInformacion("PERSONALIZA TU PIZZA");

        ing1 = vista.leerDatoTexto("Ingrediente 1: ");
        ing2 = vista.leerDatoTexto("Ingrediente 2: ");
        ing3 = vista.leerDatoTexto("Ingrediente 3: ");

        PizzaFactory fabrica = new PizzaCreador();
        Pizza pizza = fabrica.crearPizza(ing1, ing2, ing3);

        vista.mostrarInformacion("️ Has creado una " + pizza.describir());
        vista.mostrarInformacion(" Precio: " + pizza.calcularPrecio());
    }
}
