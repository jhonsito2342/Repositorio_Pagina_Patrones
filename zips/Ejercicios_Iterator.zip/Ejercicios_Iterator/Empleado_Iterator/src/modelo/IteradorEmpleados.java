/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;
import java.util.List;

/**
 * Implementación concreta del patrón Iterator para la lista de empleados
 */
public class IteradorEmpleados {

    private List<Empleado> empleados;
    private int posicionActual = 0;

    public IteradorEmpleados(List<Empleado> empleados) {
        this.empleados = empleados;
    }

    /**
     * Verifica si hay más empleados por recorrer
     *
     * @return true si hay más empleados, false en caso contrario
     */
    public boolean tieneSiguiente() {
        return posicionActual < empleados.size();
    }

    /**
     * Devuelve el siguiente empleado en la colección
     *
     * @return Siguiente empleado
     */
    public Empleado siguiente() {
        if (!tieneSiguiente()) {
            throw new IndexOutOfBoundsException("No hay más empleados en el departamento");
        }
        return empleados.get(posicionActual++);
    }

    /**
     * Reinicia el iterador al principio de la colección
     */
    public void reiniciar() {
        posicionActual = 0;
    }

    /**
     * Filtra empleados por puesto
     *
     * @param puesto Puesto a filtrar
     * @return Nuevo iterador con empleados que coinciden con el puesto
     */
    public IteradorEmpleados filtrarPorPuesto(String puesto) {
        List<Empleado> filtrados = new ArrayList<>();
        reiniciar();
        while (tieneSiguiente()) {
            Empleado emp = siguiente();
            if (emp.getPuesto().equalsIgnoreCase(puesto)) {
                filtrados.add(emp);
            }
        }
        return new IteradorEmpleados(filtrados);
    }
}
