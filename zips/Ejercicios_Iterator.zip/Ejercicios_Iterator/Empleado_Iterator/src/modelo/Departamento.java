/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;
import java.util.List;

/**
 * Clase que representa un departamento con empleados y proporciona un iterador
 */
public class Departamento {

    private String nombre;
    private List<Empleado> empleados = new ArrayList<>();

    public Departamento(String nombre) {
        this.nombre = nombre;
    }

    public void agregarEmpleado(Empleado empleado) {
        empleados.add(empleado);
    }

    public String getNombre() {
        return nombre;
    }

    /**
     * Crea y retorna un iterador para los empleados del departamento
     *
     * @return Iterador personalizado para recorrer empleados
     */
    public IteradorEmpleados crearIterador() {
        return new IteradorEmpleados(empleados);
    }

    public int cantidadEmpleados() {
        return empleados.size();
    }
}
