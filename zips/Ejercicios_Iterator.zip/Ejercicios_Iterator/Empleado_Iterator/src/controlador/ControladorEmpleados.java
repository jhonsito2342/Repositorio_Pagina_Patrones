/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.Departamento;
import modelo.Empleado;
import modelo.IteradorEmpleados;
import vista.VistaEmpleados;

/**
 * Controlador que maneja la lógica de la aplicación y comunica Modelo y Vista
 */
public class ControladorEmpleados {

    private Departamento departamento;
    private VistaEmpleados vista;

    public ControladorEmpleados() {
        this.departamento = new Departamento("TI");
        this.vista = new VistaEmpleados();
    }

    public void iniciar() {
        int opcion;
        do {
            vista.mostrarMenu();
            opcion = Integer.parseInt(vista.pedirDato("Seleccione una opción"));

            switch (opcion) {
                case 1:
                    agregarEmpleado();
                    break;
                case 2:
                    mostrarTodosEmpleados();
                    break;
                case 3:
                    mostrarEmpleadosPorPuesto();
                    break;
                case 4:
                    vista.mostrarMensaje("Saliendo del sistema...");
                    break;
                default:
                    vista.mostrarMensaje("Opción no válida");
            }
        } while (opcion != 4);
    }

    private void agregarEmpleado() {
        String id = vista.pedirDato("Ingrese ID del empleado");
        String nombre = vista.pedirDato("Ingrese nombre del empleado");
        String puesto = vista.pedirDato("Ingrese puesto del empleado");
        double salario = Double.parseDouble(vista.pedirDato("Ingrese salario del empleado"));

        Empleado empleado = new Empleado(id, nombre, puesto, salario);
        departamento.agregarEmpleado(empleado);
        vista.mostrarMensaje("Empleado agregado correctamente al departamento " + departamento.getNombre());
    }

    private void mostrarTodosEmpleados() {
        vista.mostrarMensaje("\n--- EMPLEADOS DEL DEPARTAMENTO " + departamento.getNombre()
                + " (" + departamento.cantidadEmpleados() + ") ---");

        // Uso del patrón Iterator para recorrer los empleados
        IteradorEmpleados iterador = departamento.crearIterador();
        while (iterador.tieneSiguiente()) {
            Empleado empleado = iterador.siguiente();
            vista.mostrarEmpleado(empleado);
        }
    }

    private void mostrarEmpleadosPorPuesto() {
        String puesto = vista.pedirDato("Ingrese el puesto a filtrar");
        vista.mostrarMensaje("\n--- EMPLEADOS DE " + departamento.getNombre() + " EN PUESTO: " + puesto + " ---");

        // Uso del iterador con filtrado
        IteradorEmpleados iterador = departamento.crearIterador().filtrarPorPuesto(puesto);
        while (iterador.tieneSiguiente()) {
            Empleado empleado = iterador.siguiente();
            vista.mostrarEmpleado(empleado);
        }
    }
}
