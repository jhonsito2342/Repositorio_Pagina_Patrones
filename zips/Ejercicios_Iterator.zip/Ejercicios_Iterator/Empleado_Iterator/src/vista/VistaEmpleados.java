/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import modelo.Empleado;

/**
 * Clase responsable de mostrar información al usuario
 */
public class VistaEmpleados {

    public void mostrarMenu() {
        System.out.println("\n--- SISTEMA DE EMPLEADOS ---");
        System.out.println("1. Agregar empleado");
        System.out.println("2. Mostrar todos los empleados");
        System.out.println("3. Mostrar empleados por puesto");
        System.out.println("4. Salir");
    }

    public void mostrarEmpleado(Empleado empleado) {
        System.out.println("> " + empleado);
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }

    public String pedirDato(String mensaje) {
        System.out.print(mensaje + ": ");
        return System.console().readLine();
    }
}
