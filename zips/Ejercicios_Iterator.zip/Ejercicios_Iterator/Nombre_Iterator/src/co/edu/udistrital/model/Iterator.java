package co.edu.udistrital.model;

public interface Iterator {
	
	boolean hasMore();
    String getNext();

}
