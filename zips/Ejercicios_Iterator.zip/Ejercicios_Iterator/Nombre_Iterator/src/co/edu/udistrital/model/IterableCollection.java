package co.edu.udistrital.model;

public interface IterableCollection {
	Iterator createIterator();
    Iterator createReverseIterator();

}
