
import controlador.ControladorBiblioteca;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
/**
 * Clase principal que inicia la aplicación
 */
public class Main {

    public static void main(String[] args) {
        ControladorBiblioteca controlador = new ControladorBiblioteca();
        controlador.iniciar();
    }
}
