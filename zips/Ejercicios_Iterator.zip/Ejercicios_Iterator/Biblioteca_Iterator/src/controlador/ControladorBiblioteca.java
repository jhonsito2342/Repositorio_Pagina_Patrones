/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import modelo.CatalogoLibros;
import modelo.Libro;
import modelo.IteradorCatalogo;
import vista.VistaBiblioteca;
import java.util.Scanner;

/**
 * Controlador que maneja la lógica de la aplicación y comunica Modelo y Vista
 */
public class ControladorBiblioteca {

    private CatalogoLibros catalogo;
    private VistaBiblioteca vista;
    private Scanner scanner;

    public ControladorBiblioteca() {
        catalogo = new CatalogoLibros();
        vista = new VistaBiblioteca();
        scanner = new Scanner(System.in);
    }

    public void iniciar() {
        int opcion;
        do {
            vista.mostrarMenu();
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer

            switch (opcion) {
                case 1:
                    agregarLibro();
                    break;
                case 2:
                    mostrarLibros();
                    break;
                case 3:
                    vista.mostrarMensaje("Saliendo del sistema...");
                    break;
                default:
                    vista.mostrarMensaje("Opción no válida");
            }
        } while (opcion != 3);
    }

    private void agregarLibro() {
        vista.mostrarMensaje("Ingrese título del libro:");
        String titulo = scanner.nextLine();
        vista.mostrarMensaje("Ingrese autor del libro:");
        String autor = scanner.nextLine();
        vista.mostrarMensaje("Ingrese año de publicación:");
        int año = scanner.nextInt();

        Libro libro = new Libro(titulo, autor, año);
        catalogo.agregarLibro(libro);
        vista.mostrarMensaje("Libro agregado correctamente");
    }

    private void mostrarLibros() {
        vista.mostrarMensaje("\n--- CATÁLOGO DE LIBROS (" + catalogo.cantidadLibros() + ") ---");

        // Uso del patrón Iterator para recorrer los libros
        IteradorCatalogo iterador = catalogo.crearIterador();
        while (iterador.tieneSiguiente()) {
            Libro libro = iterador.siguiente();
            vista.mostrarLibro(libro);
        }
    }
}
