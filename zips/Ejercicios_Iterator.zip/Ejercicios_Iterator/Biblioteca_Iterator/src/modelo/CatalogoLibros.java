/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.ArrayList;
import java.util.List;

/**
 * Clase que representa un catálogo de libros y proporciona un iterador
 */
public class CatalogoLibros {

    private List<Libro> libros = new ArrayList<>();

    public void agregarLibro(Libro libro) {
        libros.add(libro);
    }

    /**
     * Método que crea y retorna un iterador para el catálogo
     *
     * @return Iterador personalizado para recorrer los libros
     */
    public IteradorCatalogo crearIterador() {
        return new IteradorCatalogo(libros);
    }

    public int cantidadLibros() {
        return libros.size();
    }
}
