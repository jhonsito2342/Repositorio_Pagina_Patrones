/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.util.List;

/**
 * Implementación concreta del patrón Iterator para el catálogo de libros
 */
public class IteradorCatalogo {

    private List<Libro> libros;
    private int posicionActual = 0;

    public IteradorCatalogo(List<Libro> libros) {
        this.libros = libros;
    }

    /**
     * Verifica si hay más elementos por recorrer
     *
     * @return true si hay más libros, false en caso contrario
     */
    public boolean tieneSiguiente() {
        return posicionActual < libros.size();
    }

    /**
     * Devuelve el siguiente libro en la colección
     *
     * @return Siguiente libro
     */
    public Libro siguiente() {
        if (!tieneSiguiente()) {
            throw new IndexOutOfBoundsException("No hay más libros en el catálogo");
        }
        return libros.get(posicionActual++);
    }

    /**
     * Reinicia el iterador al principio de la colección
     */
    public void reiniciar() {
        posicionActual = 0;
    }
}
