/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import modelo.Libro;

/**
 * Clase responsable de mostrar información al usuario
 */
public class VistaBiblioteca {

    public void mostrarMenu() {
        System.out.println("\n--- MENÚ BIBLIOTECA ---");
        System.out.println("1. Agregar libro");
        System.out.println("2. Mostrar todos los libros");
        System.out.println("3. Salir");
    }

    public void mostrarLibro(Libro libro) {
        System.out.println("- " + libro);
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
}
