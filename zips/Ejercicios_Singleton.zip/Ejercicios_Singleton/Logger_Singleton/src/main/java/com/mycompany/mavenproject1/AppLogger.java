package com.mycompany.mavenproject1;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.ArrayList;
import java.util.List;

public class AppLogger {

    private static volatile AppLogger instance;
    private List<String> logs;

    private AppLogger() {
        this.logs = new ArrayList<>();
    }

    // Double-Checked Locking para thread-safety
    public static AppLogger getInstance() {
        if (instance == null) {
            synchronized (AppLogger.class) {
                if (instance == null) {
                    instance = new AppLogger();
                }
            }
        }
        return instance;
    }

    public void addLog(String message) {
        logs.add("[LOG] " + message);
    }

    public List<String> getLogs() {
        return new ArrayList<>(logs); // Retorna copia
    }
}
