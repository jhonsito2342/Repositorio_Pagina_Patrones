/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

import java.util.List;

public class LogView {

    public void displayLogs(List<String> logs) {
        System.out.println("📝 Registros:");
        logs.forEach(System.out::println);
    }
}
