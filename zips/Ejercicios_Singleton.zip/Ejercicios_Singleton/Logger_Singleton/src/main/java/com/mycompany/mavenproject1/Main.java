/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.mavenproject1;

public class Main {

    public static void main(String[] args) {
        LogController controller = new LogController();
        LogView view = new LogView();

        controller.logMessage("Inicio de sesión");
        controller.logMessage("Operación completada");

        view.displayLogs(controller.getAllLogs());

        // Test thread-safe
        new Thread(() -> {
            AppLogger logger = AppLogger.getInstance();
            logger.addLog("Desde otro hilo");
        }).start();
    }
}
