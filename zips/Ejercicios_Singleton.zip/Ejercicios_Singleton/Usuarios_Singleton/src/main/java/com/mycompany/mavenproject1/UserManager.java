/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

import java.util.HashMap;
import java.util.Map;

public enum UserManager {
    INSTANCE;

    private Map<String, String> users;

    UserManager() {
        this.users = new HashMap<>();
        users.put("admin", "admin123"); // Usuario por defecto
    }

    public void addUser(String username, String password) {
        users.put(username, password);
    }

    public boolean authenticate(String username, String password) {
        return users.containsKey(username) && users.get(username).equals(password);
    }

    public int getUserCount() {
        return users.size();
    }
}
