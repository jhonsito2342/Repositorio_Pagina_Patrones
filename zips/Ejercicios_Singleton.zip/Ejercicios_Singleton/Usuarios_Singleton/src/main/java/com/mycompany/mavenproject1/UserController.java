/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

public class UserController {

    private UserManager userManager;

    public UserController() {
        this.userManager = UserManager.INSTANCE; // Obtiene la instancia Singleton
    }

    public boolean login(String username, String password) {
        return userManager.authenticate(username, password);
    }

    public void register(String username, String password) {
        userManager.addUser(username, password);
    }
}
