/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.mavenproject1;

public class Main {

    public static void main(String[] args) {
        UserController controller = new UserController();
        UserView view = new UserView();

        controller.register("user1", "pass123");
        boolean result = controller.login("user1", "pass123");
        view.showLoginResult(result);

        // Verificar Singleton
        UserManager manager1 = UserManager.INSTANCE;
        UserManager manager2 = UserManager.INSTANCE;
        System.out.println("¿Misma instancia? " + (manager1 == manager2)); // true
    }
}
