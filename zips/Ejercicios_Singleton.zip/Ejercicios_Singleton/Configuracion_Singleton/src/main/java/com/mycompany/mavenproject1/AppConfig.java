/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mavenproject1;

public class AppConfig {

    private static AppConfig instance;
    private String appName;
    private String themeColor;

    // Constructor privado
    private AppConfig() {
        this.appName = "MiApp";
        this.themeColor = "Azul";
    }

    // Método estático para obtener la instancia
    public static synchronized AppConfig getInstance() {
        if (instance == null) {
            instance = new AppConfig();
        }
        return instance;
    }

    // Getters
    public String getAppName() {
        return appName;
    }

    public String getThemeColor() {
        return themeColor;
    }
}
