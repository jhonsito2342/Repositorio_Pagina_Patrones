/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.mavenproject1;

/**
 *
 * @author Jhon
 */
public class Main {

    public static void main(String[] args) {
        ConfigController controller = new ConfigController();
        ConfigView view = new ConfigView();

        view.showConfig(controller.getConfigData());

        // Verificar que es la misma instancia
        AppConfig config1 = AppConfig.getInstance();
        AppConfig config2 = AppConfig.getInstance();
        System.out.println("¿Misma instancia? " + (config1 == config2)); // true
    }
}
